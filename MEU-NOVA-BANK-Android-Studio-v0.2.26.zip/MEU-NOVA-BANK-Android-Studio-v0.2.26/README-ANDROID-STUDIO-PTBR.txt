Meu Nova Bank Android Studio — 0.2.23

Atualização demonstrativa do ciclo de vida do cartão virtual: ativação consentida, bloqueio por perda/furto/roubo e substituição após bloqueio. O número exibido é 0000 0000 0000 0000, a validade 12/99 é apenas ilustrativa, e o código exibido é DEMO (não é CVV); todos são fictícios e inválidos para pagamento; o protótipo não possui emissor nem processador de pagamentos.

A mudança requer aplicar a migration Supabase `supabase/migrations/20261023_demo_card_lifecycle.sql` antes de usar essas funções. Ativação exige limite configurado de pelo menos R$ 152; bloqueio exige informar perda, furto ou roubo; substituição só é permitida após bloqueio confirmado. O estado é confirmado pelo servidor e as solicitações têm idempotência por UUID. Para compilar: abrir esta pasta no Android Studio e compilar app/debug.


Versão 0.2.23: permite usar o cheque especial configurado/ativado como origem de Transferências DEM. O valor utilizado é contabilizado separadamente do saldo e do cartão, sem criar saldo negativo ou dívida real. A disponibilidade é limite escolhido menos utilizações DEM já registradas; para teste demonstrativo apenas. Exige aplicação manual da migration 20261024_dem_transfer_overdraft.sql no projeto Supabase.

Versão 0.2.24: após transferência DEM pelo cartão, apresenta o limite utilizado/disponível confirmado pelo servidor; falhas na leitura do perfil não são tratadas como limite zero. Requer migration 20261025_dem_card_credit_usage_response.sql no Supabase antes da atualização para receber o saldo de crédito no retorno da RPC.


Versão 0.2.25 (versionCode 36): nova tela nativa de escolha do débito de Transferência DEM (saldo, cartão demonstrativo ativo com limite suficiente, ou cheque especial ativo com limite suficiente). Exibe disponibilidade e motivos de indisponibilidade. Falhas de consulta não são apresentadas como saldo zero confirmado. A RPC mantém validação autoritativa e recebe funding_source balance/card/overdraft; nenhum dado, saldo, limite ou ledger é alterado fora da operação DEM confirmada pelo servidor. Não requer nova migration; depende das migrations DEM já aplicadas no servidor.


Versão 0.2.26 (versionCode 37): tela exclusiva de seleção de origem de Transferência DEM em tela cheia, com ícones de saldo/cartão/cheque especial, estado selecionado e indisponível, resumo inline e botão fixo Confirmar transferência. Fluxo sem AlertDialog/popup: somente a ação explícita do botão devolve RESULT_OK e permite a chamada RPC DEM. Mantém validação autoritativa e idempotência no servidor; sem migration ou alteração de dados.
