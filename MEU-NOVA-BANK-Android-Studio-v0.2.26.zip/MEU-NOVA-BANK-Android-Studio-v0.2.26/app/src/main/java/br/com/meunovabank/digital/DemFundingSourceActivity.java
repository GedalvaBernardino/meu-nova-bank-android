package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.text.NumberFormat;
import java.util.Locale;

/** Full-screen DEM funding-source selection. Server RPC remains authoritative. */
public final class DemFundingSourceActivity extends Activity {
    private String recipient;
    private BigDecimal amount, fee, cardCharge;
    private LinearLayout options;
    private TextView availability, summary;
    private android.widget.Button confirm;
    private BigDecimal balanceAvailable, cardAvailable, cardLimitValue, overdraftAvailable;
    private boolean balanceLoaded, cardLoaded, overdraftLoaded, cardActive, overdraftActive;
    private String selected = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recipient = getIntent().getStringExtra("recipient");
        try { amount = new BigDecimal(getIntent().getStringExtra("amount")).setScale(2, RoundingMode.UNNECESSARY); }
        catch (Exception e) { finish(); return; }
        fee = amount.multiply(new BigDecimal("0.037")).setScale(2, RoundingMode.HALF_UP);
        cardCharge = amount.add(fee);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Palette.BG);
        root.setFocusableInTouchMode(true);
        getWindow().setStatusBarColor(Palette.NAVY_DARK);
        getWindow().setNavigationBarColor(Palette.NAVY_DARK);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.d(this, 18), Ui.d(this, 8), Ui.d(this, 18), Ui.d(this, 8));
        header.setBackgroundColor(Palette.NAVY);
        TextView back = Ui.text(this, "‹", 32, android.graphics.Color.WHITE, false);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Voltar");
        back.setClickable(true); back.setFocusable(true); back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(Ui.d(this, 44), Ui.d(this, 52)));
        TextView heading = Ui.text(this, "Transferência DEM", 18, android.graphics.Color.WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, -2, 1); hp.leftMargin = Ui.d(this, 8); header.addView(heading, hp);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout content = Ui.column(this);
        Ui.section(this, content, "Escolha a origem", "Débito demonstrativo · confirme para continuar");
        Ui.card(this, content, "Destino e valor", "Conta DEM " + recipient + " · crédito de " + money(amount), null);
        Ui.card(this, content, "Somente demonstração", "A operação afeta apenas o ledger DEM interno. Não aciona Pix, bancos ou redes reais e não cria dívida real. Cartão: taxa demonstrativa de 3,7%.", null);
        TextView availabilityLabel = Ui.text(this, "Disponibilidade consultada agora · o servidor valida novamente ao confirmar", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2); alp.topMargin = Ui.d(this, 8); alp.bottomMargin = Ui.d(this, 8); content.addView(availabilityLabel, alp);
        options = new LinearLayout(this); options.setOrientation(LinearLayout.VERTICAL); content.addView(options, new LinearLayout.LayoutParams(-1, -2));
        availability = Ui.text(this, "Consultando saldo e limites demonstrativos…", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(-1, -2); avp.topMargin = Ui.d(this, 6); content.addView(availability, avp);
        summary = Ui.text(this, "Selecione uma origem disponível para revisar o débito.", 13, Palette.MUTED, false);
        summary.setPadding(Ui.d(this, 14), Ui.d(this, 12), Ui.d(this, 14), Ui.d(this, 12));
        summary.setBackground(Ui.bg(android.graphics.Color.WHITE, Ui.d(this, 14)));
        LinearLayout.LayoutParams smp = new LinearLayout.LayoutParams(-1, -2); smp.topMargin = Ui.d(this, 12); content.addView(summary, smp);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.VERTICAL);
        footer.setPadding(Ui.d(this, 18), Ui.d(this, 10), Ui.d(this, 18), Ui.d(this, 12));
        footer.setBackgroundColor(android.graphics.Color.WHITE);
        footer.setElevation(Ui.d(this, 8));
        confirm = Ui.button(this, "Confirmar transferência", Palette.GREEN);
        confirm.setEnabled(false);
        confirm.setAlpha(.55f);
        confirm.setOnClickListener(v -> finishWithSelection());
        footer.addView(confirm, new LinearLayout.LayoutParams(-1, -2));
        TextView cancel = Ui.text(this, "Cancelar e voltar", 13, Palette.MUTED, true);
        cancel.setGravity(Gravity.CENTER); cancel.setPadding(0, Ui.d(this, 10), 0, Ui.d(this, 2));
        cancel.setClickable(true); cancel.setFocusable(true); cancel.setOnClickListener(v -> finish());
        footer.addView(cancel, new LinearLayout.LayoutParams(-1, -2));
        root.addView(footer, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        loadAvailability();
    }

    private void loadAvailability() {
        final String account = SessionStore.accountNumber(), token = SessionStore.accessToken();
        new Thread(() -> {
            try {
                if (token.isEmpty() || !account.matches("[0-9]{6}")) throw new Exception("session");
                JSONArray rows = InterbankRest.get("customer_profiles?select=user_id,card_credit_limit,card_credit_used,demo_card_active,overdraft_user_limit,overdraft_active,overdraft_used&account_number=eq." + account + "&limit=1", token);
                if (rows.length() == 0 || rows.optJSONObject(0) == null) throw new Exception("profile");
                JSONObject profile = rows.getJSONObject(0);
                String userId = profile.optString("user_id", "");
                if (userId.isEmpty() || profile.isNull("card_credit_limit") || profile.isNull("card_credit_used") || profile.isNull("overdraft_user_limit") || profile.isNull("overdraft_used") || !profile.has("demo_card_active") || !profile.has("overdraft_active")) throw new Exception("profile_fields");
                BigDecimal cLimit = new BigDecimal(profile.getString("card_credit_limit"));
                BigDecimal cUsed = new BigDecimal(profile.getString("card_credit_used"));
                BigDecimal oLimit = new BigDecimal(profile.getString("overdraft_user_limit"));
                BigDecimal oUsed = new BigDecimal(profile.getString("overdraft_used"));
                boolean cActive = profile.getBoolean("demo_card_active"), oActive = profile.getBoolean("overdraft_active");
                JSONArray wallets = InterbankRest.get("wallets?select=available_balance&user_id=eq." + URLEncoder.encode(userId, "UTF-8") + "&limit=1", token);
                if (wallets.length() == 0 || wallets.optJSONObject(0) == null || wallets.getJSONObject(0).isNull("available_balance")) throw new Exception("wallet");
                BigDecimal b = new BigDecimal(wallets.getJSONObject(0).getString("available_balance"));
                BigDecimal c = cLimit.subtract(cUsed).max(BigDecimal.ZERO), o = oLimit.subtract(oUsed).max(BigDecimal.ZERO);
                runOnUiThread(() -> {
                    balanceAvailable = b; cardAvailable = c; cardLimitValue = cLimit; overdraftAvailable = o;
                    balanceLoaded = cardLoaded = overdraftLoaded = true; cardActive = cActive; overdraftActive = oActive;
                    renderOptions(); availability.setText("Valores indicativos; saldo e limites podem mudar. A RPC DEM verifica novamente antes de registrar.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> { balanceLoaded = cardLoaded = overdraftLoaded = false; renderOptions(); availability.setText("Não foi possível confirmar saldo e limites agora. As origens ficam indisponíveis; tente novamente mais tarde."); });
            }
        }, "dem-funding-availability").start();
    }

    private void renderOptions() {
        options.removeAllViews();
        addOption("balance", "Saldo", balanceLoaded ? "Disponível: " + money(balanceAvailable) + " · débito " + money(amount) : "Saldo indisponível: falha ao consultar a carteira", balanceLoaded && balanceAvailable.compareTo(amount) >= 0, "Saldo demonstrativo insuficiente.");
        BigDecimal cardMinimum = new BigDecimal("152.00");
        String cardDetail = !cardLoaded ? "Cartão indisponível: perfil não confirmado" : !cardActive ? "Cartão demonstrativo inativo; ative-o para usar" : cardAvailable.compareTo(cardCharge) < 0 ? "Limite insuficiente para valor + taxa de 3,7%" : "Disponível: " + money(cardAvailable) + " · débito " + money(cardCharge) + " (inclui taxa de 3,7%)";
        boolean canCard = cardLoaded && cardActive && cardAvailable.compareTo(cardCharge) >= 0 && cardLimitValue.compareTo(cardMinimum) >= 0;
        addOption("card", "Cartão de crédito", cardDetail, canCard, "O cartão precisa estar ativo e ter limite suficiente para o valor e a taxa.");
        String overdraftDetail = !overdraftLoaded ? "Cheque especial indisponível: perfil não confirmado" : !overdraftActive ? "Cheque especial demonstrativo inativo" : overdraftAvailable.compareTo(amount) < 0 ? "Limite disponível insuficiente" : "Disponível: " + money(overdraftAvailable) + " · utilização " + money(amount);
        addOption("overdraft", "Cheque especial", overdraftDetail, overdraftLoaded && overdraftActive && overdraftAvailable.compareTo(amount) >= 0, "Ative o cheque especial ou aguarde a atualização do limite.");
        boolean hasSelection = !selected.isEmpty();
        confirm.setEnabled(hasSelection); confirm.setAlpha(hasSelection ? 1f : .55f);
        if (!hasSelection) summary.setText("Selecione uma origem disponível para revisar o débito.");
        else {
            String label = sourceLabel(selected);
            BigDecimal debit = "card".equals(selected) ? cardCharge : amount;
            summary.setText("Resumo da confirmação\nDestino: conta DEM " + recipient + "\nValor a creditar: " + money(amount) + "\nOrigem: " + label + "\nDébito demonstrativo: " + money(debit) + ("card".equals(selected) ? " (inclui taxa de 3,7%)" : "") + "\n\nSomente ledger demonstrativo. O servidor validará os valores atuais ao confirmar.");
        }
    }

    private void addOption(String key, String title, String detail, boolean enabled, String reason) {
        boolean chosen = selected.equals(key);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(Ui.d(this, 14), Ui.d(this, 13), Ui.d(this, 14), Ui.d(this, 13));
        row.setBackground(Ui.bg(chosen ? Palette.PALE_BLUE : android.graphics.Color.WHITE, Ui.d(this, 17)));
        row.setAlpha(enabled ? 1f : .58f); row.setClickable(enabled); row.setFocusable(enabled);
        TextView icon = Ui.text(this, "balance".equals(key) ? "▤" : "card".equals(key) ? "▣" : "◷", 22, chosen ? Palette.GREEN : Palette.NAVY, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(Ui.bg(chosen ? android.graphics.Color.WHITE : Palette.PALE_BLUE, Ui.d(this, 13)));
        icon.setContentDescription("Ícone: " + title);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.d(this, 42), Ui.d(this, 42)); ip.rightMargin = Ui.d(this, 12); row.addView(icon, ip);
        LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(Ui.text(this, title, 15, Palette.NAVY, true));
        TextView sub = Ui.text(this, detail + (enabled ? "" : " · " + reason), 12, Palette.MUTED, false); sub.setLineSpacing(Ui.d(this, 2), 1f);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, -2); subp.topMargin = Ui.d(this, 5); copy.addView(sub, subp);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        TextView radio = Ui.text(this, chosen ? "✓" : "○", 21, chosen ? Palette.GREEN : Palette.MUTED, true);
        radio.setGravity(Gravity.CENTER); radio.setContentDescription(chosen ? "Selecionado" : "Não selecionado");
        row.addView(radio, new LinearLayout.LayoutParams(Ui.d(this, 32), Ui.d(this, 32)));
        row.setContentDescription(title + (chosen ? ", selecionado. " : ". ") + detail + (enabled ? "" : ". Indisponível."));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.bottomMargin = Ui.d(this, 9); options.addView(row, rp);
        if (enabled) row.setOnClickListener(v -> { selected = key; renderOptions(); });
    }

    private String sourceLabel(String source) {
        return "balance".equals(source) ? "Saldo" : "card".equals(source) ? "Cartão de crédito DEM" : "Cheque especial DEM";
    }

    private void finishWithSelection() {
        if (selected.isEmpty()) return;
        Intent result = new Intent(); result.putExtra("recipient", recipient); result.putExtra("amount", amount.toPlainString()); result.putExtra("source", selected);
        setResult(RESULT_OK, result); finish();
    }

    private String money(BigDecimal v) { return NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(v); }
}
