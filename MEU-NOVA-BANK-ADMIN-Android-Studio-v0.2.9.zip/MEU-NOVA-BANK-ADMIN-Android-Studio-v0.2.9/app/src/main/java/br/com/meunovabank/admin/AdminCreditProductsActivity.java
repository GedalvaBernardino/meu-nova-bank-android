package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.util.Locale;

/** Per-account demo limits. These values never fund real lending or card transactions. */
public final class AdminCreditProductsActivity extends AdminNativeActivity {
    private String account="",name="";private EditText loanField,cardField;private TextView loanStatus,cardStatus;private Button loanSave,cardSave;private boolean loaded=false;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";name=getIntent().getStringExtra("display_name");if(name==null)name="Usuário";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Crédito demonstrativo",23,BLUE,true),matchWrap());root.addView(text(name+"  ·  Conta "+account,14,INK,true),matchWrap());
        root.addView(text("Configure cada produto por usuário. Informe 0 para desativar; os limites nunca movimentam dinheiro.",13,MUTED,false),matchWrap());
        addProduct(root,true);addProduct(root,false);
        Button back=button("Voltar",BLUE);root.addView(back,matchWrap());back.setOnClickListener(v->finish());installPage(root);load();
    }
    private void addProduct(LinearLayout root,boolean loan){
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(15),dp(14),dp(15),dp(14));card.setBackground(round(android.graphics.Color.WHITE,"#E3E9F1",21));card.setElevation(dp(1));LinearLayout.LayoutParams cp=matchWrap();cp.topMargin=dp(10);root.addView(card,cp);
        String title=loan?"Empréstimo pessoal":"Meu Nova Card";String hint=loan?"Limite de R$ 102 a R$ 90.000 (0 desativa)":"Limite de R$ 152 a R$ 90.000 (0 desativa)";
        card.addView(text(title,17,BLUE,true),matchWrap());card.addView(text(hint,12,MUTED,false),matchWrap());
        EditText field=field(hint,InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);field.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(12)});card.addView(field,matchWrap());
        TextView current=text("Carregando limite atual…",12,MUTED,false);card.addView(current,matchWrap());Button save=button(loan?"Salvar limite do empréstimo":"Salvar limite do cartão",GREEN);card.addView(save,matchWrap());
        if(loan){loanField=field;loanStatus=current;loanSave=save;save.setOnClickListener(v->review(true));}else{cardField=field;cardStatus=current;cardSave=save;save.setOnClickListener(v->review(false));}
    }
    private void load(){new Thread(()->{try{JSONObject req=new JSONObject();req.put("action","get_profile");req.put("account_number",account);JSONObject p=adminRequest(req).getJSONObject("profile");String loan=p.optString("personal_loan_limit","0.00"),card=p.optString("card_credit_limit","0.00");runOnUiThread(()->{loanField.setText(amount(loan).signum()==0?"":loan);cardField.setText(amount(card).signum()==0?"":card);loanStatus.setText("Empréstimo: "+(amount(loan).signum()==0?"desativado":money(loan)));cardStatus.setText("Cartão: "+(amount(card).signum()==0?"desativado":money(card)));loaded=true;loanSave.setEnabled(true);cardSave.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{loanStatus.setText("Não foi possível carregar os limites.");cardStatus.setText("Não foi possível carregar os limites.");});}},"nova-admin-credit-load").start();loanSave.setEnabled(false);cardSave.setEnabled(false);}
    private void review(boolean loan){if(!loaded)return;EditText field=loan?loanField:cardField;String raw=field.getText().toString().trim().replace(',','.');if(!raw.matches("[0-9]{1,6}(?:[.][0-9]{1,2})?")){message(loan,"Informe um valor com até duas casas decimais.");return;}BigDecimal value=amount(raw);BigDecimal minimum=BigDecimal.valueOf(loan?102:152);if(value.signum()!=0&&(value.compareTo(minimum)<0||value.compareTo(BigDecimal.valueOf(90000))>0)){message(loan,"O limite deve ficar entre R$ "+minimum.toPlainString()+" e R$ 90.000, ou 0 para desativar.");return;}String label=loan?"empréstimo pessoal":"Meu Nova Card";new AlertDialog.Builder(this).setTitle("Confirmar limite de "+label+"?").setMessage("Conta "+account+"\nNovo limite: "+(value.signum()==0?"Desativado":money(value.toPlainString()))+"\n\nConfiguração demonstrativa; sem empréstimo, crédito ou transferência real.").setNegativeButton("Revisar",null).setPositiveButton("Confirmar",(d,w)->save(loan,value)).show();}
    private void save(boolean loan,BigDecimal value){Button button=loan?loanSave:cardSave;TextView label=loan?loanStatus:cardStatus;button.setEnabled(false);label.setText("Salvando e registrando auditoria…");new Thread(()->{try{JSONObject req=new JSONObject();req.put("action",loan?"set_personal_loan_limit":"set_card_credit_limit");req.put("account_number",account);req.put("limit",value.setScale(2,java.math.RoundingMode.HALF_UP).toPlainString());JSONObject result=adminRequest(req);if(!result.optBoolean("ok",false))throw new Exception("PRODUCT_LIMIT_REJECTED");runOnUiThread(()->{label.setText((loan?"Empréstimo pessoal":"Meu Nova Card")+": limite atualizado e auditado — "+(value.signum()==0?"desativado":money(value.toPlainString()))+".");button.setEnabled(true);});}catch(Exception e){String error=e.getMessage()==null?"":e.getMessage();String msg=error.contains("TARGET_ACCOUNT_INACTIVE")?"Não é possível liberar crédito demonstrativo para conta inativa.":"Não foi possível salvar. Verifique o intervalo permitido e tente novamente.";runOnUiThread(()->{label.setText(msg);button.setEnabled(true);});}},"nova-admin-credit-save").start();}
    private void message(boolean loan,String value){(loan?loanStatus:cardStatus).setText(value);}
    private BigDecimal amount(String value){try{return new BigDecimal(value);}catch(Exception e){return BigDecimal.ZERO;}}
}
