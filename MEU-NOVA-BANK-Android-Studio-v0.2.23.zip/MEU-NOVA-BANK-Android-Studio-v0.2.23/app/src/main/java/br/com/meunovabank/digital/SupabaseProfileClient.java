package br.com.meunovabank.digital;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Obtém somente campos de apresentação não sensíveis do próprio perfil, sujeito ao RLS. */
public final class SupabaseProfileClient {
    private static final String PROFILE_URL =
            "https://hzgslpskmyzczqquendt.supabase.co/rest/v1/customer_profiles";

    public interface NameCallback { void done(String displayName); }
    public interface ThemeCallback { void done(String themeTier); }
    public interface CreditLimitsCallback { void done(String personalLoanLimit, String cardCreditLimit, String cardCreditUsed); }

    private SupabaseProfileClient() {}

    public static void fetchDisplayName(String accessToken, String accountNumber, NameCallback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            String displayName = "";
            try {
                if (accessToken == null || accessToken.isEmpty()
                        || accountNumber == null || !accountNumber.matches("[0-9]{6}")) {
                    callback.done("");
                    return;
                }
                URL url = new URL(PROFILE_URL + "?select=display_name&account_number=eq." + accountNumber + "&limit=1");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + accessToken);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("Cache-Control", "no-store");
                int status = connection.getResponseCode();
                if (status >= 200 && status < 300) {
                    String response = readAll(connection.getInputStream());
                    JSONArray profiles = new JSONArray(response);
                    if (profiles.length() > 0) {
                        JSONObject profile = profiles.optJSONObject(0);
                        if (profile != null) displayName = profile.optString("display_name", "").trim();
                    }
                }
            } catch (Exception ignored) {
                displayName = "";
            } finally {
                if (connection != null) connection.disconnect();
            }
            callback.done(displayName);
        }, "meunova-profile-name").start();
    }

    /** Fetches the signed-in user's demo-only product limits subject to profile RLS. */
    public static void fetchCreditLimits(String accessToken, String accountNumber, CreditLimitsCallback callback) {
        new Thread(() -> {
            String loan = "0.00", card = "0.00", used = "0.00";
            HttpURLConnection connection = null;
            try {
                if (accessToken != null && !accessToken.isEmpty() && accountNumber != null && accountNumber.matches("[0-9]{6}")) {
                    URL url = new URL(PROFILE_URL + "?select=personal_loan_limit,card_credit_limit,card_credit_used&account_number=eq." + accountNumber + "&limit=1");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET"); connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
                    connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                    connection.setRequestProperty("Authorization", "Bearer " + accessToken);
                    connection.setRequestProperty("Accept", "application/json"); connection.setRequestProperty("Cache-Control", "no-store");
                    int status = connection.getResponseCode();
                    if (status >= 200 && status < 300) {
                        JSONArray rows = new JSONArray(readAll(connection.getInputStream()));
                        if (rows.length() > 0) { JSONObject row = rows.optJSONObject(0); if (row != null) { loan = row.optString("personal_loan_limit", "0.00"); card = row.optString("card_credit_limit", "0.00"); used = row.optString("card_credit_used", "0.00"); } }
                    }
                }
            } catch (Exception ignored) { loan = "0.00"; card = "0.00"; }
            finally { if (connection != null) connection.disconnect(); }
            callback.done(loan, card, used);
        }, "meunova-credit-limits").start();
    }

    /** Fetches only the server-assigned visual tier; the client never writes it. */
    public static void fetchThemeTier(String accessToken, String accountNumber, ThemeCallback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            String tier = "";
            try {
                if (accessToken != null && !accessToken.isEmpty()
                        && accountNumber != null && accountNumber.matches("[0-9]{6}")) {
                    URL url = new URL(PROFILE_URL + "?select=theme_tier&account_number=eq." + accountNumber + "&limit=1");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(12000);
                    connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                    connection.setRequestProperty("Authorization", "Bearer " + accessToken);
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("Cache-Control", "no-store");
                    int status = connection.getResponseCode();
                    if (status >= 200 && status < 300) {
                        JSONArray profiles = new JSONArray(readAll(connection.getInputStream()));
                        if (profiles.length() > 0) {
                            JSONObject profile = profiles.optJSONObject(0);
                            if (profile != null) tier = Palette.normalizeTier(profile.optString("theme_tier", "basic"));
                        }
                    }
                }
            } catch (Exception ignored) {
                // Retain the locally cached/server default tier on transient failures.
            } finally {
                if (connection != null) connection.disconnect();
            }
            callback.done(tier);
        }, "meunova-profile-theme").start();
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int count;
            while ((count = in.read(buffer)) != -1) {
                if (out.size() + count > 8192) throw new IllegalStateException("Profile response too large");
                out.write(buffer, 0, count);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
