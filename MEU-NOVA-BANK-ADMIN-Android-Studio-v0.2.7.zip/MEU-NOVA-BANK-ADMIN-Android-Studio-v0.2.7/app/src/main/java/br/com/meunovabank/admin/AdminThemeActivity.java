package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import org.json.JSONObject;

/** Dedicated theme-tier selector; updates the user's display preference only. */
public final class AdminThemeActivity extends AdminNativeActivity {
    private static final String[] KEYS={"basic","select","platinum","gold","black"};
    private static final String[] LABELS={"Basic · azul","Select · cinza","Platinum · laranja","Ouro · dourado","Black · preto"};
    private String account="",displayName="",email="",phone="",original="basic";
    private Spinner selector; private TextView status; private Button save; private boolean loaded=false;

    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";displayName=getIntent().getStringExtra("display_name");if(displayName==null)displayName="Usuário";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Cor do aplicativo",24,BLUE,true),matchWrap());root.addView(text(displayName+"  ·  Conta "+account,14,INK,true),matchWrap());
        root.addView(text("Escolha a categoria visual que o app deste usuário carregará ao atualizar o perfil.",13,MUTED,false),matchWrap());
        selector=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,LABELS);adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);selector.setAdapter(adapter);root.addView(selector,matchWrap());
        status=text("Carregando categoria atual…",13,MUTED,false);root.addView(status,matchWrap());save=button("Revisar e salvar cor",GREEN);save.setEnabled(false);root.addView(save,matchWrap());Button back=button("Voltar",BLUE);root.addView(back,matchWrap());
        save.setOnClickListener(v->review());back.setOnClickListener(v->finish());installPage(root);load();
    }

    private void load(){new Thread(()->{try{JSONObject request=new JSONObject();request.put("action","get_profile");request.put("account_number",account);JSONObject p=adminRequest(request).getJSONObject("profile");runOnUiThread(()->{displayName=p.optString("display_name",displayName);email=p.optString("email","");phone=p.optString("phone","");original=p.optString("theme_tier","basic");selector.setSelection(position(original));loaded=true;status.setText("Categoria atual: "+LABELS[position(original)]);save.setEnabled(true);});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível carregar a categoria atual."));}},"nova-admin-theme-load").start();}

    private int position(String key){for(int i=0;i<KEYS.length;i++)if(KEYS[i].equalsIgnoreCase(key))return i;return 0;}
    private void review(){if(!loaded)return;int i=selector.getSelectedItemPosition();if(i<0||i>=KEYS.length)return;String next=KEYS[i];if(next.equals(original)){toast("Esta categoria já está selecionada.");return;}new AlertDialog.Builder(this).setTitle("Aplicar "+LABELS[i]+"?").setMessage("A mudança afeta apenas a aparência do app da conta "+account+". Não altera saldo nem transações.").setNegativeButton("Voltar",null).setPositiveButton("Confirmar",(d,w)->saveTheme(next)).show();}

    private void saveTheme(String tier){save.setEnabled(false);status.setText("Salvando preferência visual…");new Thread(()->{try{JSONObject request=new JSONObject();request.put("action","update_profile");request.put("account_number",account);request.put("display_name",displayName);request.put("email",email);request.put("phone",phone);request.put("theme_tier",tier);request.put("confirm_email_change",false);JSONObject response=adminRequest(request);boolean auditOk=response.optBoolean("audit_ok",false);runOnUiThread(()->{original=tier;status.setText(auditOk?"Categoria atualizada e auditada.":"Categoria atualizada, mas não foi possível confirmar a auditoria.");save.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{status.setText("Não foi possível atualizar a categoria. Tente novamente.");save.setEnabled(true);});}},"nova-admin-theme-save").start();}
}
