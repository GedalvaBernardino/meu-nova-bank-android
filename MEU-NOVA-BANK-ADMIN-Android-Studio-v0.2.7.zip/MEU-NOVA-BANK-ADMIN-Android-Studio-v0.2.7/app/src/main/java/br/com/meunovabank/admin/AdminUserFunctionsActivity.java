package br.com.meunovabank.admin;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.content.Intent;

/** User-specific action hub; each administrative function opens its own Activity. */
public final class AdminUserFunctionsActivity extends AdminNativeActivity {
    private String account = "", name = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        account = getIntent().getStringExtra("account_number"); if (account == null) account = "";
        name = getIntent().getStringExtra("display_name"); if (name == null || name.trim().isEmpty()) name = "Usuário";
        LinearLayout root = page();
        root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());
        root.addView(text("Funções da conta",24,BLUE,true),matchWrap());
        root.addView(text(name + "  ·  Conta " + account,14,INK,true),matchWrap());
        root.addView(text("Cada ação tem sua própria tela de revisão e confirmação.",13,MUTED,false),matchWrap());
        addAction(root,"P","Editar perfil","Nome, e-mail e telefone",AdminEditProfileActivity.class);
        addAction(root,"A","Permissões","Acesso de administrador ou usuário",AdminRoleActivity.class);
        addAction(root,"✦","Cor do aplicativo","Ouro, Select, Platinum, Basic ou Black",AdminThemeActivity.class);
        addAction(root,"↻","Recuperação de senha","Enviar link seguro ao e-mail confirmado",AdminPasswordRecoveryActivity.class);
        android.widget.Button back=button("Voltar aos usuários",BLUE); root.addView(back,matchWrap()); back.setOnClickListener(v->finish());
        installPage(root);
    }

    private void addAction(LinearLayout root,String icon,String title,String subtitle,Class<?> target) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(15),dp(14),dp(14),dp(14)); card.setBackground(round(Color.WHITE,"#E3E9F1",21)); card.setElevation(dp(1));
        LinearLayout.LayoutParams cp=matchWrap(); cp.bottomMargin=dp(8); root.addView(card,cp);
        TextView badge=text(icon,17,BLUE,true); badge.setGravity(Gravity.CENTER); badge.setBackground(round(Color.rgb(232,241,252),"#E8F1FC",15));
        card.addView(badge,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout copy=new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL); copy.setPadding(dp(12),0,dp(6),0);
        copy.addView(text(title,15,BLUE,true)); copy.addView(text(subtitle,12,MUTED,false)); card.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=text("›",25,BLUE,true); arrow.setGravity(Gravity.CENTER); card.addView(arrow,new LinearLayout.LayoutParams(dp(25),-2));
        card.setClickable(true); card.setFocusable(true);
        card.setOnClickListener(v->{Intent intent=new Intent(this,target); intent.putExtra("admin_access_token",accessToken); intent.putExtra("account_number",account); intent.putExtra("display_name",name); startActivity(intent); overridePendingTransition(R.anim.activity_enter,R.anim.activity_exit);});
        card.setOnTouchListener((v,event)->{if(event.getAction()==MotionEvent.ACTION_DOWN)v.animate().scaleX(.98f).scaleY(.98f).setDuration(90).start();else if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(170).setInterpolator(new DecelerateInterpolator()).start();return false;});
    }
}
