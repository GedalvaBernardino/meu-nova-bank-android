package br.com.meunovabank.admin;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

abstract class AdminNativeActivity extends Activity {
    protected static final String BLUE="#102B50", RED="#D62839", GREEN="#16834A", MUTED="#63748A", INK="#24354D";
    private static final int SURFACE = Color.WHITE;
    private static final int BORDER = Color.rgb(224, 232, 241);
    protected String accessToken="";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor(BLUE));
        getWindow().setNavigationBarColor(Color.parseColor(BLUE));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        accessToken=getIntent().getStringExtra("admin_access_token");
        if(accessToken==null)accessToken="";
    }

    protected LinearLayout page() {
        AnimatedColumn root = new AnimatedColumn(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(30));
        root.setBackgroundColor(Color.rgb(244,247,251));
        root.setClipToPadding(false);
        return root;
    }

    protected void installPage(LinearLayout root) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(Color.rgb(244,247,251));
        scroll.addView(root);
        setContentView(scroll);
    }

    protected TextView text(String value,int size,String color,boolean bold) {
        TextView t=new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.parseColor(color));
        t.setIncludeFontPadding(false); t.setLineSpacing(dp(2),1f);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }

    protected Button button(String label,String color) {
        Button b=new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(50)); b.setPadding(dp(16),dp(5),dp(16),dp(5));
        b.setBackground(ripple(Color.parseColor(color),dp(17),Color.argb(36,255,255,255),Color.TRANSPARENT));
        b.setElevation(dp(1));
        if(Build.VERSION.SDK_INT>=21)b.setStateListAnimator(null);
        pressScale(b);
        return b;
    }

    protected EditText field(String hint,int inputType) {
        EditText e=new EditText(this);
        e.setSingleLine(true); e.setHint(hint); e.setHintTextColor(Color.rgb(129,145,164));
        e.setTextColor(Color.parseColor(INK)); e.setInputType(inputType); e.setTextSize(15);
        e.setPadding(dp(15),dp(8),dp(15),dp(8)); e.setMinHeight(dp(52));
        e.setBackground(ripple(SURFACE,dp(16),Color.argb(22,16,43,80),BORDER));
        e.setOnFocusChangeListener((v,focused)->e.setBackground(ripple(SURFACE,dp(16),Color.argb(22,16,43,80),Color.parseColor(focused?BLUE:"#D8E0EA"))));
        return e;
    }

    protected GradientDrawable round(int fill,String stroke,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(Math.min(24,Math.max(16,radius+4))));
        if(stroke!=null&&!stroke.isEmpty())d.setStroke(dp(1),Color.parseColor(stroke));
        return d;
    }

    protected LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,dp(6),0,dp(6)); return p;
    }

    protected int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+0.5f);}
    protected JSONObject adminRequest(JSONObject body)throws Exception{return AdminApi.request("/functions/v1/admin-users",body,accessToken);}
    protected void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    protected String money(String raw){try{double value=Double.parseDouble(raw);DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("pt","BR"));return new DecimalFormat("R$ #,##0.00",s).format(value);}catch(Exception e){return "R$ 0,00";}}

    @Override public void finish() {
        super.finish();
        overridePendingTransition(R.anim.activity_return,R.anim.activity_close_exit);
    }

    private android.graphics.drawable.Drawable ripple(int fill,int radius,int rippleColor,int strokeColor) {
        GradientDrawable content=round(fill,strokeColor==Color.TRANSPARENT?null:colorHex(strokeColor),Math.max(1,Math.round(radius/getResources().getDisplayMetrics().density)));
        if(Build.VERSION.SDK_INT>=21)return new RippleDrawable(ColorStateList.valueOf(rippleColor),content,null);
        return content;
    }

    private String colorHex(int color){return String.format(Locale.ROOT,"#%06X",(0xFFFFFF&color));}

    private void pressScale(View view) {
        view.setOnTouchListener((v,event)->{
            if(event.getAction()==MotionEvent.ACTION_DOWN)v.animate().scaleX(.975f).scaleY(.975f).setDuration(100).setInterpolator(new DecelerateInterpolator()).start();
            else if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new DecelerateInterpolator()).start();
            return false;
        });
    }

    private final class AnimatedColumn extends LinearLayout {
        AnimatedColumn(Activity context){super(context);}
        @Override public void addView(View child,int index,ViewGroup.LayoutParams params){
            super.addView(child,index,params);
            int position=Math.max(0,getChildCount()-1);
            child.setAlpha(0f); child.setTranslationY(dp(8));
            child.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(position*16L,180L)).setDuration(250L).setInterpolator(new DecelerateInterpolator()).start();
        }
    }
}
