package br.com.meunovabank.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Painel administrativo de protótipo. A autorização é sempre validada no servidor. */
public final class AdminActivity extends Activity {
    private static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private static final String KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private static final String BLUE = "#102B50", RED = "#D62839", GREEN = "#16834A", INK = "#24354D", MUTED = "#63748A";
    private String accessToken = "";
    private final List<JSONObject> users = new ArrayList<>();
    private LinearLayout cards;
    private EditText search;
    private TextView hiddenToggle;
    private TextView status;
    private boolean showHidden = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.parseColor(BLUE));
        getWindow().setNavigationBarColor(Color.parseColor(BLUE));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if (CredentialStore.hasSaved(this)) {
            showLogin("Verificando login salvo…");
            attemptSavedLogin();
        } else showLogin("");
    }

    @Override protected void onResume() {
        super.onResume();
        if (!accessToken.isEmpty() && cards != null) reload();
    }

    private void showLogin(String message) {
        LinearLayout page = page();
        TextView brand = text("MEU NOVA BANK", 22, BLUE, true); brand.setGravity(Gravity.CENTER);
        page.addView(brand, matchWrap());
        TextView subtitle = text("PAINEL ADMINISTRATIVO", 13, RED, true); subtitle.setGravity(Gravity.CENTER);
        page.addView(subtitle, matchWrap());
        addGap(page, 20);
        TextView info = text("Acesso restrito a contas autorizadas pelo administrador do Supabase.", 14, MUTED, false);
        page.addView(info, matchWrap()); addGap(page, 14);
        EditText account = field("Número da conta (6 dígitos)", InputType.TYPE_CLASS_NUMBER);
        account.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        EditText password = field("Senha (8 dígitos)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        password.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(8)});
        CredentialStore.Credentials saved = CredentialStore.read(this);
        if (saved != null) { account.setText(saved.account); password.setText(saved.password); }
        page.addView(account, matchWrap()); page.addView(password, matchWrap());
        CheckBox remember = new CheckBox(this);
        remember.setText("Salvar login e senha neste aparelho");
        remember.setTextSize(13); remember.setTextColor(Color.parseColor(BLUE));
        remember.setChecked(saved != null);
        page.addView(remember, matchWrap());
        TextView secureNote = text("Quando ativado, os dados ficam criptografados pelo Android Keystore; a senha não é salva em texto aberto.", 11, MUTED, false);
        page.addView(secureNote, matchWrap());
        Button enter = button("Entrar", BLUE); page.addView(enter, matchWrap());
        TextView statusView = text(message, 13, message.isEmpty() ? MUTED : RED, false); page.addView(statusView, matchWrap());
        TextView note = text("Protótipo: os saldos exibidos são demonstrativos e não representam dinheiro real.", 12, MUTED, false); page.addView(note, matchWrap());
        enter.setEnabled(!message.startsWith("Verificando login salvo"));
        enter.setOnClickListener(v -> {
            String a = account.getText().toString().trim(), p = password.getText().toString();
            boolean keep = remember.isChecked();
            password.setText("");
            if (!a.matches("\\d{6}") || !p.matches("\\d{8}")) { statusView.setText("Informe conta com 6 dígitos e senha com 8 dígitos."); return; }
            enter.setEnabled(false); statusView.setText("Validando acesso...");
            new Thread(() -> {
                try {
                    LoginResult result = authenticate(a, p);
                    boolean stored = true;
                    if (keep) stored = CredentialStore.save(this, a, p);
                    else CredentialStore.clear(this);
                    if (keep && !stored) CredentialStore.clear(this);
                    final boolean credentialsStored = stored;
                    runOnUiThread(() -> {
                        accessToken = result.token; users.clear(); users.addAll(result.users);
                        showDashboard();
                        if (keep && !credentialsStored) toast("Acesso confirmado, mas não foi possível salvar o login com segurança neste aparelho.");
                    });
                } catch (Exception ex) {
                    String m = ex.getMessage() != null && ex.getMessage().contains("403") ? "Esta conta ainda não tem acesso administrativo." : "Não foi possível entrar. Confira os dados ou a autorização administrativa.";
                    runOnUiThread(() -> { enter.setEnabled(true); statusView.setText(m); });
                }
            }, "nova-admin-login").start();
        });
        setContentView(wrap(page));
    }

    private static final class LoginResult {
        final String token; final List<JSONObject> users;
        LoginResult(String token, List<JSONObject> users) { this.token=token; this.users=users; }
    }

    private LoginResult authenticate(String account, String password) throws Exception {
        JSONObject login = new JSONObject(); login.put("account", account); login.put("password", password);
        JSONObject session = request("/functions/v1/account-login", login, null);
        String token = session.optString("access_token", "");
        if (token.isEmpty()) throw new Exception("Login não autorizado.");
        JSONObject response = request("/functions/v1/admin-users", new JSONObject().put("action", "list"), token);
        JSONArray array = response.optJSONArray("users");
        if (array == null) throw new Exception("Resposta administrativa inválida.");
        List<JSONObject> loaded = new ArrayList<>();
        for (int i=0; i<array.length(); i++) loaded.add(array.getJSONObject(i));
        return new LoginResult(token, loaded);
    }

    private void attemptSavedLogin() {
        CredentialStore.Credentials saved = CredentialStore.read(this);
        if (saved == null) { showLogin("O login salvo não pôde ser lido; entre novamente."); return; }
        new Thread(() -> {
            try {
                LoginResult result = authenticate(saved.account, saved.password);
                runOnUiThread(() -> {
                    accessToken = result.token; users.clear(); users.addAll(result.users);
                    showDashboard(); toast("Login salvo restaurado com segurança.");
                });
            } catch (Exception ex) {
                boolean rejected = isDefinitiveLoginRejection(ex);
                if (rejected) CredentialStore.clear(this);
                runOnUiThread(() -> showLogin(rejected ? "O login salvo não foi aceito. Entre novamente e salve os dados atualizados." : "Não foi possível verificar o login salvo agora. Confira a conexão e entre novamente."));
            }
        }, "nova-admin-auto-login").start();
    }

    private boolean isDefinitiveLoginRejection(Exception ex) {
        String m = ex.getMessage() == null ? "" : ex.getMessage();
        return m.contains("HTTP 400") || m.contains("HTTP 401") || m.contains("HTTP 403") || m.contains("LOGIN_INVALID");
    }

    private void showDashboard() {
        LinearLayout page = page();
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Usuários e contas", 21, BLUE, true); top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        Button transfers = button("Recebimentos", GREEN); top.addView(transfers, wrapParams());
        Button refresh = button("Atualizar", BLUE); top.addView(refresh, wrapParams());
        page.addView(top, matchWrap());
        transfers.setOnClickListener(v -> openIncomingTransfers());
        Button featureSettings = button("Funções do usuário", BLUE); page.addView(featureSettings, matchWrap());
        featureSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, FeatureVisibilityActivity.class);
            intent.putExtra("admin_access_token", accessToken);
            startActivity(intent);
        });
        TextView note = text("Saldo demonstrativo • ocultar apenas tira o cadastro desta lista • excluir encerra sem apagar o histórico", 12, MUTED, false);
        page.addView(note, matchWrap());
        search = field("Buscar por nome ou conta", InputType.TYPE_CLASS_TEXT); page.addView(search, matchWrap());
        hiddenToggle = text("Mostrar cadastros ocultos", 14, BLUE, true); hiddenToggle.setPadding(4,14,4,14); page.addView(hiddenToggle, matchWrap());
        status = text("", 13, MUTED, false); page.addView(status, matchWrap());
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.addView(cards);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        refresh.setOnClickListener(v -> reload());
        if (CredentialStore.hasSaved(this)) {
            TextView savedStatus = text("Login e senha salvos criptografados neste aparelho.", 12, GREEN, true);
            page.addView(savedStatus, matchWrap());
            Button clearSaved = button("Sair do login salvo", RED); page.addView(clearSaved, matchWrap());
            clearSaved.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Sair do login salvo?")
                    .setMessage("A conta e a senha criptografadas serão removidas deste aparelho, e a sessão atual será encerrada.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Sair e remover", (dialog, which) -> {
                        CredentialStore.clear(this); accessToken = ""; users.clear();
                        showLogin("Login salvo removido. Entre novamente.");
                    }).show());
        }
        Button logout = button("Sair da sessão", BLUE); page.addView(logout, matchWrap());
        logout.setOnClickListener(v -> {
            accessToken = ""; users.clear();
            showLogin(CredentialStore.hasSaved(this) ? "Sessão encerrada. O login continua salvo neste aparelho." : "");
        });
        hiddenToggle.setOnClickListener(v -> { showHidden = !showHidden; hiddenToggle.setText(showHidden ? "Ocultar cadastros ocultos" : "Mostrar cadastros ocultos"); renderCards(); });
        search.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderCards();} public void afterTextChanged(Editable e){} });
        renderCards(); setContentView(wrap(page));
    }

    private void openIncomingTransfers() {
        Intent intent = new Intent(this, AdminIncomingTransfersActivity.class);
        intent.putExtra("admin_access_token", accessToken);
        startActivity(intent);
    }

    private void openUserScreen(Class<? extends Activity> screen, String account, String name, String balance, boolean hidden) {
        Intent intent = new Intent(this, screen);
        intent.putExtra("admin_access_token", accessToken);
        intent.putExtra("account_number", account);
        intent.putExtra("display_name", name);
        intent.putExtra("available_balance", balance);
        intent.putExtra("is_hidden", hidden);
        startActivity(intent);
    }

    private void reload() {
        status.setText("Atualizando lista...");
        new Thread(() -> {
            try {
                JSONArray array = request("/functions/v1/admin-users", new JSONObject().put("action", "list"), accessToken).optJSONArray("users");
                if (array == null) throw new Exception();
                users.clear(); for (int i=0; i<array.length(); i++) users.add(array.getJSONObject(i));
                runOnUiThread(() -> { status.setText("Lista atualizada."); renderCards(); });
            } catch (Exception ex) { runOnUiThread(() -> status.setText("Não foi possível atualizar. Tente novamente.")); }
        }, "nova-admin-list").start();
    }

    private void renderCards() {
        if (cards == null) return;
        cards.removeAllViews();
        String term = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int count = 0;
        for (JSONObject u : users) {
            boolean hidden = u.optBoolean("is_hidden", false);
            String account = u.optString("account_number", ""), name = u.optString("display_name", ""), state = u.optString("account_status", "active");
            if (hidden && !showHidden) continue;
            if (!term.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(term) && !account.contains(term)) continue;
            count++;
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(15),dp(13),dp(15),dp(13));
            card.setBackground(round(Color.WHITE, "#D8E0EA", 14));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0,dp(6),0,dp(7)); cards.addView(card, cp);
            TextView who = text(name.isEmpty() ? "Sem nome" : name, 17, BLUE, true); card.addView(who, matchWrap());
            card.addView(text("Conta: " + account + "   •   " + stateLabel(state) + (hidden ? "   •   OCULTA" : ""), 13, MUTED, false), matchWrap());
            card.addView(text("Saldo: " + money(u.optString("available_balance", "0.00")), 17, GREEN, true), matchWrap());
            LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL); card.addView(actions, matchWrap());
            Button edit = button("Editar", BLUE), hide = button(hidden ? "Reexibir" : "Ocultar", "#50647C"), close = button("Excluir / encerrar", RED);
            actions.addView(edit, new LinearLayout.LayoutParams(0,dp(44),1)); actions.addView(hide, new LinearLayout.LayoutParams(0,dp(44),1)); actions.addView(close, new LinearLayout.LayoutParams(0,dp(44),1));
            String currentBalance = u.optString("available_balance", "0.00");
            edit.setOnClickListener(v -> openUserScreen(AdminEditNameActivity.class, account, name, currentBalance, hidden));
            hide.setOnClickListener(v -> openUserScreen(AdminVisibilityActivity.class, account, name, currentBalance, hidden));
            close.setOnClickListener(v -> openUserScreen(AdminCloseUserActivity.class, account, name, currentBalance, hidden));
            LinearLayout balanceActions = new LinearLayout(this); balanceActions.setOrientation(LinearLayout.HORIZONTAL); card.addView(balanceActions, matchWrap());
            Button adjustBalance = button("Editar saldo", GREEN); balanceActions.addView(adjustBalance, new LinearLayout.LayoutParams(0, dp(44), 1));
            adjustBalance.setOnClickListener(v -> openUserScreen(AdminEditBalanceActivity.class, account, name, currentBalance, hidden));
            Button editAccount = button("Editar conta", BLUE); balanceActions.addView(editAccount, new LinearLayout.LayoutParams(0, dp(44), 1));
            editAccount.setOnClickListener(v -> openUserScreen(AdminEditAccountActivity.class, account, name, currentBalance, hidden));
        }
        if (count == 0) cards.addView(text(users.isEmpty() ? "Nenhum usuário cadastrado." : "Nenhum cadastro corresponde ao filtro atual.", 14, MUTED, false), matchWrap());
    }

    private JSONObject request(String path, JSONObject body, String token) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection)new URL(BASE + path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setDoOutput(true);
            c.setRequestProperty("apikey", KEY); c.setRequestProperty("Authorization", "Bearer " + (token == null || token.isEmpty() ? KEY : token)); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setRequestProperty("Cache-Control", "no-store");
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(data.length); try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String text=readAll(in);
            if(code<200||code>=300) throw new Exception("HTTP "+code+" "+text);
            return new JSONObject(text);
        } finally { if(c!=null)c.disconnect(); }
    }
    private String readAll(InputStream in) throws Exception { if(in==null)return ""; try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[2048];int n;while((n=src.read(b))!=-1){if(out.size()+n>65536)throw new Exception("Resposta muito grande");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);} }
    private String money(String raw) { try { double value=Double.parseDouble(raw); DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("pt","BR")); return new DecimalFormat("R$ #,##0.00",s).format(value); } catch(Exception e){return "R$ 0,00";} }
    private String stateLabel(String s) { if("closed".equals(s))return "ENCERRADA"; if("locked".equals(s))return "BLOQUEADA"; return "ATIVA"; }
    private LinearLayout page(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(18),dp(18),dp(16));l.setBackgroundColor(Color.rgb(244,247,251));return l;}
    private View wrap(View v){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(v);return s;}
    private TextView text(String value,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setPadding(0,dp(5),0,dp(5));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(type);e.setTextSize(15);e.setPadding(dp(12),dp(8),dp(12),dp(8));return e;}
    private Button button(String title,String color){Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(round(Color.parseColor(color),color,10));return b;}
    private GradientDrawable round(int fill,String stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.parseColor(stroke));return d;}
    private LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(4),0,dp(4));return p;}
    private LinearLayout.LayoutParams wrapParams(){return new LinearLayout.LayoutParams(-2,dp(44));}
    private void addGap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String msg){android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_LONG).show();}
}
