package br.com.meunovabank.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.Editable;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Painel administrativo de protótipo. A autorização é sempre validada no servidor. */
public final class AdminActivity extends Activity {
    private static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private static final String KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private static final String BLUE = "#102B50", RED = "#D62839", GREEN = "#16834A", INK = "#24354D", MUTED = "#63748A";
    private String accessToken = "";
    private final List<JSONObject> users = new ArrayList<>();
    private LinearLayout cards;
    private EditText search;
    private TextView hiddenToggle;
    private TextView status;
    private boolean showHidden = false;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.parseColor(BLUE));
        getWindow().setNavigationBarColor(Color.parseColor(BLUE));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        if (CredentialStore.hasSaved(this)) {
            showLogin("Verificando login salvo…");
            attemptSavedLogin();
        } else showLogin("");
    }

    @Override protected void onResume() {
        super.onResume();
        if (!accessToken.isEmpty() && cards != null) reload();
    }

    private void showLogin(String message) {
        LinearLayout page = page();
        LinearLayout brandRow = new LinearLayout(this); brandRow.setOrientation(LinearLayout.HORIZONTAL); brandRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView emblem = text("N", 23, "#FFFFFF", true); emblem.setGravity(Gravity.CENTER); emblem.setBackground(round(Color.parseColor(BLUE), BLUE, 18));
        brandRow.addView(emblem, new LinearLayout.LayoutParams(dp(54), dp(54)));
        LinearLayout brandCopy = new LinearLayout(this); brandCopy.setOrientation(LinearLayout.VERTICAL); brandCopy.setPadding(dp(13), 0, 0, 0);
        brandCopy.addView(text("MEU NOVA BANK", 21, BLUE, true));
        brandCopy.addView(text("PAINEL ADMINISTRATIVO", 11, RED, true));
        brandRow.addView(brandCopy, new LinearLayout.LayoutParams(0, -2, 1));
        page.addView(brandRow, matchWrap());
        addGap(page, 20);

        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(20),dp(20),dp(20),dp(18));
        panel.setBackground(round(Color.WHITE, "#E3E9F1", 23)); panel.setElevation(dp(2));
        page.addView(panel, matchWrap());
        panel.addView(text("Acesse com segurança", 20, BLUE, true), matchWrap());
        panel.addView(text("Somente contas autorizadas podem entrar neste painel.", 13, MUTED, false), matchWrap());
        EditText account = field("Número da conta (6 dígitos)", InputType.TYPE_CLASS_NUMBER);
        account.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        EditText password = field("Senha (8 dígitos)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        password.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(8)});
        CredentialStore.Credentials saved = CredentialStore.read(this);
        if (saved != null) { account.setText(saved.account); password.setText(saved.password); }
        panel.addView(account, matchWrap()); panel.addView(password, matchWrap());
        CheckBox remember = new CheckBox(this);
        remember.setText("Salvar o acesso neste aparelho"); remember.setTextSize(13); remember.setTextColor(Color.parseColor(BLUE)); remember.setChecked(saved != null);
        panel.addView(remember, matchWrap());
        TextView secureNote = text("Se ativado, o acesso fica protegido pelo Android Keystore.", 11, MUTED, false); panel.addView(secureNote, matchWrap());
        Button enter = button("Entrar no painel", BLUE); panel.addView(enter, matchWrap());
        TextView statusView = text(message, 13, message.isEmpty() ? MUTED : RED, false); panel.addView(statusView, matchWrap());
        TextView note = text("Protótipo: os saldos exibidos são demonstrativos e não representam dinheiro real.", 12, MUTED, false); page.addView(note, matchWrap());
        enter.setEnabled(!message.startsWith("Verificando login salvo"));
        enter.setOnClickListener(v -> {
            String a = account.getText().toString().trim(), p = password.getText().toString();
            boolean keep = remember.isChecked();
            password.setText("");
            if (!a.matches("\\d{6}") || !p.matches("\\d{8}")) { statusView.setText("Informe conta com 6 dígitos e senha com 8 dígitos."); return; }
            enter.setEnabled(false); statusView.setText("Validando acesso…");
            new Thread(() -> {
                try {
                    LoginResult result = authenticate(a, p);
                    boolean stored = true;
                    if (keep) stored = CredentialStore.save(this, a, p);
                    else CredentialStore.clear(this);
                    if (keep && !stored) CredentialStore.clear(this);
                    final boolean credentialsStored = stored;
                    runOnUiThread(() -> {
                        accessToken = result.token; users.clear(); users.addAll(result.users);
                        showDashboard();
                        if (keep && !credentialsStored) toast("Acesso confirmado, mas não foi possível salvar o login com segurança neste aparelho.");
                    });
                } catch (Exception ex) {
                    String m = ex.getMessage() != null && ex.getMessage().contains("403") ? "Esta conta ainda não tem acesso administrativo." : "Não foi possível entrar. Confira os dados ou a autorização administrativa.";
                    runOnUiThread(() -> { enter.setEnabled(true); statusView.setText(m); });
                }
            }, "nova-admin-login").start();
        });
        setContentView(wrap(page));
    }

    private static final class LoginResult {
        final String token; final List<JSONObject> users;
        LoginResult(String token, List<JSONObject> users) { this.token=token; this.users=users; }
    }

    private LoginResult authenticate(String account, String password) throws Exception {
        JSONObject login = new JSONObject(); login.put("account", account); login.put("password", password);
        JSONObject session = request("/functions/v1/account-login", login, null);
        String token = session.optString("access_token", "");
        if (token.isEmpty()) throw new Exception("Login não autorizado.");
        JSONObject response = request("/functions/v1/admin-users", new JSONObject().put("action", "list"), token);
        JSONArray array = response.optJSONArray("users");
        if (array == null) throw new Exception("Resposta administrativa inválida.");
        List<JSONObject> loaded = new ArrayList<>();
        for (int i=0; i<array.length(); i++) loaded.add(array.getJSONObject(i));
        return new LoginResult(token, loaded);
    }

    private void attemptSavedLogin() {
        CredentialStore.Credentials saved = CredentialStore.read(this);
        if (saved == null) { showLogin("O login salvo não pôde ser lido; entre novamente."); return; }
        new Thread(() -> {
            try {
                LoginResult result = authenticate(saved.account, saved.password);
                runOnUiThread(() -> {
                    accessToken = result.token; users.clear(); users.addAll(result.users);
                    showDashboard(); toast("Login salvo restaurado com segurança.");
                });
            } catch (Exception ex) {
                boolean rejected = isDefinitiveLoginRejection(ex);
                if (rejected) CredentialStore.clear(this);
                runOnUiThread(() -> showLogin(rejected ? "O login salvo não foi aceito. Entre novamente e salve os dados atualizados." : "Não foi possível verificar o login salvo agora. Confira a conexão e entre novamente."));
            }
        }, "nova-admin-auto-login").start();
    }

    private boolean isDefinitiveLoginRejection(Exception ex) {
        String m = ex.getMessage() == null ? "" : ex.getMessage();
        return m.contains("HTTP 400") || m.contains("HTTP 401") || m.contains("HTTP 403") || m.contains("LOGIN_INVALID");
    }

    private void showDashboard() {
        LinearLayout page = page();
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(15),dp(13),dp(15),dp(13)); top.setBackground(round(Color.WHITE,"#E3E9F1",22)); top.setElevation(dp(2));
        TextView emblem = text("N",19,"#FFFFFF",true); emblem.setGravity(Gravity.CENTER); emblem.setBackground(round(Color.parseColor(BLUE),BLUE,16));
        top.addView(emblem,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout heading = new LinearLayout(this); heading.setOrientation(LinearLayout.VERTICAL); heading.setPadding(dp(11),0,dp(5),0);
        heading.addView(text("ADMINISTRADOR",10,RED,true)); heading.addView(text("Usuários e contas",18,BLUE,true));
        top.addView(heading,new LinearLayout.LayoutParams(0,-2,1)); page.addView(top,matchWrap());
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setGravity(Gravity.CENTER_VERTICAL);
        Button transfers = button("Recebimentos", GREEN); Button refresh = button("Atualizar", BLUE);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(0,dp(48),1); actionLp.setMargins(0,0,dp(7),0); actions.addView(transfers,actionLp);
        LinearLayout.LayoutParams refreshLp = new LinearLayout.LayoutParams(0,dp(48),1); refreshLp.setMargins(dp(7),0,0,0); actions.addView(refresh,refreshLp);
        page.addView(actions,matchWrap());
        transfers.setOnClickListener(v -> openIncomingTransfers());
        Button featureSettings = button("Configurar funções do usuário", BLUE); page.addView(featureSettings, matchWrap());
        featureSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, FeatureVisibilityActivity.class);
            intent.putExtra("admin_access_token", accessToken);
            openWithTransition(intent);
        });
        TextView note = text("Saldo demonstrativo • ocultar apenas tira o cadastro desta lista • excluir encerra sem apagar o histórico", 12, MUTED, false);
        page.addView(note, matchWrap());
        search = field("Buscar por nome ou conta", InputType.TYPE_CLASS_TEXT); page.addView(search, matchWrap());
        hiddenToggle = text("Mostrar cadastros ocultos", 13, BLUE, true); hiddenToggle.setPadding(dp(14),dp(11),dp(14),dp(11)); hiddenToggle.setBackground(round(Color.WHITE,"#E3E9F1",16)); hiddenToggle.setGravity(Gravity.CENTER_VERTICAL); page.addView(hiddenToggle, matchWrap());
        status = text("", 13, MUTED, false); page.addView(status, matchWrap());
        cards = new LinearLayout(this); cards.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.addView(cards);
        page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        refresh.setOnClickListener(v -> reload());
        if (CredentialStore.hasSaved(this)) {
            TextView savedStatus = text("Login e senha salvos criptografados neste aparelho.", 12, GREEN, true);
            page.addView(savedStatus, matchWrap());
            Button clearSaved = button("Sair do login salvo", RED); page.addView(clearSaved, matchWrap());
            clearSaved.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Sair do login salvo?")
                    .setMessage("A conta e a senha criptografadas serão removidas deste aparelho, e a sessão atual será encerrada.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Sair e remover", (dialog, which) -> {
                        CredentialStore.clear(this); accessToken = ""; users.clear();
                        showLogin("Login salvo removido. Entre novamente.");
                    }).show());
        }
        Button logout = button("Sair da sessão", BLUE); page.addView(logout, matchWrap());
        logout.setOnClickListener(v -> {
            accessToken = ""; users.clear();
            showLogin(CredentialStore.hasSaved(this) ? "Sessão encerrada. O login continua salvo neste aparelho." : "");
        });
        hiddenToggle.setOnClickListener(v -> { showHidden = !showHidden; hiddenToggle.setText(showHidden ? "Ocultar cadastros ocultos" : "Mostrar cadastros ocultos"); renderCards(); });
        search.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderCards();} public void afterTextChanged(Editable e){} });
        renderCards(); setContentView(wrap(page));
    }

    private void openIncomingTransfers() {
        Intent intent = new Intent(this, AdminIncomingTransfersActivity.class);
        intent.putExtra("admin_access_token", accessToken);
        openWithTransition(intent);
    }

    private void openUserScreen(Class<? extends Activity> screen, String account, String name, String balance, boolean hidden) {
        Intent intent = new Intent(this, screen);
        intent.putExtra("admin_access_token", accessToken);
        intent.putExtra("account_number", account);
        intent.putExtra("display_name", name);
        intent.putExtra("available_balance", balance);
        intent.putExtra("is_hidden", hidden);
        openWithTransition(intent);
    }

    private void reload() {
        status.setText("Atualizando lista...");
        new Thread(() -> {
            try {
                JSONArray array = request("/functions/v1/admin-users", new JSONObject().put("action", "list"), accessToken).optJSONArray("users");
                if (array == null) throw new Exception();
                users.clear(); for (int i=0; i<array.length(); i++) users.add(array.getJSONObject(i));
                runOnUiThread(() -> { status.setText("Lista atualizada."); renderCards(); });
            } catch (Exception ex) { runOnUiThread(() -> status.setText("Não foi possível atualizar. Tente novamente.")); }
        }, "nova-admin-list").start();
    }

    private void renderCards() {
        if (cards == null) return;
        cards.removeAllViews();
        String term = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        int count = 0;
        for (JSONObject u : users) {
            boolean hidden = u.optBoolean("is_hidden", false);
            String account = u.optString("account_number", ""), name = u.optString("display_name", ""), state = u.optString("account_status", "active");
            if (hidden && !showHidden) continue;
            if (!term.isEmpty() && !name.toLowerCase(Locale.ROOT).contains(term) && !account.contains(term)) continue;
            count++;
            String currentBalance = u.optString("available_balance", "0.00");
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(16),dp(16),dp(16),dp(14));
            card.setBackground(round(Color.WHITE, "#E3E9F1", 22)); card.setElevation(dp(2)); card.setClipToOutline(true);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.setMargins(0,dp(6),0,dp(9)); cards.addView(card, cp);
            animateIn(card, count - 1);

            LinearLayout identity = new LinearLayout(this); identity.setOrientation(LinearLayout.HORIZONTAL); identity.setGravity(Gravity.CENTER_VERTICAL); card.addView(identity,matchWrap());
            TextView avatar = text(name.isEmpty()?"N":name.substring(0,1).toUpperCase(Locale.ROOT),16,BLUE,true); avatar.setGravity(Gravity.CENTER); avatar.setBackground(round(Color.rgb(232,241,252),"#E8F1FC",16));
            identity.addView(avatar,new LinearLayout.LayoutParams(dp(46),dp(46)));
            LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL); copy.setPadding(dp(11),0,dp(6),0);
            TextView who = text(name.isEmpty() ? "Sem nome" : name, 16, BLUE, true); copy.addView(who,matchWrap());
            TextView meta = text("Conta " + account + "  ·  " + stateLabel(state), 12, MUTED, false); copy.addView(meta,matchWrap());
            identity.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
            TextView stateChip = text(hidden?"OCULTA":"ATIVA",9,hidden?MUTED:GREEN,true); stateChip.setGravity(Gravity.CENTER); stateChip.setPadding(dp(9),dp(6),dp(9),dp(6)); stateChip.setBackground(round(hidden?Color.rgb(238,241,245):Color.rgb(232,246,238),hidden?"#E5E9EE":"#D9EFE2",14)); identity.addView(stateChip,new LinearLayout.LayoutParams(-2,-2));

            LinearLayout balance = new LinearLayout(this); balance.setOrientation(LinearLayout.VERTICAL); balance.setPadding(dp(13),dp(10),dp(13),dp(10)); balance.setBackground(round(Color.rgb(245,248,252),"#EEF2F7",15));
            LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin=dp(8); bp.bottomMargin=dp(8); card.addView(balance,bp);
            balance.addView(text("SALDO DEMONSTRATIVO",10,MUTED,true),new LinearLayout.LayoutParams(-1,-2));
            TextView amount = text(money(currentBalance),19,GREEN,true); LinearLayout.LayoutParams amountLp=matchWrap(); amountLp.topMargin=dp(2); balance.addView(amount,amountLp);

            LinearLayout rowOne = new LinearLayout(this); rowOne.setOrientation(LinearLayout.HORIZONTAL); card.addView(rowOne,matchWrap());
            Button edit = button("Funções",BLUE), hide = button(hidden ? "Reexibir" : "Ocultar", "#50647C");
            LinearLayout.LayoutParams first = new LinearLayout.LayoutParams(0,dp(46),1); first.setMargins(0,0,dp(5),0); rowOne.addView(edit,first);
            LinearLayout.LayoutParams second = new LinearLayout.LayoutParams(0,dp(46),1); second.setMargins(dp(5),0,0,0); rowOne.addView(hide,second);
            LinearLayout rowTwo = new LinearLayout(this); rowTwo.setOrientation(LinearLayout.HORIZONTAL); card.addView(rowTwo,matchWrap());
            Button adjustBalance = button("Editar saldo",GREEN), editAccount = button("Editar conta",BLUE);
            LinearLayout.LayoutParams third = new LinearLayout.LayoutParams(0,dp(46),1); third.setMargins(0,0,dp(5),0); rowTwo.addView(adjustBalance,third);
            LinearLayout.LayoutParams fourth = new LinearLayout.LayoutParams(0,dp(46),1); fourth.setMargins(dp(5),0,0,0); rowTwo.addView(editAccount,fourth);
            Button close = button("Encerrar conta",RED); card.addView(close,matchWrap());

            edit.setOnClickListener(v -> openUserScreen(AdminUserFunctionsActivity.class, account, name, currentBalance, hidden));
            hide.setOnClickListener(v -> openUserScreen(AdminVisibilityActivity.class, account, name, currentBalance, hidden));
            close.setOnClickListener(v -> openUserScreen(AdminCloseUserActivity.class, account, name, currentBalance, hidden));
            adjustBalance.setOnClickListener(v -> openUserScreen(AdminEditBalanceActivity.class, account, name, currentBalance, hidden));
            editAccount.setOnClickListener(v -> openUserScreen(AdminEditAccountActivity.class, account, name, currentBalance, hidden));
        }
        if (count == 0) cards.addView(text(users.isEmpty() ? "Nenhum usuário cadastrado." : "Nenhum cadastro corresponde ao filtro atual.", 14, MUTED, false), matchWrap());
    }

    private JSONObject request(String path, JSONObject body, String token) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection)new URL(BASE + path).openConnection(); c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setDoOutput(true);
            c.setRequestProperty("apikey", KEY); c.setRequestProperty("Authorization", "Bearer " + (token == null || token.isEmpty() ? KEY : token)); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setRequestProperty("Cache-Control", "no-store");
            byte[] data = body.toString().getBytes(StandardCharsets.UTF_8); c.setFixedLengthStreamingMode(data.length); try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream(); String text=readAll(in);
            if(code<200||code>=300) throw new Exception("HTTP "+code+" "+text);
            return new JSONObject(text);
        } finally { if(c!=null)c.disconnect(); }
    }
    private String readAll(InputStream in) throws Exception { if(in==null)return ""; try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[2048];int n;while((n=src.read(b))!=-1){if(out.size()+n>65536)throw new Exception("Resposta muito grande");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);} }
    private String money(String raw) { try { double value=Double.parseDouble(raw); DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("pt","BR")); return new DecimalFormat("R$ #,##0.00",s).format(value); } catch(Exception e){return "R$ 0,00";} }
    private String stateLabel(String s) { if("closed".equals(s))return "ENCERRADA"; if("locked".equals(s))return "BLOQUEADA"; return "ATIVA"; }
    private LinearLayout page(){AnimatedColumn l=new AnimatedColumn(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(20),dp(20),dp(20),dp(28));l.setBackgroundColor(Color.rgb(244,247,251));l.setClipToPadding(false);return l;}
    private View wrap(View v){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setClipToPadding(false);s.setBackgroundColor(Color.rgb(244,247,251));s.addView(v);return s;}
    private TextView text(String value,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setIncludeFontPadding(false);t.setLineSpacing(dp(2),1f);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private EditText field(String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(Color.rgb(129,145,164));e.setTextColor(Color.parseColor(INK));e.setInputType(type);e.setTextSize(15);e.setPadding(dp(15),dp(8),dp(15),dp(8));e.setMinHeight(dp(52));e.setBackground(round(Color.WHITE,"#D8E0EA",16));e.setOnFocusChangeListener((v,focused)->e.setBackground(round(Color.WHITE,focused?BLUE:"#D8E0EA",16)));return e;}
    private Button button(String title,String color){Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setAllCaps(false);b.setMinHeight(dp(48));b.setPadding(dp(12),dp(5),dp(12),dp(5));GradientDrawable shape=round(Color.parseColor(color),color,17);if(android.os.Build.VERSION.SDK_INT>=21)b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(38,255,255,255)),shape,null));else b.setBackground(shape);b.setElevation(dp(1));pressScale(b);return b;}
    private GradientDrawable round(int fill,String stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=null&&!stroke.isEmpty())d.setStroke(dp(1),Color.parseColor(stroke));return d;}
    private LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));return p;}
    private LinearLayout.LayoutParams wrapParams(){return new LinearLayout.LayoutParams(-2,dp(48));}
    private void addGap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String msg){android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_LONG).show();}
    private void openWithTransition(Intent intent){startActivity(intent);overridePendingTransition(R.anim.activity_enter,R.anim.activity_exit);}
    private void pressScale(View view){view.setOnTouchListener((v,event)->{if(event.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.975f).scaleY(.975f).setDuration(100).start();else if(event.getAction()==android.view.MotionEvent.ACTION_UP||event.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(180).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();return false;});}
    private void animateIn(View view,int index){view.setAlpha(0f);view.setTranslationY(dp(10));view.post(()->view.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(index*35L,210L)).setDuration(260L).setInterpolator(new android.view.animation.DecelerateInterpolator()).start());}
    private final class AnimatedColumn extends LinearLayout{AnimatedColumn(Activity context){super(context);}@Override public void addView(View child,int index,android.view.ViewGroup.LayoutParams params){super.addView(child,index,params);int n=Math.max(0,getChildCount()-1);child.setAlpha(0f);child.setTranslationY(dp(8));child.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(n*16L,180L)).setDuration(250L).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();}}
}
