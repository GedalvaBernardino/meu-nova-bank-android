package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

/** Dedicated, audited administrator-role screen for one customer account. */
public final class AdminRoleActivity extends AdminNativeActivity {
    private String account="", name="";
    private TextView status, roleValue;
    private Button change;
    private boolean isAdmin=false, loaded=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        account=getIntent().getStringExtra("account_number"); if(account==null)account="";
        name=getIntent().getStringExtra("display_name"); if(name==null)name="Usuário";
        LinearLayout root=page();
        root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());
        root.addView(text("Permissões",24,BLUE,true),matchWrap());
        root.addView(text(name+"  ·  Conta "+account,14,INK,true),matchWrap());
        root.addView(text("Controle se esta conta pode acessar o painel administrativo.",13,MUTED,false),matchWrap());
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(17),dp(15),dp(17),dp(15)); card.setBackground(round(android.graphics.Color.WHITE,"#E3E9F1",21)); card.setElevation(dp(1)); root.addView(card,matchWrap());
        card.addView(text("Acesso atual",12,MUTED,true),matchWrap());
        roleValue=text("Verificando…",19,BLUE,true); card.addView(roleValue,matchWrap());
        status=text("Carregando permissão protegida…",13,MUTED,false); root.addView(status,matchWrap());
        change=button("Carregando…",BLUE); change.setEnabled(false); root.addView(change,matchWrap());
        root.addView(text("O servidor impede remover o próprio acesso e o último administrador. A promoção exige uma conta ativa e confirmada.",12,MUTED,false),matchWrap());
        Button back=button("Voltar",BLUE); root.addView(back,matchWrap()); back.setOnClickListener(v->finish());
        change.setOnClickListener(v->reviewChange());
        installPage(root); load();
    }

    private void load(){new Thread(()->{try{JSONObject request=new JSONObject();request.put("action","get_profile");request.put("account_number",account);JSONObject profile=adminRequest(request).getJSONObject("profile");runOnUiThread(()->{isAdmin=profile.optBoolean("is_admin",false);loaded=true;roleValue.setText(isAdmin?"Administrador":"Usuário");status.setText("Permissão carregada do servidor.");change.setText(isAdmin?"Remover acesso administrativo":"Conceder acesso administrativo");change.setEnabled(true);});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível consultar a permissão. Tente novamente."));}} ,"nova-admin-role-load").start();}

    private void reviewChange(){if(!loaded)return;boolean desired=!isAdmin;String title=desired?"Conceder acesso administrativo?":"Remover acesso administrativo?";String body=desired?"A conta poderá acessar o painel e executar as ações administrativas autorizadas.":"A conta perderá o acesso ao painel. O servidor preserva o último administrador e bloqueia a remoção do próprio acesso.";new AlertDialog.Builder(this).setTitle(title).setMessage("Conta "+account+"\n\n"+body).setNegativeButton("Revisar",null).setPositiveButton("Confirmar",(d,w)->save(desired)).show();}

    private void save(boolean desired){change.setEnabled(false);status.setText("Atualizando e registrando a permissão…");new Thread(()->{try{JSONObject request=new JSONObject();request.put("action","set_admin_role");request.put("account_number",account);request.put("is_admin",desired);JSONObject response=adminRequest(request);if(!response.optBoolean("ok",false))throw new Exception();boolean auditOk=response.optBoolean("audit_ok",false);runOnUiThread(()->{isAdmin=desired;roleValue.setText(isAdmin?"Administrador":"Usuário");status.setText(auditOk?"Permissão atualizada e registrada na auditoria.":"Permissão atualizada; a auditoria não pôde ser confirmada.");change.setText(isAdmin?"Remover acesso administrativo":"Conceder acesso administrativo");change.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{status.setText("O servidor recusou a alteração. Confira se a conta está ativa e se não é o último administrador.");change.setEnabled(true);});}},"nova-admin-role-save").start();}
}
