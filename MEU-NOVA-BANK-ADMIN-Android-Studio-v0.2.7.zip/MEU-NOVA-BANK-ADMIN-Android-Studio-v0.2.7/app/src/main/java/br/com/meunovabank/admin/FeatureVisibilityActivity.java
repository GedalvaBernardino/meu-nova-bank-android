package br.com.meunovabank.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Administra, em uma Activity nativa, quais funções aparecem no menu de todos os clientes. */
public final class FeatureVisibilityActivity extends Activity {
    private static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private static final String KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private static final String BLUE = "#102B50", GREEN = "#16834A", RED = "#D62839", MUTED = "#63748A";
    private final List<Option> options = new ArrayList<>();
    private String accessToken = "";
    private LinearLayout list;
    private TextView status;
    private Button save;

    private static final class Option {
        final String key, label;
        boolean savedVisible;
        CheckBox check;
        Option(String key, String label, boolean visible) { this.key=key; this.label=label; this.savedVisible=visible; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor(BLUE));
        getWindow().setNavigationBarColor(Color.parseColor(BLUE));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        accessToken = getIntent().getStringExtra("admin_access_token");
        if (accessToken == null) accessToken = "";
        buildScreen();
        if (accessToken.isEmpty()) { status.setText("Sessão administrativa ausente. Entre novamente."); save.setEnabled(false); }
        else loadOptions();
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20),dp(20),dp(20),dp(18)); page.setBackgroundColor(Color.rgb(244,247,251)); page.setClipToPadding(false);
        LinearLayout brandRow = new LinearLayout(this); brandRow.setOrientation(LinearLayout.HORIZONTAL); brandRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView emblem = text("N",18,"#FFFFFF",true); emblem.setGravity(Gravity.CENTER); emblem.setBackground(round(Color.parseColor(BLUE),BLUE,16));
        brandRow.addView(emblem,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(dp(11),0,0,0);
        brand.addView(text("MEU NOVA BANK",16,BLUE,true)); brand.addView(text("PAINEL ADMINISTRATIVO",10,RED,true));
        brandRow.addView(brand,new LinearLayout.LayoutParams(0,-2,1)); page.addView(brandRow,matchWrap());
        LinearLayout heading = new LinearLayout(this); heading.setOrientation(LinearLayout.VERTICAL); heading.setPadding(0,dp(14),0,dp(5));
        heading.addView(text("Funções do usuário",23,BLUE,true));
        heading.addView(text("Escolha o que aparece na área do cliente.",13,MUTED,false)); page.addView(heading,matchWrap());
        TextView note = text("As opções marcadas ficam visíveis no app de todos os usuários. A alteração é sincronizada centralmente.",12,MUTED,false); page.addView(note,matchWrap());
        status = text("Carregando funções…",13,MUTED,false); page.addView(status,matchWrap());
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false); scroll.addView(list);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        save = button("Salvar funções",GREEN); page.addView(save,matchWrap());
        Button back = button("Voltar",BLUE); page.addView(back,matchWrap());
        save.setEnabled(false);
        save.setOnClickListener(v -> confirmSave());
        back.setOnClickListener(v -> finish());
        setContentView(page); animateIn(page,0);
    }

    private void loadOptions() {
        status.setText("Buscando configuração central…"); save.setEnabled(false);
        new Thread(() -> {
            try {
                JSONObject result = rpc("meunova_admin_get_feature_visibility", new JSONObject());
                JSONArray rows = result.optJSONArray("features");
                if (rows == null) throw new Exception();
                List<Option> loaded = new ArrayList<>();
                for (int i=0;i<rows.length();i++) {
                    JSONObject row=rows.optJSONObject(i); if(row==null) continue;
                    String key=row.optString("key",""), label=row.optString("label","");
                    if(key.isEmpty()||label.isEmpty()) continue;
                    loaded.add(new Option(key,label,row.optBoolean("visible",true)));
                }
                if(loaded.isEmpty()) throw new Exception();
                runOnUiThread(() -> showOptions(loaded));
            } catch (Exception ex) {
                runOnUiThread(() -> { status.setText("Não foi possível carregar. Confirme a configuração do servidor e tente novamente."); save.setEnabled(false); });
            }
        },"nova-admin-feature-list").start();
    }

    private void showOptions(List<Option> loaded) {
        options.clear(); options.addAll(loaded); list.removeAllViews();
        int animationIndex = 0;
        for (Option option : options) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(15),dp(12),dp(15),dp(12)); card.setBackground(round(Color.WHITE,"#E3E9F1",20)); card.setElevation(dp(1));
            LinearLayout.LayoutParams cp=matchWrap(); cp.setMargins(0,dp(5),0,dp(6)); list.addView(card,cp); animateIn(card,animationIndex++);
            CheckBox check = new CheckBox(this); check.setText(option.label); check.setTextSize(15); check.setTextColor(Color.parseColor(BLUE)); check.setChecked(option.savedVisible); option.check=check;
            card.addView(check,matchWrap());
            TextView hint=text(option.savedVisible?"Visível para os usuários":"Oculto no menu dos usuários",11,option.savedVisible?GREEN:MUTED,false);
            card.addView(hint,matchWrap());
            check.setOnCheckedChangeListener((button,checked)->{
                hint.setText(checked?"Visível para os usuários":"Oculto no menu dos usuários");
                hint.setTextColor(checked?Color.rgb(22,131,74):Color.parseColor(MUTED));
                status.setText("Há alterações ainda não salvas.");
            });
        }
        status.setText("Marque as funções que devem aparecer e depois salve."); save.setEnabled(true);
    }

    private void confirmSave() {
        boolean changed=false;
        for(Option o:options) if(o.check!=null&&o.check.isChecked()!=o.savedVisible){changed=true;break;}
        if(!changed){toast("Não há alterações para salvar.");return;}
        new AlertDialog.Builder(this).setTitle("Aplicar para todos os usuários?")
                .setMessage("As funções marcadas ficarão visíveis no menu de todos os usuários. As desmarcadas serão ocultadas.")
                .setNegativeButton("Revisar",null).setPositiveButton("Salvar",(d,w)->saveOptions()).show();
    }

    private void saveOptions() {
        save.setEnabled(false); status.setText("Salvando configuração central…");
        new Thread(() -> {
            try {
                JSONArray payload = new JSONArray();
                for(Option o:options) payload.put(new JSONObject().put("key",o.key).put("visible",o.check!=null&&o.check.isChecked()));
                JSONObject result=rpc("meunova_admin_save_feature_visibility",new JSONObject().put("p_features",payload));
                if(!result.optBoolean("ok",false)) throw new Exception();
                runOnUiThread(()->{
                    for(Option o:options) o.savedVisible=o.check!=null&&o.check.isChecked();
                    status.setText("Configuração salva e sincronizada para todos os usuários."); save.setEnabled(true);
                    toast("Funções atualizadas. O app do usuário sincroniza ao voltar à tela inicial.");
                });
            } catch(Exception ex) {
                runOnUiThread(()->{status.setText("Não foi possível salvar. Nada foi confirmado; tente novamente.");save.setEnabled(true);});
            }
        },"nova-admin-feature-save").start();
    }

    private JSONObject rpc(String name, JSONObject body) throws Exception {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)new URL(BASE+"/rest/v1/rpc/"+name).openConnection();
            c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setDoOutput(true);
            c.setRequestProperty("apikey",KEY);c.setRequestProperty("Authorization","Bearer "+accessToken);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Cache-Control","no-store");
            byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(data.length);
            try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String raw=readAll(in);
            if(code<200||code>=300)throw new Exception("RPC failed");return new JSONObject(raw);
        }finally{if(c!=null)c.disconnect();}
    }

    private String readAll(InputStream in)throws Exception{if(in==null)return "{}";try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[2048];int n;while((n=src.read(b))!=-1){if(out.size()+n>65536)throw new Exception("response too large");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
    private TextView text(String value,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setIncludeFontPadding(false);t.setLineSpacing(dp(2),1f);if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;}
    private Button button(String title,String color){Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setTypeface(null,android.graphics.Typeface.BOLD);b.setAllCaps(false);b.setMinHeight(dp(50));b.setPadding(dp(14),dp(5),dp(14),dp(5));android.graphics.drawable.GradientDrawable shape=round(Color.parseColor(color),color,17);if(android.os.Build.VERSION.SDK_INT>=21)b.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(Color.argb(36,255,255,255)),shape,null));else b.setBackground(shape);b.setElevation(dp(1));pressScale(b);return b;}
    private android.graphics.drawable.GradientDrawable round(int fill,String stroke,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));if(stroke!=null&&!stroke.isEmpty())d.setStroke(dp(1),Color.parseColor(stroke));return d;}
    private LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(6),0,dp(6));return p;}
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void animateIn(View view,int index){view.setAlpha(0f);view.setTranslationY(dp(8));view.post(()->view.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(index*25L,200L)).setDuration(250L).setInterpolator(new android.view.animation.DecelerateInterpolator()).start());}
    private void pressScale(View view){view.setOnTouchListener((v,event)->{if(event.getAction()==android.view.MotionEvent.ACTION_DOWN)v.animate().scaleX(.975f).scaleY(.975f).setDuration(100).start();else if(event.getAction()==android.view.MotionEvent.ACTION_UP||event.getAction()==android.view.MotionEvent.ACTION_CANCEL)v.animate().scaleX(1f).scaleY(1f).setDuration(180).start();return false;});}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void finish(){super.finish();overridePendingTransition(R.anim.activity_return,R.anim.activity_close_exit);}
}
