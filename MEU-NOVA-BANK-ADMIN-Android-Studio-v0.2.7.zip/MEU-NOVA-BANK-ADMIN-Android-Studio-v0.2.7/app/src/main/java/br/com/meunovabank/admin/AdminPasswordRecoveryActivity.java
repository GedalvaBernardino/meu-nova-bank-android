package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

/** Dedicated and confirmed password-recovery link action. The administrator never sees or sets a password. */
public final class AdminPasswordRecoveryActivity extends AdminNativeActivity {
    private String account="",name=""; private Button send; private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";name=getIntent().getStringExtra("display_name");if(name==null)name="Usuário";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Recuperação de senha",24,BLUE,true),matchWrap());root.addView(text(name+"  ·  Conta "+account,14,INK,true),matchWrap());
        root.addView(text("O usuário escolhe a própria senha por um link enviado ao e-mail confirmado. O administrador não define nem visualiza a senha.",13,MUTED,false),matchWrap());
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(16),dp(15),dp(16),dp(15));card.setBackground(round(android.graphics.Color.WHITE,"#E3E9F1",21));card.setElevation(dp(1));root.addView(card,matchWrap());
        card.addView(text("O endereço de e-mail não será exibido nesta tela.",14,BLUE,true),matchWrap());card.addView(text("O pedido pode ser limitado para proteger a conta. A resposta não revela se o endereço recebeu a mensagem.",12,MUTED,false),matchWrap());
        status=text("Nenhum link foi solicitado.",13,MUTED,false);root.addView(status,matchWrap());send=button("Revisar envio do link",RED);root.addView(send,matchWrap());Button back=button("Voltar",BLUE);root.addView(back,matchWrap());
        send.setOnClickListener(v->confirmSend());back.setOnClickListener(v->finish());installPage(root);
    }
    private void confirmSend(){new AlertDialog.Builder(this).setTitle("Enviar link de recuperação?").setMessage("Será solicitado o envio de um link seguro ao e-mail confirmado da conta "+account+". O usuário precisa abrir o link e definir a senha.").setNegativeButton("Cancelar",null).setPositiveButton("Enviar link",(d,w)->sendLink()).show();}
    private void sendLink(){send.setEnabled(false);status.setText("Solicitando envio seguro…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("account_number",account);JSONObject result=AdminApi.request("/functions/v1/account-password-recovery",body,accessToken);if(!"recovery_requested".equals(result.optString("status","")))throw new Exception();JSONObject audit=new JSONObject();audit.put("action","audit_password_recovery");audit.put("account_number",account);JSONObject auditResult=adminRequest(audit);boolean auditOk=auditResult.optBoolean("audit_ok",false);runOnUiThread(()->{status.setText(auditOk?"Solicitação processada e registrada. Se a conta estiver ativa, o link foi enviado ao e-mail confirmado.":"Solicitação processada, mas a auditoria não pôde ser confirmada.");send.setEnabled(true);});}catch(Exception e){runOnUiThread(()->{status.setText("Não foi possível solicitar o link agora. Tente novamente mais tarde.");send.setEnabled(true);});}},"nova-admin-password-recovery").start();}
}
