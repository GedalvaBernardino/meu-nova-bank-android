package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

/** Dedicated edit screen for a user's name, email and phone. */
public final class AdminEditProfileActivity extends AdminNativeActivity {
    private String account="",originalEmail="",originalTheme="basic";
    private EditText name,email,phone; private CheckBox emailAttestation; private TextView status; private Button save; private boolean loaded=false;

    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Dados do perfil",24,BLUE,true),matchWrap());root.addView(text("Conta: "+account,14,INK,true),matchWrap());
        name=field("Nome completo",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(120)});
        email=field("E-mail",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);email.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(254)});
        phone=field("Telefone (DDD + número)",InputType.TYPE_CLASS_PHONE);phone.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(20)});
        root.addView(text("Nome",13,INK,true),matchWrap());root.addView(name,matchWrap());root.addView(text("E-mail",13,INK,true),matchWrap());root.addView(email,matchWrap());root.addView(text("Telefone",13,INK,true),matchWrap());root.addView(phone,matchWrap());
        TextView warning=text("A alteração de e-mail é confirmada imediatamente pelo administrador. Confira o endereço cuidadosamente.",12,RED,true);root.addView(warning,matchWrap());
        emailAttestation=new CheckBox(this);emailAttestation.setText("Confirmo que o novo e-mail pertence ao usuário.");emailAttestation.setTextColor(android.graphics.Color.parseColor(INK));emailAttestation.setVisibility(View.GONE);root.addView(emailAttestation,matchWrap());
        email.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){}public void onTextChanged(CharSequence s,int start,int before,int count){emailAttestation.setVisibility(emailChanged()?View.VISIBLE:View.GONE);}public void afterTextChanged(android.text.Editable e){}});
        status=text("Carregando perfil protegido…",13,MUTED,false);root.addView(status,matchWrap());save=button("Revisar e salvar",GREEN);save.setEnabled(false);root.addView(save,matchWrap());Button back=button("Voltar",BLUE);root.addView(back,matchWrap());
        save.setOnClickListener(v->review());back.setOnClickListener(v->finish());installPage(root);load();
    }

    private void load(){new Thread(()->{try{JSONObject req=new JSONObject();req.put("action","get_profile");req.put("account_number",account);JSONObject p=adminRequest(req).getJSONObject("profile");runOnUiThread(()->{name.setText(p.optString("display_name",""));originalEmail=p.optString("email","");email.setText(originalEmail);phone.setText(p.optString("phone",""));originalTheme=p.optString("theme_tier","basic");loaded=true;save.setEnabled(true);status.setText("Perfil carregado. E-mail confirmado: "+(p.optBoolean("email_confirmed",false)?"sim":"não"));});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível carregar o perfil autorizado."));}},"nova-admin-profile-load").start();}
    private boolean emailChanged(){return loaded&&!email.getText().toString().trim().equalsIgnoreCase(originalEmail.trim());}
    private void review(){if(!loaded)return;String displayName=name.getText().toString().trim().replaceAll("\\s+"," ");String nextEmail=email.getText().toString().trim();String digits=phone.getText().toString().replaceAll("\\D","");if(displayName.length()<2||displayName.length()>120){status.setText("Informe um nome entre 2 e 120 caracteres.");return;}if(nextEmail.length()>254||!Patterns.EMAIL_ADDRESS.matcher(nextEmail).matches()){status.setText("Informe um e-mail válido.");return;}if(!digits.isEmpty()&&(digits.length()<10||digits.length()>11)){status.setText("O telefone deve conter 10 ou 11 dígitos.");return;}boolean changed=!nextEmail.equalsIgnoreCase(originalEmail);if(changed&&!emailAttestation.isChecked()){status.setText("Confirme que o novo e-mail pertence ao usuário.");return;}String details="Nome: "+displayName+"\nTelefone: "+(digits.isEmpty()?"(vazio)":digits);if(changed)details+="\n\nE-mail atual: "+originalEmail+"\nNovo e-mail: "+nextEmail+"\n\nO endereço será confirmado imediatamente.";new AlertDialog.Builder(this).setTitle("Revisar perfil").setMessage(details+"\n\nSalvar as alterações?").setNegativeButton("Voltar",null).setPositiveButton("Confirmar",(d,w)->save(displayName,nextEmail,digits,changed)).show();}
    private void save(String displayName,String nextEmail,String digits,boolean changedEmail){save.setEnabled(false);status.setText("Salvando perfil…");new Thread(()->{try{JSONObject req=new JSONObject();req.put("action","update_profile");req.put("account_number",account);req.put("display_name",displayName);req.put("email",nextEmail);req.put("phone",digits);req.put("theme_tier",originalTheme);req.put("confirm_email_change",changedEmail&&emailAttestation.isChecked());JSONObject result=adminRequest(req);boolean auditOk=result.optBoolean("audit_ok",false);runOnUiThread(()->{originalEmail=nextEmail;emailAttestation.setChecked(false);status.setText(auditOk?"Perfil atualizado e auditado.":"Perfil atualizado; não foi possível confirmar a auditoria.");save.setEnabled(true);});}catch(Exception e){String msg=e.getMessage()!=null&&e.getMessage().contains("EMAIL_ALREADY_IN_USE")?"Esse e-mail já está associado a outra conta.":"Não foi possível atualizar. Confira os dados e tente novamente.";runOnUiThread(()->{status.setText(msg);save.setEnabled(true);});}},"nova-admin-profile-save").start();}
}
