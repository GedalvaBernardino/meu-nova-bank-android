package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONObject;

/** Admin-only profile, access-role, theme and secure password-recovery controls. */
public final class AdminEditProfileActivity extends AdminNativeActivity {
    private static final String[] THEME_KEYS = {"basic", "select", "platinum", "gold", "black"};
    private static final String[] THEME_LABELS = {"Basic · azul", "Select · cinza", "Platinum · laranja", "Ouro · dourado", "Black · preto"};

    private String account = "";
    private EditText name, email, phone;
    private Spinner theme;
    private TextView status;
    private Button saveProfile, saveRole, sendRecovery;
    private CheckBox emailAttestation, adminRole;
    private boolean loaded = false;
    private String originalEmail = "", originalTheme = "basic";
    private boolean originalIsAdmin = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        account = getIntent().getStringExtra("account_number");
        if (account == null) account = "";

        LinearLayout root = page();
        root.addView(text("MEU NOVA BANK ADMIN", 12, RED, true), matchWrap());
        root.addView(text("Editar perfil do usuário", 21, BLUE, true), matchWrap());
        root.addView(text("Conta: " + account, 15, INK, true), matchWrap());
        root.addView(text("Nome, e-mail, telefone e categoria visual. Status e número da conta permanecem nos controles próprios.", 12, MUTED, false), matchWrap());

        name = field("Nome completo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        email = field("E-mail", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        phone = field("Telefone (DDD + número)", InputType.TYPE_CLASS_PHONE);
        name.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(120)});
        email.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(254)});
        phone.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(20)});
        root.addView(text("Nome", 13, INK, true), matchWrap()); root.addView(name, matchWrap());
        root.addView(text("E-mail", 13, INK, true), matchWrap()); root.addView(email, matchWrap());
        root.addView(text("Telefone", 13, INK, true), matchWrap()); root.addView(phone, matchWrap());

        root.addView(text("Categoria visual do app", 13, INK, true), matchWrap());
        theme = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, THEME_LABELS);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        theme.setAdapter(adapter);
        root.addView(theme, matchWrap());

        TextView warning = text("Ao alterar o e-mail, o administrador confirma o novo endereço imediatamente no Supabase. Isso ignora a confirmação usual; confirme que o endereço pertence ao usuário.", 12, RED, true);
        root.addView(warning, matchWrap());
        emailAttestation = new CheckBox(this);
        emailAttestation.setText("Confirmo que o novo e-mail pertence ao usuário.");
        emailAttestation.setTextColor(android.graphics.Color.parseColor(INK));
        emailAttestation.setVisibility(View.GONE);
        root.addView(emailAttestation, matchWrap());
        email.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { emailAttestation.setVisibility(emailChanged() ? View.VISIBLE : View.GONE); }
            public void afterTextChanged(android.text.Editable e) {}
        });

        status = text("Carregando perfil protegido…", 13, MUTED, false); root.addView(status, matchWrap());
        saveProfile = button("Revisar e salvar perfil", GREEN); saveProfile.setEnabled(false); root.addView(saveProfile, matchWrap());

        adminRole = new CheckBox(this);
        adminRole.setText("Acesso de administrador");
        adminRole.setTextColor(android.graphics.Color.parseColor(BLUE));
        adminRole.setEnabled(false);
        root.addView(adminRole, matchWrap());
        root.addView(text("Administradores podem visualizar perfis e executar as ações administrativas autorizadas.", 12, MUTED, false), matchWrap());
        saveRole = button("Revisar permissão", BLUE); saveRole.setEnabled(false); root.addView(saveRole, matchWrap());

        sendRecovery = button("Enviar link para trocar a senha", RED); sendRecovery.setEnabled(false); root.addView(sendRecovery, matchWrap());
        root.addView(text("O link vai ao e-mail confirmado do usuário. O administrador não vê nem define a senha.", 12, MUTED, false), matchWrap());
        Button back = button("Voltar", BLUE); root.addView(back, matchWrap());

        saveProfile.setOnClickListener(v -> reviewAndSave());
        saveRole.setOnClickListener(v -> reviewRole());
        sendRecovery.setOnClickListener(v -> confirmPasswordRecovery());
        back.setOnClickListener(v -> finish());
        installPage(root);
        loadProfile();
    }

    private void loadProfile() {
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject(); request.put("action", "get_profile"); request.put("account_number", account);
                JSONObject profile = adminRequest(request).getJSONObject("profile");
                runOnUiThread(() -> {
                    name.setText(profile.optString("display_name", ""));
                    originalEmail = profile.optString("email", ""); email.setText(originalEmail);
                    phone.setText(profile.optString("phone", ""));
                    originalTheme = profile.optString("theme_tier", "basic");
                    theme.setSelection(themePosition(originalTheme));
                    originalIsAdmin = profile.optBoolean("is_admin", false);
                    adminRole.setChecked(originalIsAdmin);
                    status.setText("Perfil carregado • Status: " + profile.optString("account_status", "active")
                            + " • E-mail confirmado: " + (profile.optBoolean("email_confirmed", false) ? "sim" : "não"));
                    loaded = true; saveProfile.setEnabled(true); saveRole.setEnabled(true); adminRole.setEnabled(true); sendRecovery.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Não foi possível carregar o perfil autorizado. Volte e tente novamente."));
            }
        }, "nova-admin-profile-load").start();
    }

    private int themePosition(String tier) {
        for (int i = 0; i < THEME_KEYS.length; i++) if (THEME_KEYS[i].equalsIgnoreCase(tier)) return i;
        return 0;
    }

    private String selectedTheme() {
        int position = theme.getSelectedItemPosition();
        return position >= 0 && position < THEME_KEYS.length ? THEME_KEYS[position] : "basic";
    }

    private boolean emailChanged() {
        return loaded && !email.getText().toString().trim().equalsIgnoreCase(originalEmail.trim());
    }

    private void reviewAndSave() {
        if (!loaded) return;
        String displayName = name.getText().toString().trim().replaceAll("\\s+", " ");
        String newEmail = email.getText().toString().trim();
        String digits = phone.getText().toString().replaceAll("\\D", "");
        String newTheme = selectedTheme();
        if (displayName.length() < 2 || displayName.length() > 120) { status.setText("Informe um nome entre 2 e 120 caracteres."); return; }
        if (newEmail.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(newEmail).matches()) { status.setText("Informe um endereço de e-mail válido."); return; }
        if (!digits.isEmpty() && (digits.length() < 10 || digits.length() > 11)) { status.setText("O telefone deve conter 10 ou 11 dígitos."); return; }
        boolean changedEmail = !newEmail.equalsIgnoreCase(originalEmail);
        if (changedEmail && !emailAttestation.isChecked()) { status.setText("Marque a confirmação de que o novo e-mail pertence ao usuário."); return; }

        String details = "Conta: " + account + "\nNome: " + displayName + "\nTelefone: " + (digits.isEmpty() ? "(vazio)" : digits)
                + "\nCategoria: " + themeLabel(newTheme);
        if (changedEmail) details += "\n\nE-mail atual: " + originalEmail + "\nNovo e-mail: " + newEmail + "\n\nO novo e-mail será confirmado imediatamente pelo administrador.";
        new AlertDialog.Builder(this).setTitle("Revisar perfil")
                .setMessage(details + "\n\nSalvar estas alterações?")
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Confirmar e salvar", (dialog, which) -> saveProfile(displayName, newEmail, digits, newTheme, changedEmail))
                .show();
    }

    private String themeLabel(String key) { return THEME_LABELS[themePosition(key)]; }

    private void saveProfile(String displayName, String newEmail, String digits, String newTheme, boolean changedEmail) {
        final boolean emailConfirmedByAdmin = changedEmail && emailAttestation.isChecked();
        setProfileControlsEnabled(false); status.setText("Salvando perfil protegido…");
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("action", "update_profile"); request.put("account_number", account);
                request.put("display_name", displayName); request.put("email", newEmail); request.put("phone", digits);
                request.put("theme_tier", newTheme); request.put("confirm_email_change", emailConfirmedByAdmin);
                JSONObject response = adminRequest(request);
                boolean auditOk = response.optBoolean("audit_ok", false);
                runOnUiThread(() -> {
                    status.setText(auditOk ? "Perfil atualizado e alteração registrada na auditoria." : "Perfil atualizado, mas o registro de auditoria não foi confirmado. Avise o responsável técnico.");
                    if (auditOk) toast("Perfil atualizado.");
                    originalEmail = newEmail; originalTheme = newTheme; emailAttestation.setChecked(false); setProfileControlsEnabled(true);
                });
            } catch (Exception e) {
                String error = e.getMessage() == null ? "" : e.getMessage();
                String message = error.contains("EMAIL_ALREADY_IN_USE") ? "Esse e-mail já está associado a outra conta."
                        : "Não foi possível confirmar a atualização. Confira o perfil e tente novamente.";
                runOnUiThread(() -> { status.setText(message); setProfileControlsEnabled(true); });
            }
        }, "nova-admin-profile-save").start();
    }

    private void setProfileControlsEnabled(boolean enabled) {
        saveProfile.setEnabled(enabled); name.setEnabled(enabled); email.setEnabled(enabled); phone.setEnabled(enabled); theme.setEnabled(enabled);
    }

    private void reviewRole() {
        if (!loaded) return;
        boolean desired = adminRole.isChecked();
        if (desired == originalIsAdmin) { toast("A permissão não foi alterada."); return; }
        String action = desired ? "Conceder acesso de administrador?" : "Remover acesso de administrador?";
        String explanation = desired
                ? "Este usuário poderá acessar o painel e executar as ações administrativas autorizadas."
                : "Este usuário deixará de acessar o painel. O servidor impedirá remover o último administrador ou o próprio acesso.";
        new AlertDialog.Builder(this).setTitle(action).setMessage("Conta: " + account + "\n\n" + explanation)
                .setNegativeButton("Revisar", (d, w) -> adminRole.setChecked(originalIsAdmin))
                .setPositiveButton("Confirmar", (d, w) -> saveRole(desired)).setOnCancelListener(d -> adminRole.setChecked(originalIsAdmin)).show();
    }

    private void saveRole(boolean desired) {
        saveRole.setEnabled(false); status.setText("Atualizando permissão no servidor…");
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject(); request.put("action", "set_admin_role"); request.put("account_number", account); request.put("is_admin", desired);
                JSONObject response = adminRequest(request);
                if (!response.optBoolean("ok", false)) throw new Exception("ADMIN_ROLE_CHANGE_REJECTED");
                boolean auditOk = response.optBoolean("audit_ok", false);
                runOnUiThread(() -> {
                    originalIsAdmin = desired; adminRole.setChecked(desired); saveRole.setEnabled(true);
                    status.setText(auditOk ? "Permissão atualizada e auditada." : "Permissão atualizada, mas a auditoria não foi confirmada.");
                    if (auditOk) toast(desired ? "Acesso de administrador concedido." : "Acesso removido.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    adminRole.setChecked(originalIsAdmin); saveRole.setEnabled(true);
                    status.setText("O servidor recusou a alteração. Verifique se não é o último administrador e tente novamente.");
                });
            }
        }, "nova-admin-role-change").start();
    }

    private void confirmPasswordRecovery() {
        if (!loaded) return;
        new AlertDialog.Builder(this).setTitle("Enviar link de troca de senha?")
                .setMessage("Se a conta estiver ativa, um link seguro será enviado ao e-mail confirmado. O usuário precisará abrir o link e escolher a própria senha. Nenhuma senha será exibida ou definida pelo administrador.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Enviar link", (d, w) -> sendPasswordRecovery())
                .show();
    }

    private void sendPasswordRecovery() {
        sendRecovery.setEnabled(false); status.setText("Solicitando link seguro…");
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject(); body.put("account_number", account);
                JSONObject result = AdminApi.request("/functions/v1/account-password-recovery", body, accessToken);
                if (!"recovery_requested".equals(result.optString("status", ""))) throw new Exception("Recovery request failed");
                JSONObject audit = new JSONObject(); audit.put("action", "audit_password_recovery"); audit.put("account_number", account);
                JSONObject auditResult = adminRequest(audit);
                boolean auditOk = auditResult.optBoolean("audit_ok", false);
                runOnUiThread(() -> {
                    sendRecovery.setEnabled(true);
                    status.setText(auditOk ? "Solicitação processada. Se a conta estiver ativa, o link foi enviado ao e-mail confirmado." : "Solicitação processada; não foi possível confirmar o registro de auditoria.");
                });
            } catch (Exception e) {
                runOnUiThread(() -> { sendRecovery.setEnabled(true); status.setText("Não foi possível solicitar o link. Tente novamente mais tarde."); });
            }
        }, "nova-admin-password-recovery").start();
    }
}
