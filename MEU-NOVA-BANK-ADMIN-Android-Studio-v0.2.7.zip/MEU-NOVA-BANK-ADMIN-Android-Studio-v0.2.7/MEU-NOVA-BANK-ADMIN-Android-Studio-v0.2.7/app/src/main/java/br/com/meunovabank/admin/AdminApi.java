package br.com.meunovabank.admin;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class AdminApi {
    static final String BASE="https://hzgslpskmyzczqquendt.supabase.co";
    static final String KEY="sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private AdminApi(){}
    static JSONObject request(String path,JSONObject body,String token)throws Exception{
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(BASE+path).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setDoOutput(true);
            c.setRequestProperty("apikey",KEY);c.setRequestProperty("Authorization","Bearer "+(token==null||token.isEmpty()?KEY:token));c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Cache-Control","no-store");
            byte[]data=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(data.length);try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String result=read(in);
            if(code<200||code>=300)throw new Exception("HTTP "+code+" "+result);return new JSONObject(result);
        }finally{if(c!=null)c.disconnect();}
    }
    private static String read(InputStream in)throws Exception{if(in==null)return "";try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[2048];int n;while((n=src.read(b))!=-1){if(out.size()+n>65536)throw new Exception("response too large");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
}
