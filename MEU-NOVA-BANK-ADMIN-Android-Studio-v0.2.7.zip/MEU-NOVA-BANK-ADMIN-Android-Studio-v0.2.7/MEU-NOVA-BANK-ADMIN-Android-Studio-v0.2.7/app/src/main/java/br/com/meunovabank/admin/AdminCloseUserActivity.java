package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class AdminCloseUserActivity extends AdminNativeActivity {
    private String account="";private EditText confirmation;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Encerrar conta",21,BLUE,true),matchWrap());
        root.addView(text("Conta selecionada: "+account,15,INK,true),matchWrap());root.addView(text("O acesso será encerrado logicamente. Perfil, saldo registrado e histórico serão preservados; não haverá exclusão física.",14,MUTED,false),matchWrap());
        confirmation=field("Digite o número da conta para confirmar",InputType.TYPE_CLASS_NUMBER);confirmation.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});root.addView(confirmation,matchWrap());
        status=text("A conta só será encerrada após revisão e confirmação.",12,MUTED,false);root.addView(status,matchWrap());
        android.widget.Button close=button("Revisar encerramento",RED),back=button("Voltar",BLUE);root.addView(close,matchWrap());root.addView(back,matchWrap());close.setOnClickListener(v->confirm());back.setOnClickListener(v->finish());installPage(root);
    }
    private void confirm(){if(!account.equals(confirmation.getText().toString().trim())){status.setText("O número informado não confere; nada foi alterado.");return;}
        new AlertDialog.Builder(this).setTitle("Confirmar encerramento?").setMessage("Conta "+account+" será bloqueada para acesso e encerrada logicamente. O histórico será preservado.").setNegativeButton("Voltar",null).setPositiveButton("Encerrar conta",(d,w)->close()).show();}
    private void close(){status.setText("Encerrando conta…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("action","close");body.put("account_number",account);adminRequest(body);runOnUiThread(()->{status.setText("Conta encerrada logicamente; histórico preservado.");toast("Conta encerrada.");});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível confirmar o encerramento."));}},"nova-admin-close").start();}
}
