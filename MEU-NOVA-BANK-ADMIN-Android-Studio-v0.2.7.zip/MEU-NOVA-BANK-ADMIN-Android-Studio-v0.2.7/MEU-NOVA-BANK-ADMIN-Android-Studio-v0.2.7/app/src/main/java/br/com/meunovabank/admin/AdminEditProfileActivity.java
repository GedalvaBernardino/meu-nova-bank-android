package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

/** Admin-only profile editor; profile data is fetched on demand and not persisted locally. */
public final class AdminEditProfileActivity extends AdminNativeActivity {
    private String account = "";
    private EditText name, email, phone;
    private TextView status;
    private Button save;
    private CheckBox emailAttestation;
    private boolean loaded = false;
    private String originalEmail = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        account = getIntent().getStringExtra("account_number");
        if (account == null) account = "";

        LinearLayout root = page();
        root.addView(text("MEU NOVA BANK ADMIN", 12, RED, true), matchWrap());
        root.addView(text("Editar perfil do usuário", 21, BLUE, true), matchWrap());
        root.addView(text("Conta: " + account, 15, INK, true), matchWrap());
        root.addView(text("Status e número da conta são somente leitura. Alterações de conta e saldo ficam nos controles próprios.", 12, MUTED, false), matchWrap());

        name = field("Nome completo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        email = field("E-mail", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        phone = field("Telefone (10 ou 11 dígitos)", InputType.TYPE_CLASS_PHONE);
        root.addView(text("Nome", 13, INK, true), matchWrap()); root.addView(name, matchWrap());
        root.addView(text("E-mail", 13, INK, true), matchWrap()); root.addView(email, matchWrap());
        root.addView(text("Telefone", 13, INK, true), matchWrap()); root.addView(phone, matchWrap());

        TextView warning = text("ATENÇÃO: ao alterar o e-mail, o administrador o confirma imediatamente no Supabase. Isso ignora os fluxos usuais de confirmação. Confirme apenas um endereço que pertença ao usuário.", 13, RED, true);
        root.addView(warning, matchWrap());
        emailAttestation = new CheckBox(this);
        emailAttestation.setText("Atesto que o novo endereço de e-mail pertence ao usuário.");
        emailAttestation.setTextColor(android.graphics.Color.parseColor(INK));
        root.addView(emailAttestation, matchWrap());

        status = text("Carregando perfil protegido…", 13, MUTED, false); root.addView(status, matchWrap());
        save = button("Revisar e salvar", GREEN); save.setEnabled(false); root.addView(save, matchWrap());
        Button back = button("Voltar", BLUE); root.addView(back, matchWrap());
        save.setOnClickListener(v -> reviewAndSave());
        back.setOnClickListener(v -> finish());
        email.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            public void onTextChanged(CharSequence s, int start, int before, int count) { emailAttestation.setVisibility(emailChanged() ? View.VISIBLE : View.GONE); }
            public void afterTextChanged(android.text.Editable e) {}
        });
        emailAttestation.setVisibility(View.GONE);
        installPage(root);
        loadProfile();
    }

    private void loadProfile() {
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject(); request.put("action", "get_profile"); request.put("account_number", account);
                JSONObject response = adminRequest(request);
                JSONObject profile = response.getJSONObject("profile");
                runOnUiThread(() -> {
                    name.setText(profile.optString("display_name", ""));
                    originalEmail = profile.optString("email", "");
                    email.setText(originalEmail);
                    phone.setText(profile.optString("phone", ""));
                    String state = profile.optString("account_status", "active");
                    status.setText("Perfil carregado • Conta: " + profile.optString("account_number", account) + " • Status: " + state);
                    loaded = true; save.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Não foi possível carregar o perfil autorizado. Volte e tente novamente."));
            }
        }, "nova-admin-profile-load").start();
    }

    private boolean emailChanged() {
        return loaded && !email.getText().toString().trim().equalsIgnoreCase(originalEmail.trim());
    }

    private void reviewAndSave() {
        if (!loaded) return;
        String displayName = name.getText().toString().trim().replaceAll("\\s+", " ");
        String newEmail = email.getText().toString().trim();
        String digits = phone.getText().toString().replaceAll("\\D", "");
        if (displayName.length() < 2 || displayName.length() > 120) { status.setText("Informe um nome entre 2 e 120 caracteres."); return; }
        if (newEmail.length() > 254 || !Patterns.EMAIL_ADDRESS.matcher(newEmail).matches()) { status.setText("Informe um endereço de e-mail válido."); return; }
        if (!digits.isEmpty() && (digits.length() < 10 || digits.length() > 11)) { status.setText("O telefone deve conter 10 ou 11 dígitos."); return; }
        String previousEmail = originalEmail;
        boolean changedEmail = !newEmail.equalsIgnoreCase(previousEmail);
        if (changedEmail && !emailAttestation.isChecked()) { status.setText("Marque a confirmação de que o novo e-mail pertence ao usuário."); return; }

        String details = "Conta: " + account + "\nNome: " + displayName + "\nTelefone: " + (digits.isEmpty() ? "(vazio)" : digits);
        if (changedEmail) details += "\n\nE-mail atual: " + previousEmail + "\nNovo e-mail: " + newEmail + "\n\nO novo e-mail será confirmado imediatamente pelo administrador.";
        new AlertDialog.Builder(this).setTitle("Revisar perfil")
                .setMessage(details + "\n\nSalvar estas alterações?")
                .setNegativeButton("Voltar", null)
                .setPositiveButton("Confirmar e salvar", (dialog, which) -> saveProfile(displayName, newEmail, digits, changedEmail))
                .show();
    }

    private void saveProfile(String displayName, String newEmail, String digits, boolean changedEmail) {
        final boolean emailConfirmedByAdmin = changedEmail && emailAttestation.isChecked();
        save.setEnabled(false); status.setText("Salvando perfil protegido…");
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("action", "update_profile"); request.put("account_number", account);
                request.put("display_name", displayName); request.put("email", newEmail); request.put("phone", digits);
                request.put("confirm_email_change", emailConfirmedByAdmin);
                JSONObject response = adminRequest(request);
                boolean auditOk = response.optBoolean("audit_ok", false);
                runOnUiThread(() -> {
                    status.setText(auditOk ? "Perfil atualizado e alteração registrada na auditoria." : "Perfil atualizado, mas o registro de auditoria não foi confirmado. Avise o responsável técnico.");
                    if (auditOk) toast("Perfil atualizado.");
                    originalEmail = newEmail; emailAttestation.setChecked(false); save.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> { status.setText("Não foi possível confirmar a atualização. Confira o perfil e tente novamente."); save.setEnabled(true); });
            }
        }, "nova-admin-profile-save").start();
    }
}
