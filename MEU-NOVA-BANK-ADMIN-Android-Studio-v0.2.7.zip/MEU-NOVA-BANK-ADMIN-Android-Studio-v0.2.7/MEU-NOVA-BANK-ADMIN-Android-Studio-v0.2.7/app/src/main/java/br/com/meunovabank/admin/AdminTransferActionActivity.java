package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class AdminTransferActionActivity extends AdminNativeActivity {
    private String id="",decision="",statusValue="",sender="",from="",to="",amount="0";private TextView status;private Button confirm;
    @Override public void onCreate(Bundle state){super.onCreate(state);id=extra("transfer_id");decision=extra("decision");statusValue=extra("status");sender=extra("sender_name");from=extra("sender_account");to=extra("recipient_account");amount=extra("amount");
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text(title(),21,BLUE,true),matchWrap());
        root.addView(text("Remetente: "+sender+" · conta "+from,15,INK,true),matchWrap());root.addView(text("Destino: conta MEU NOVA "+to+"\nValor: "+money(amount),14,BLUE,true),matchWrap());root.addView(text("Status atual: "+statusValue+"\nID: "+id,12,MUTED,false),matchWrap());
        root.addView(text(description(),13,MUTED,false),matchWrap());status=text("Revise os dados antes de confirmar.",12,MUTED,false);root.addView(status,matchWrap());confirm=button(buttonLabel(),decision.equals("reject")?RED:GREEN);Button back=button("Voltar",BLUE);root.addView(confirm,matchWrap());root.addView(back,matchWrap());confirm.setOnClickListener(v->confirmAction());back.setOnClickListener(v->finish());installPage(root);
    }
    private String extra(String k){String v=getIntent().getStringExtra(k);return v==null?"":v;}
    private String title(){if("reject".equals(decision))return "Revisar rejeição";if("notify".equals(decision))return "Reenviar aviso à origem";return "Revisar recebimento";}
    private String buttonLabel(){if("reject".equals(decision))return "Confirmar rejeição";if("notify".equals(decision))return "Repetir aviso";return "Confirmar aprovação / processamento";}
    private String description(){if("reject".equals(decision))return "Só rejeite enquanto o débito na origem não tiver sido confirmado. Se o estado do débito estiver incerto, não rejeite: volte e confira a situação.";if("notify".equals(decision))return "Esta ação repete apenas o aviso de status à instituição de origem; não executa novo débito nem altera saldo.";return "Ao aprovar, o sistema pode solicitar o débito à instituição de origem. O crédito demonstrativo de destino só ocorre após confirmação do débito.";}
    private void confirmAction(){String message="Ação: "+title()+"\nConta de origem: "+from+"\nConta de destino: "+to+"\nValor: "+money(amount)+"\n\nConfirmar?";new AlertDialog.Builder(this).setTitle("Confirmação final").setMessage(message).setNegativeButton("Revisar",null).setPositiveButton("Confirmar",(d,w)->execute()).show();}
    private void execute(){confirm.setEnabled(false);status.setText("Enviando solicitação administrativa…");new Thread(()->{try{JSONObject body=new JSONObject();if("notify".equals(decision)){body.put("action","interbank_notify_source");body.put("transfer_id",id);JSONObject result=adminRequest(body);String msg=result.optBoolean("callback_pending",false)?"Aviso pendente. Nenhum novo débito foi iniciado.":"Aviso encaminhado à origem; nenhum novo débito foi iniciado.";runOnUiThread(()->{status.setText(msg);toast(msg);confirm.setEnabled(true);});}else{body.put("action","interbank_review");body.put("transfer_id",id);body.put("decision",decision);JSONObject result=adminRequest(body);String state=result.optString("status","");String msg="credited".equals(state)?"Recebimento confirmado e lançado no saldo/extrato demonstrativo.":"Resultado informado pelo servidor: "+(state.isEmpty()?"processamento atualizado":state);runOnUiThread(()->{status.setText(msg);toast(msg);confirm.setEnabled(true);});}}catch(Exception e){runOnUiThread(()->{status.setText("Não há confirmação da resposta. Volte à lista e confira o status antes de repetir a ação.");confirm.setEnabled(true);});}},"nova-admin-transfer-action").start();}
}
