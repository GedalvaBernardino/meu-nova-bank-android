package br.com.meunovabank.admin;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

abstract class AdminNativeActivity extends Activity {
    protected static final String BLUE="#102B50", RED="#D62839", GREEN="#16834A", MUTED="#63748A", INK="#24354D";
    protected String accessToken="";
    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(Color.parseColor(BLUE));getWindow().setNavigationBarColor(Color.parseColor(BLUE));getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);accessToken=getIntent().getStringExtra("admin_access_token");if(accessToken==null)accessToken="";}
    protected LinearLayout page(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(18),dp(18),dp(18));l.setBackgroundColor(Color.rgb(244,247,251));return l;}
    protected void installPage(LinearLayout root){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(root);setContentView(scroll);}
    protected TextView text(String value,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setPadding(0,dp(5),0,dp(5));if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    protected Button button(String label,String color){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(round(Color.parseColor(color),color,11));return b;}
    protected EditText field(String hint,int inputType){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(inputType);e.setTextSize(15);e.setPadding(dp(12),dp(8),dp(12),dp(8));e.setBackground(round(Color.WHITE,"#D8E0EA",11));return e;}
    protected GradientDrawable round(int fill,String stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.parseColor(stroke));return d;}
    protected LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));return p;}
    protected int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+0.5f);}
    protected JSONObject adminRequest(JSONObject body)throws Exception{return AdminApi.request("/functions/v1/admin-users",body,accessToken);}
    protected void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    protected String money(String raw){try{double value=Double.parseDouble(raw);DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("pt","BR"));return new DecimalFormat("R$ #,##0.00",s).format(value);}catch(Exception e){return "R$ 0,00";}}
}
