package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class AdminEditAccountActivity extends AdminNativeActivity {
    private String oldAccount="",name=""; private EditText target; private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);oldAccount=getIntent().getStringExtra("account_number");name=getIntent().getStringExtra("display_name");if(oldAccount==null)oldAccount="";if(name==null)name="";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Editar número da conta",21,BLUE,true),matchWrap());root.addView(text("Usuário: "+(name.isEmpty()?"Sem nome":name),15,INK,true),matchWrap());root.addView(text("Conta atual: "+oldAccount,14,MUTED,false),matchWrap());
        root.addView(text("A alteração atualiza o login por conta e mantém o mesmo usuário, saldo e histórico. O novo número precisa ser único.",13,MUTED,false),matchWrap());
        target=field("Novo número da conta · 6 dígitos",InputType.TYPE_CLASS_NUMBER);target.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});root.addView(target,matchWrap());status=text("Nada será alterado até a confirmação final.",12,MUTED,false);root.addView(status,matchWrap());
        android.widget.Button review=button("Revisar alteração",GREEN),back=button("Voltar",BLUE);root.addView(review,matchWrap());root.addView(back,matchWrap());review.setOnClickListener(v->review());back.setOnClickListener(v->finish());installPage(root);
    }
    private void review(){String next=target.getText().toString().trim();if(!next.matches("\\d{6}")){status.setText("O novo número deve ter exatamente 6 dígitos.");return;}if(next.equals(oldAccount)){status.setText("Informe um número diferente da conta atual.");return;}
        new AlertDialog.Builder(this).setTitle("Confirmar alteração da conta?").setMessage("Usuário: "+(name.isEmpty()?"Sem nome":name)+"\nConta atual: "+oldAccount+"\nNova conta: "+next+"\n\nO saldo, histórico e perfil serão preservados.").setNegativeButton("Voltar",null).setPositiveButton("Confirmar",(d,w)->save(next)).show();}
    private void save(String next){status.setText("Atualizando conta com proteção de unicidade…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("action","change_account");body.put("account_number",oldAccount);body.put("new_account_number",next);JSONObject result=adminRequest(body);if(!result.optBoolean("ok",false))throw new Exception(result.optString("error","operation_failed"));runOnUiThread(()->{status.setText("Número da conta atualizado com sucesso.");toast("Conta alterada para "+next+".");});}catch(Exception e){String error=e.getMessage()==null?"":e.getMessage();String msg=error.contains("ACCOUNT_NUMBER_TAKEN")?"Esse número já está em uso. Escolha outro.":error.contains("ACCOUNT_NUMBER_CHANGE_NOT_DEPLOYED")?"A função administrativa ainda não foi publicada no servidor.":"Não foi possível confirmar a alteração. Confira a conexão e tente novamente.";runOnUiThread(()->status.setText(msg));}},"nova-admin-account-change").start();}
}
