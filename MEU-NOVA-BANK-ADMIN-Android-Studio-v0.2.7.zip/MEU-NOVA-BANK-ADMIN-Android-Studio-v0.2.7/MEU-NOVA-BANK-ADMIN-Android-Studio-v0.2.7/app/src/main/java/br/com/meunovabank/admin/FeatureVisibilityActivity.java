package br.com.meunovabank.admin;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Administra, em uma Activity nativa, quais funções aparecem no menu de todos os clientes. */
public final class FeatureVisibilityActivity extends Activity {
    private static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private static final String KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private static final String BLUE = "#102B50", GREEN = "#16834A", RED = "#D62839", MUTED = "#63748A";
    private final List<Option> options = new ArrayList<>();
    private String accessToken = "";
    private LinearLayout list;
    private TextView status;
    private Button save;

    private static final class Option {
        final String key, label;
        boolean savedVisible;
        CheckBox check;
        Option(String key, String label, boolean visible) { this.key=key; this.label=label; this.savedVisible=visible; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.parseColor(BLUE));
        getWindow().setNavigationBarColor(Color.parseColor(BLUE));
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        accessToken = getIntent().getStringExtra("admin_access_token");
        if (accessToken == null) accessToken = "";
        buildScreen();
        if (accessToken.isEmpty()) { status.setText("Sessão administrativa ausente. Entre novamente."); save.setEnabled(false); }
        else loadOptions();
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18),dp(18),dp(18),dp(14)); page.setBackgroundColor(Color.rgb(244,247,251));
        TextView brand = text("MEU NOVA BANK",21,BLUE,true); page.addView(brand,matchWrap());
        TextView title = text("Funções do usuário",19,RED,true); page.addView(title,matchWrap());
        TextView note = text("Marcado = aparece no app de todos os usuários. Desmarcado = oculto no menu. A alteração fica salva centralmente.",13,MUTED,false); page.addView(note,matchWrap());
        status = text("Carregando funções…",13,MUTED,false); page.addView(status,matchWrap());
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(false); scroll.addView(list);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        save = button("Salvar funções",GREEN); page.addView(save,matchWrap());
        Button back = button("Voltar",BLUE); page.addView(back,matchWrap());
        save.setEnabled(false);
        save.setOnClickListener(v -> confirmSave());
        back.setOnClickListener(v -> finish());
        setContentView(page);
    }

    private void loadOptions() {
        status.setText("Buscando configuração central…"); save.setEnabled(false);
        new Thread(() -> {
            try {
                JSONObject result = rpc("meunova_admin_get_feature_visibility", new JSONObject());
                JSONArray rows = result.optJSONArray("features");
                if (rows == null) throw new Exception();
                List<Option> loaded = new ArrayList<>();
                for (int i=0;i<rows.length();i++) {
                    JSONObject row=rows.optJSONObject(i); if(row==null) continue;
                    String key=row.optString("key",""), label=row.optString("label","");
                    if(key.isEmpty()||label.isEmpty()) continue;
                    loaded.add(new Option(key,label,row.optBoolean("visible",true)));
                }
                if(loaded.isEmpty()) throw new Exception();
                runOnUiThread(() -> showOptions(loaded));
            } catch (Exception ex) {
                runOnUiThread(() -> { status.setText("Não foi possível carregar. Confirme a configuração do servidor e tente novamente."); save.setEnabled(false); });
            }
        },"nova-admin-feature-list").start();
    }

    private void showOptions(List<Option> loaded) {
        options.clear(); options.addAll(loaded); list.removeAllViews();
        for (Option option : options) {
            LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12),dp(9),dp(12),dp(9)); card.setBackground(round(Color.WHITE,"#D8E0EA",12));
            LinearLayout.LayoutParams cp=matchWrap(); cp.setMargins(0,dp(4),0,dp(4)); list.addView(card,cp);
            CheckBox check = new CheckBox(this); check.setText(option.label); check.setTextSize(15); check.setTextColor(Color.parseColor(BLUE)); check.setChecked(option.savedVisible); option.check=check;
            card.addView(check,matchWrap());
            TextView hint=text(option.savedVisible?"Visível para os usuários":"Oculto no menu dos usuários",11,option.savedVisible?GREEN:MUTED,false);
            card.addView(hint,matchWrap());
            check.setOnCheckedChangeListener((button,checked)->{
                hint.setText(checked?"Visível para os usuários":"Oculto no menu dos usuários");
                hint.setTextColor(checked?Color.rgb(22,131,74):Color.parseColor(MUTED));
                status.setText("Há alterações ainda não salvas.");
            });
        }
        status.setText("Marque as funções que devem aparecer e depois salve."); save.setEnabled(true);
    }

    private void confirmSave() {
        boolean changed=false;
        for(Option o:options) if(o.check!=null&&o.check.isChecked()!=o.savedVisible){changed=true;break;}
        if(!changed){toast("Não há alterações para salvar.");return;}
        new AlertDialog.Builder(this).setTitle("Aplicar para todos os usuários?")
                .setMessage("As funções marcadas ficarão visíveis no menu de todos os usuários. As desmarcadas serão ocultadas.")
                .setNegativeButton("Revisar",null).setPositiveButton("Salvar",(d,w)->saveOptions()).show();
    }

    private void saveOptions() {
        save.setEnabled(false); status.setText("Salvando configuração central…");
        new Thread(() -> {
            try {
                JSONArray payload = new JSONArray();
                for(Option o:options) payload.put(new JSONObject().put("key",o.key).put("visible",o.check!=null&&o.check.isChecked()));
                JSONObject result=rpc("meunova_admin_save_feature_visibility",new JSONObject().put("p_features",payload));
                if(!result.optBoolean("ok",false)) throw new Exception();
                runOnUiThread(()->{
                    for(Option o:options) o.savedVisible=o.check!=null&&o.check.isChecked();
                    status.setText("Configuração salva e sincronizada para todos os usuários."); save.setEnabled(true);
                    toast("Funções atualizadas. O app do usuário sincroniza ao voltar à tela inicial.");
                });
            } catch(Exception ex) {
                runOnUiThread(()->{status.setText("Não foi possível salvar. Nada foi confirmado; tente novamente.");save.setEnabled(true);});
            }
        },"nova-admin-feature-save").start();
    }

    private JSONObject rpc(String name, JSONObject body) throws Exception {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)new URL(BASE+"/rest/v1/rpc/"+name).openConnection();
            c.setRequestMethod("POST");c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setDoOutput(true);
            c.setRequestProperty("apikey",KEY);c.setRequestProperty("Authorization","Bearer "+accessToken);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Cache-Control","no-store");
            byte[] data=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(data.length);
            try(OutputStream out=c.getOutputStream()){out.write(data);}
            int code=c.getResponseCode();InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();String raw=readAll(in);
            if(code<200||code>=300)throw new Exception("RPC failed");return new JSONObject(raw);
        }finally{if(c!=null)c.disconnect();}
    }

    private String readAll(InputStream in)throws Exception{if(in==null)return "{}";try(InputStream src=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]b=new byte[2048];int n;while((n=src.read(b))!=-1){if(out.size()+n>65536)throw new Exception("response too large");out.write(b,0,n);}return new String(out.toByteArray(),StandardCharsets.UTF_8);}}
    private TextView text(String value,int size,String color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.parseColor(color));t.setPadding(0,dp(4),0,dp(4));if(bold)t.setTypeface(null,android.graphics.Typeface.BOLD);return t;}
    private Button button(String title,String color){Button b=new Button(this);b.setText(title);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setBackground(round(Color.parseColor(color),color,10));return b;}
    private android.graphics.drawable.GradientDrawable round(int fill,String stroke,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));d.setStroke(dp(1),Color.parseColor(stroke));return d;}
    private LinearLayout.LayoutParams matchWrap(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(4),0,dp(4));return p;}
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+0.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
