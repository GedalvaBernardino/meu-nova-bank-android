package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

public final class AdminEditBalanceActivity extends AdminNativeActivity {
    private String account="",oldBalance="0.00";private EditText target,reason;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");oldBalance=getIntent().getStringExtra("available_balance");if(account==null)account="";if(oldBalance==null)oldBalance="0.00";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Editar saldo demonstrativo",21,BLUE,true),matchWrap());root.addView(text("Conta: "+account+"  •  Atual: "+money(oldBalance),15,INK,true),matchWrap());
        root.addView(text("O valor final substitui o saldo demonstrativo e a diferença será registrada no extrato administrativo com motivo.",13,MUTED,false),matchWrap());
        target=field("Novo saldo final (ex.: 250,00)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);target.setText(oldBalance);root.addView(target,matchWrap());
        reason=field("Motivo obrigatório (5 a 200 caracteres)",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);reason.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(200)});root.addView(reason,matchWrap());
        status=text("Nenhuma alteração é feita até a confirmação final.",12,MUTED,false);root.addView(status,matchWrap());
        android.widget.Button review=button("Revisar ajuste",GREEN),back=button("Voltar",BLUE);root.addView(review,matchWrap());root.addView(back,matchWrap());review.setOnClickListener(v->review());back.setOnClickListener(v->finish());installPage(root);
    }
    private void review(){String raw=target.getText().toString().trim(),why=reason.getText().toString().trim();if(!raw.matches("\\d{1,14}(?:[.,]\\d{1,2})?")||why.length()<5){status.setText("Informe saldo não negativo com até 2 casas decimais e motivo com no mínimo 5 caracteres.");return;}
        try{BigDecimal before=new BigDecimal(oldBalance.replace(',','.')).setScale(2,RoundingMode.UNNECESSARY);BigDecimal after=new BigDecimal(raw.replace(',','.')).setScale(2,RoundingMode.UNNECESSARY);if(after.compareTo(new BigDecimal("99999999999999.99"))>0)throw new Exception();BigDecimal delta=after.subtract(before);String direction=delta.signum()>0?"Crédito":delta.signum()<0?"Débito":"Sem diferença";String message="Conta: "+account+"\nSaldo atual: "+money(before.toPlainString())+"\nNovo saldo: "+money(after.toPlainString())+"\n"+direction+" no extrato: "+money(delta.abs().toPlainString())+"\n\nMotivo: "+why+"\n\nConfirmar o ajuste demonstrativo?";
            new AlertDialog.Builder(this).setTitle("Confirmar ajuste de saldo").setMessage(message).setNegativeButton("Voltar",null).setPositiveButton("Confirmar",(d,w)->save(after.toPlainString(),why,UUID.randomUUID().toString())).show();
        }catch(Exception e){status.setText("Saldo atual inválido. Use ponto ou vírgula e até duas casas decimais.");}}
    private void save(String amount,String why,String requestId){status.setText("Registrando ajuste com trilha de auditoria…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("action","set_balance");body.put("account_number",account);body.put("target_balance",amount);body.put("reason",why);body.put("request_id",requestId);JSONObject result=adminRequest(body);if(!result.optBoolean("ok",false))throw new Exception(result.optString("error","WALLET_EDIT_NOT_CONFIRMED"));String delta=result.optString("delta","0.00");runOnUiThread(()->{status.setText("Saldo atualizado; diferença registrada no extrato.");toast("Ajuste salvo · diferença: "+money(delta));});}catch(Exception e){String error=e.getMessage()==null?"":e.getMessage();String msg=error.contains("WALLET_EDIT_ACCOUNT_NOT_FOUND")?"A conta não foi encontrada.":error.contains("WALLET_EDIT_WALLET_NOT_FOUND")?"A carteira do usuário não foi encontrada.":error.contains("WALLET_EDIT_IDEMPOTENCY_CONFLICT")?"Esta solicitação já foi usada com dados diferentes.":error.contains("WALLET_EDIT_AMOUNT_INVALID")?"O saldo informado é inválido.":error.contains("WALLET_EDIT_REASON_INVALID")?"O motivo precisa ter entre 5 e 200 caracteres.":"Ajuste não confirmado. O saldo não foi alterado; atualize a lista antes de tentar novamente.";runOnUiThread(()->status.setText(msg));}},"nova-admin-balance-save").start();}
}
