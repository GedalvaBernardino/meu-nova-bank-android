package br.com.meunovabank.admin;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.KeyPairGeneratorSpec;
import android.util.Base64;

import org.json.JSONObject;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Calendar;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.security.auth.x500.X500Principal;

/** Guarda a conta e a senha somente cifradas com chaves protegidas pelo Android Keystore. */
final class CredentialStore {
    private static final String PREFS = "admin_login_secure_v1";
    private static final String VALUE = "encrypted_credentials";
    private static final String AES_ALIAS = "meunova_admin_credentials_aes_v1";
    private static final String RSA_ALIAS = "meunova_admin_credentials_rsa_v1";
    private CredentialStore() {}

    static final class Credentials {
        final String account, password;
        Credentials(String account, String password) { this.account=account; this.password=password; }
    }

    static boolean hasSaved(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).contains(VALUE);
    }

    static boolean save(Context context, String account, String password) {
        try {
            JSONObject obj = new JSONObject(); obj.put("account", account); obj.put("password", password);
            byte[] clear = obj.toString().getBytes(StandardCharsets.UTF_8);
            String encrypted;
            if (Build.VERSION.SDK_INT >= 23) encrypted = "A:" + Base64.encodeToString(Aes.encrypt(context, clear), Base64.NO_WRAP);
            else encrypted = "R:" + Base64.encodeToString(Rsa.encrypt(context, clear), Base64.NO_WRAP);
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(VALUE, encrypted).commit();
        } catch (Exception ignored) { return false; }
    }

    static Credentials read(Context context) {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(VALUE, null);
        if (stored == null || stored.length() < 4) return null;
        try {
            int split = stored.indexOf(':'); if (split < 0) throw new Exception();
            String mode = stored.substring(0, split);
            byte[] data = Base64.decode(stored.substring(split + 1), Base64.NO_WRAP);
            byte[] clear = "A".equals(mode) ? Aes.decrypt(context, data) : "R".equals(mode) ? Rsa.decrypt(context, data) : null;
            if (clear == null) throw new Exception();
            JSONObject obj = new JSONObject(new String(clear, StandardCharsets.UTF_8));
            String account = obj.optString("account", ""), password = obj.optString("password", "");
            if (!account.matches("\\d{6}") || !password.matches("\\d{8}")) throw new Exception();
            return new Credentials(account, password);
        } catch (Exception ignored) {
            clear(context);
            return null;
        }
    }

    static void clear(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(VALUE).commit();
        try {
            KeyStore store = KeyStore.getInstance("AndroidKeyStore"); store.load(null);
            if (store.containsAlias(AES_ALIAS)) store.deleteEntry(AES_ALIAS);
            if (store.containsAlias(RSA_ALIAS)) store.deleteEntry(RSA_ALIAS);
        } catch (Exception ignored) { }
    }

    private static final class Aes {
        private static SecretKey key(Context context) throws Exception {
            KeyStore store=KeyStore.getInstance("AndroidKeyStore"); store.load(null);
            if (store.containsAlias(AES_ALIAS)) return (SecretKey)store.getKey(AES_ALIAS,null);
            KeyGenerator generator=KeyGenerator.getInstance("AES","AndroidKeyStore");
            generator.init(new android.security.keystore.KeyGenParameterSpec.Builder(AES_ALIAS,3)
                    .setBlockModes("GCM").setEncryptionPaddings("NoPadding").setRandomizedEncryptionRequired(true).setKeySize(256).build());
            return generator.generateKey();
        }
        static byte[] encrypt(Context context,byte[] clear)throws Exception{
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key(context));
            byte[] iv=cipher.getIV(), encrypted=cipher.doFinal(clear);
            ByteBuffer result=ByteBuffer.allocate(1+iv.length+encrypted.length);result.put((byte)iv.length).put(iv).put(encrypted);return result.array();
        }
        static byte[] decrypt(Context context,byte[] data)throws Exception{
            ByteBuffer input=ByteBuffer.wrap(data);int len=input.get()&255;if(len<12||len>16||input.remaining()<=len)throw new Exception();
            byte[] iv=new byte[len],encrypted=new byte[input.remaining()-len];input.get(iv);input.get(encrypted);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(context),new GCMParameterSpec(128,iv));return cipher.doFinal(encrypted);
        }
    }

    private static final class Rsa {
        private static KeyPair pair(Context context) throws Exception {
            KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
            if(store.containsAlias(RSA_ALIAS)){
                PrivateKey privateKey=(PrivateKey)store.getKey(RSA_ALIAS,null);
                java.security.cert.Certificate certificate=store.getCertificate(RSA_ALIAS);
                return new KeyPair(certificate.getPublicKey(),privateKey);
            }
            Calendar start=Calendar.getInstance(),end=Calendar.getInstance();end.add(Calendar.YEAR,30);
            AlgorithmParameterSpec spec=new KeyPairGeneratorSpec.Builder(context).setAlias(RSA_ALIAS)
                    .setSubject(new X500Principal("CN=Meu Nova Admin Login"))
                    .setSerialNumber(BigInteger.ONE).setStartDate(start.getTime()).setEndDate(end.getTime()).setKeySize(2048).build();
            KeyPairGenerator generator=KeyPairGenerator.getInstance("RSA","AndroidKeyStore");generator.initialize(spec);return generator.generateKeyPair();
        }
        static byte[] encrypt(Context context,byte[] clear)throws Exception{
            Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");cipher.init(Cipher.ENCRYPT_MODE,pair(context).getPublic());return cipher.doFinal(clear);
        }
        static byte[] decrypt(Context context,byte[] encrypted)throws Exception{
            Cipher cipher=Cipher.getInstance("RSA/ECB/PKCS1Padding");cipher.init(Cipher.DECRYPT_MODE,pair(context).getPrivate());return cipher.doFinal(encrypted);
        }
    }
}
