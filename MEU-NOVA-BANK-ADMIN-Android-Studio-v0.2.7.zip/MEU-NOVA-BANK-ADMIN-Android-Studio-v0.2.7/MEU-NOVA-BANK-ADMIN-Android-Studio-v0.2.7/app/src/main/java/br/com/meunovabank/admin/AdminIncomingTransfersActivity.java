package br.com.meunovabank.admin;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public final class AdminIncomingTransfersActivity extends AdminNativeActivity {
    private LinearLayout list;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=page();
        LinearLayout header=new LinearLayout(this);header.setOrientation(LinearLayout.HORIZONTAL);TextView title=text("Transferências recebidas",21,BLUE,true);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));Button refresh=button("Atualizar",BLUE);header.addView(refresh,new LinearLayout.LayoutParams(-2,dp(44)));root.addView(header,matchWrap());
        root.addView(text("Fluxo demonstrativo entre livros internos. O crédito de destino só pode ocorrer após a confirmação do débito na origem; isso não representa liquidação externa de dinheiro.",12,MUTED,false),matchWrap());
        status=text("Carregando recebimentos…",13,MUTED,false);root.addView(status,matchWrap());list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));Button back=button("Voltar aos usuários",BLUE);root.addView(back,matchWrap());
        refresh.setOnClickListener(v->load());back.setOnClickListener(v->finish());installPage(root);
    }
    @Override protected void onResume(){super.onResume();if(list!=null)load();}
    private void load(){if(accessToken.isEmpty()){status.setText("Sessão administrativa ausente. Entre novamente.");return;}status.setText("Carregando recebimentos…");
        new Thread(()->{try{JSONArray rows=adminRequest(new JSONObject().put("action","interbank_list")).optJSONArray("transfers");if(rows==null)throw new Exception();runOnUiThread(()->render(rows));}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível carregar os recebimentos."));}},"nova-admin-incoming-list").start();}
    private void render(JSONArray rows){list.removeAllViews();status.setText(rows.length()+" recebimento(s)");if(rows.length()==0){list.addView(text("Nenhum recebimento encontrado.",14,MUTED,false),matchWrap());return;}
        for(int i=0;i<rows.length();i++){JSONObject item=rows.optJSONObject(i);if(item==null)continue;String id=item.optString("transfer_id",""),sender=item.optString("sender_name","Remetente"),account=item.optString("sender_account",""),recipient=item.optString("recipient_account",""),amount=item.optString("amount","0"),state=item.optString("status",""),source=item.optString("source_commit_status","");
            LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(13),dp(14),dp(13));card.setBackground(round(Color.WHITE,"#D8E0EA",14));LinearLayout.LayoutParams cp=matchWrap();cp.setMargins(0,dp(6),0,dp(7));list.addView(card,cp);
            card.addView(text(sender+" · conta "+account,16,BLUE,true),matchWrap());card.addView(text(("credited".equals(state)?"Crédito lançado · ":"Valor solicitado · ")+"MEU NOVA "+recipient+" • "+money(amount),14,"credited".equals(state)?GREEN:BLUE,true),matchWrap());card.addView(text("Status: "+stateLabel(state)+" • origem: "+source+"\nID: "+id,12,"credited".equals(state)?GREEN:MUTED,false),matchWrap());
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);card.addView(actions,matchWrap());boolean reviewable="pending_admin".equals(state)||"source_failed".equals(state)||"approved_waiting_source".equals(state);
            if(reviewable){String label="pending_admin".equals(state)?"Aprovar recebimento":"source_failed".equals(state)?"Tentar novamente":"Retomar processamento";Button approve=button(label,GREEN);actions.addView(approve,new LinearLayout.LayoutParams(0,dp(46),1));approve.setOnClickListener(v->openAction(item,"approve"));}
            if("pending_admin".equals(state)||"source_failed".equals(state)){Button reject=button("Rejeitar",RED);actions.addView(reject,new LinearLayout.LayoutParams(0,dp(46),1));reject.setOnClickListener(v->openAction(item,"reject"));}
            if("rejected".equals(state)||"credited".equals(state)){Button notify=button("Repetir aviso à origem",BLUE);actions.addView(notify,new LinearLayout.LayoutParams(-1,dp(46)));notify.setOnClickListener(v->openAction(item,"notify"));}
        }
    }
    private void openAction(JSONObject row,String action){Intent i=new Intent(this,AdminTransferActionActivity.class);i.putExtra("admin_access_token",accessToken);i.putExtra("transfer_id",row.optString("transfer_id",""));i.putExtra("sender_name",row.optString("sender_name","Remetente"));i.putExtra("sender_account",row.optString("sender_account",""));i.putExtra("recipient_account",row.optString("recipient_account",""));i.putExtra("amount",row.optString("amount","0"));i.putExtra("status",row.optString("status",""));i.putExtra("decision",action);startActivity(i);}
    private String stateLabel(String state){switch(state){case "pending_admin":return "Aguardando aprovação MEU NOVA";case "approved_waiting_source":return "Aprovado · aguardando débito na origem";case "source_failed":return "Débito não confirmado · sem crédito";case "credited":return "Creditado e lançado no extrato";case "rejected":return "Recusado · sem movimentação";default:return "Processamento pendente";}}
}
