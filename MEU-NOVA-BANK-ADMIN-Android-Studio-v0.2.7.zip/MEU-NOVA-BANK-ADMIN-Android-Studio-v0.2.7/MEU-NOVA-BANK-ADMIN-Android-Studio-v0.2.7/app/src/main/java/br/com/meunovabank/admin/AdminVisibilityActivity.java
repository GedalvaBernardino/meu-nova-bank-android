package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class AdminVisibilityActivity extends AdminNativeActivity {
    private String account="";private boolean hidden;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";hidden=getIntent().getBooleanExtra("is_hidden",false);
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text(hidden?"Reexibir cadastro":"Ocultar cadastro",21,BLUE,true),matchWrap());root.addView(text("Conta: "+account,15,INK,true),matchWrap());
        root.addView(text("Esta opção controla apenas a exibição do cadastro na lista administrativa. Não apaga perfil, saldo nem histórico.",14,MUTED,false),matchWrap());
        status=text("Confirme a ação para registrar a alteração.",12,MUTED,false);root.addView(status,matchWrap());
        android.widget.Button action=button(hidden?"Reexibir usuário":"Ocultar usuário",hidden?GREEN:RED),back=button("Voltar",BLUE);root.addView(action,matchWrap());root.addView(back,matchWrap());
        action.setOnClickListener(v->confirm());back.setOnClickListener(v->finish());installPage(root);
    }
    private void confirm(){String action=hidden?"Reexibir":"Ocultar";new AlertDialog.Builder(this).setTitle(action+" cadastro?").setMessage("Conta: "+account+"\n\nNenhum dado financeiro será apagado.").setNegativeButton("Cancelar",null).setPositiveButton(action,(d,w)->save()).show();}
    private void save(){status.setText("Registrando alteração…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("action",hidden?"unhide":"hide");body.put("account_number",account);adminRequest(body);runOnUiThread(()->{status.setText(hidden?"Cadastro reexibido.":"Cadastro oculto na lista.");toast(hidden?"Usuário reexibido.":"Usuário oculto.");});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível confirmar a alteração."));}},"nova-admin-visibility").start();}
}
