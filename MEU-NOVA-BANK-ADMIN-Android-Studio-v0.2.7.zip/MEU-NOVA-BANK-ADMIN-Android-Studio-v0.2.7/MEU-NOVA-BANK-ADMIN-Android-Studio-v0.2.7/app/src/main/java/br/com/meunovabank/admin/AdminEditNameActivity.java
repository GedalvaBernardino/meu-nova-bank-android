package br.com.meunovabank.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;

public final class AdminEditNameActivity extends AdminNativeActivity {
    private String account=""; private EditText name; private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);account=getIntent().getStringExtra("account_number");if(account==null)account="";String old=getIntent().getStringExtra("display_name");if(old==null)old="";
        LinearLayout root=page();root.addView(text("MEU NOVA BANK ADMIN",12,RED,true),matchWrap());root.addView(text("Editar nome do usuário",21,BLUE,true),matchWrap());root.addView(text("Conta: "+account,15,INK,true),matchWrap());
        name=field("Nome completo",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);name.setText(old);root.addView(name,matchWrap());
        status=text("A alteração será registrada no perfil administrativo.",12,MUTED,false);root.addView(status,matchWrap());
        android.widget.Button save=button("Revisar e salvar",GREEN),back=button("Voltar",BLUE);root.addView(save,matchWrap());root.addView(back,matchWrap());
        save.setOnClickListener(v->confirmSave());back.setOnClickListener(v->finish());installPage(root);
    }
    private void confirmSave(){String value=name.getText().toString().trim().replaceAll("\\s+"," ");if(value.length()<2||value.length()>120){status.setText("Informe um nome entre 2 e 120 caracteres.");return;}
        new AlertDialog.Builder(this).setTitle("Confirmar alteração?").setMessage("Conta: "+account+"\nNovo nome: "+value+"\n\nSalvar no perfil do usuário?").setNegativeButton("Voltar",null).setPositiveButton("Salvar",(d,w)->save(value)).show();}
    private void save(String value){status.setText("Salvando nome…");new Thread(()->{try{JSONObject body=new JSONObject();body.put("action","rename");body.put("account_number",account);body.put("display_name",value);adminRequest(body);runOnUiThread(()->{status.setText("Nome atualizado.");toast("Nome atualizado.");});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível confirmar a alteração. Tente novamente."));}},"nova-admin-rename").start();}
}
