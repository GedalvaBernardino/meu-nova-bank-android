package br.com.meunovabank.digital;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

/** Cartão visual demonstrativo com chip EMV desenhado no Canvas. */
public final class MeuNovaCardView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private String cardholder = "TITULAR DO CARTÃO";
    private boolean demoActive = false;
    private int demoGeneration = 0;
    private boolean stateAvailable = false;
    private float density, scaledDensity;

    public MeuNovaCardView(Context context) { super(context); init(); }
    public MeuNovaCardView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    public MeuNovaCardView(Context context, AttributeSet attrs, int style) { super(context, attrs, style); init(); }

    private void init() {
        density = getResources().getDisplayMetrics().density;
        scaledDensity = getResources().getDisplayMetrics().scaledDensity;
        GradientDrawable outline = new GradientDrawable();
        outline.setColor(Color.TRANSPARENT);
        outline.setCornerRadius(dp(25));
        setBackground(outline);
        if (Build.VERSION.SDK_INT >= 21) {
            setClipToOutline(true);
            setElevation(dp(6));
        }
        setContentDescription("Meu Nova Card demonstrativo, com número mascarado e chip metálico. Não realiza pagamentos.");
    }

    public void setCardholderName(String name) {
        String clean = name == null ? "" : name.trim().replaceAll("\\s+", " ");
        cardholder = clean.isEmpty() ? "TITULAR DO CARTÃO" : clean.toUpperCase(java.util.Locale.ROOT);
        invalidate();
    }

    public void setDemoCardState(boolean active, int generation, boolean available) {
        demoActive = active;
        demoGeneration = Math.max(0, generation);
        stateAvailable = available;
        setContentDescription(!available
                ? "Estado do cartão demonstrativo indisponível; ações desativadas."
                : active ? "Cartão DEMO Meu Nova, identificador fictício inválido para pagamentos."
                : "Cartão demonstrativo bloqueado ou não ativado; sem credenciais de pagamento.");
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        float radius = dp(25);
        RectF card = new RectF(dp(1), dp(1), w - dp(1), h - dp(1));
        Path clip = new Path();
        clip.addRoundRect(card, radius, radius, Path.Direction.CW);
        canvas.save();
        canvas.clipPath(clip);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(0, 0, w, h,
                new int[]{Color.rgb(12, 35, 68), Color.rgb(24, 70, 112), Color.rgb(13, 105, 91)},
                new float[]{0f, .58f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(card, radius, radius, paint);
        paint.setShader(null);

        // Permanent overlay prevents the card face from implying a usable payment card.
        paint.setColor(Color.argb(stateAvailable && demoActive ? 72 : 150, 5, 12, 22));
        canvas.drawRoundRect(card, radius, radius, paint);
        paint.setColor(Color.WHITE);
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        paint.setTextSize(sp(21));
        String overlay = !stateAvailable ? "INDISPONÍVEL" : (demoActive ? "DEMONSTRAÇÃO" : "BLOQUEADO");
        float overlayWidth = paint.measureText(overlay);
        canvas.drawText(overlay, Math.max(dp(12), (w-overlayWidth)/2), h*.59f, paint);
        paint.setTextSize(sp(9));
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        String sub = "NÃO É CARTÃO DE PAGAMENTO";
        canvas.drawText(sub, Math.max(dp(12), (w-paint.measureText(sub))/2), h*.68f, paint);

        // Soft glass-like light blooms and diagonal bands.
        paint.setColor(Color.argb(24, 132, 220, 236));
        canvas.drawCircle(w * .91f, h * .12f, w * .32f, paint);
        paint.setColor(Color.argb(18, 255, 255, 255));
        Path sweep = new Path();
        sweep.moveTo(w * .48f, 0); sweep.lineTo(w * .70f, 0); sweep.lineTo(w * .31f, h); sweep.lineTo(w * .12f, h); sweep.close();
        canvas.drawPath(sweep, paint);
        paint.setColor(Color.argb(30, 255, 255, 255));
        canvas.drawCircle(w * .80f, h * .62f, w * .28f, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.argb(92, 215, 242, 255));
        canvas.drawRoundRect(card, radius, radius, paint);
        paint.setStyle(Paint.Style.FILL);

        drawBrand(canvas, w, h);
        drawNumberAndHolder(canvas, w, h);
        canvas.restore();
    }

    private void drawBrand(Canvas canvas, float w, float h) {
        float left = w * .075f, top = h * .14f;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        paint.setTextSize(sp(15));
        paint.setColor(Color.WHITE);
        canvas.drawText("MEU NOVA", left, top + sp(15), paint);
        paint.setTextSize(sp(9));
        paint.setColor(Color.rgb(136, 235, 209));
        canvas.drawText("CARD", left + dp(1), top + sp(29), paint);

        float pillW = dp(48), pillH = dp(21);
        RectF pill = new RectF(w - dp(66), dp(17), w - dp(18), dp(17) + pillH);
        paint.setColor(Color.argb(46, 255, 255, 255));
        canvas.drawRoundRect(pill, dp(12), dp(12), paint);
        paint.setTextSize(sp(8));
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        paint.setColor(Color.rgb(220, 246, 244));
        canvas.drawText("DEMO", pill.left + dp(11), pill.top + dp(14), paint);
    }

    private void drawChip(Canvas canvas, float w, float h) {
        float x = w * .075f, y = h * .355f, chipW = w * .17f, chipH = h * .235f;
        RectF chip = new RectF(x, y, x + chipW, y + chipH);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new LinearGradient(x, y, x + chipW, y + chipH,
                new int[]{Color.rgb(255, 232, 164), Color.rgb(203, 153, 61), Color.rgb(247, 213, 129)}, null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(chip, dp(7), dp(7), paint);
        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1));
        paint.setColor(Color.argb(190, 126, 87, 32));
        canvas.drawRoundRect(chip, dp(7), dp(7), paint);

        float x1 = x + chipW * .34f, x2 = x + chipW * .66f;
        float y1 = y + chipH * .34f, y2 = y + chipH * .67f;
        paint.setStrokeWidth(dp(1.1f));
        paint.setColor(Color.argb(210, 134, 94, 39));
        canvas.drawLine(x1, y + dp(2), x1, y + chipH - dp(2), paint);
        canvas.drawLine(x2, y + dp(2), x2, y + chipH - dp(2), paint);
        canvas.drawLine(x + dp(2), y1, x + chipW - dp(2), y1, paint);
        canvas.drawLine(x + dp(2), y2, x + chipW - dp(2), y2, paint);
        RectF center = new RectF(x1 + dp(2), y1 + dp(2), x2 - dp(2), y2 - dp(2));
        paint.setColor(Color.argb(35, 120, 74, 22));
        paint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(center, dp(3), dp(3), paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(Color.argb(115, 255, 246, 208));
        canvas.drawRoundRect(new RectF(chip.left + dp(2), chip.top + dp(2), chip.right - dp(2), chip.bottom - dp(2)), dp(6), dp(6), paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawContactless(Canvas canvas, float w, float h) {
        float cx = w - dp(37), cy = h * .40f;
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(Color.argb(220, 216, 244, 248));
        for (int i = 0; i < 3; i++) {
            float r = dp(7 + i * 5);
            RectF arc = new RectF(cx - r, cy - r, cx + r, cy + r);
            canvas.drawArc(arc, -55, 110, false, paint);
        }
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(cx - dp(13), cy, dp(2), paint);
    }

    private void drawNumberAndHolder(Canvas canvas, float w, float h) {
        float left = w * .075f;
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        paint.setColor(Color.WHITE);
        paint.setTextSize(sp(15));
        canvas.drawText("DEMO  ·  INVÁLIDO", left, h * .82f, paint);
        paint.setColor(Color.argb(180, 217, 235, 248));
        paint.setTextSize(sp(7));
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        canvas.drawText("TITULAR", left, h * .835f, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(sp(9));
        paint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        String holder = ellipsize(cardholder, 23);
        canvas.drawText(holder, left, h * .91f, paint);
        paint.setColor(Color.argb(220, 255, 255, 255));
        paint.setTextSize(sp(8));
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        canvas.drawText("SEM PAGAMENTOS", w * .61f, h * .91f, paint);
    }

    private String ellipsize(String value, int max) { return value.length() <= max ? value : value.substring(0, max - 1) + "…"; }
    private float dp(float v) { return v * density; }
    private float sp(float v) { return v * scaledDensity; }
}
