package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLEncoder;
import java.text.NumberFormat;
import java.util.Locale;

/** DEM-only native funding-source chooser; the server RPC remains authoritative. */
public final class DemFundingSourceActivity extends Activity {
    private String recipient;
    private BigDecimal amount, fee, cardCharge;
    private LinearLayout options;
    private TextView status;
    private BigDecimal balanceAvailable, cardAvailable, cardLimitValue, overdraftAvailable;
    private boolean balanceLoaded, cardLoaded, overdraftLoaded, cardActive, overdraftActive;
    private String selected = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        recipient = getIntent().getStringExtra("recipient");
        try { amount = new BigDecimal(getIntent().getStringExtra("amount")).setScale(2, RoundingMode.UNNECESSARY); }
        catch (Exception e) { finish(); return; }
        fee = amount.multiply(new BigDecimal("0.037")).setScale(2, RoundingMode.HALF_UP);
        cardCharge = amount.add(fee);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.column(this);
        Ui.section(this, root, "Escolha a origem", "Transferência DEM · débito demonstrativo");
        Ui.card(this, root, "Destino e valor", "Conta DEM " + recipient + " · crédito de " + money(amount), null);
        Ui.card(this, root, "Somente demonstração", "Esta escolha afeta apenas o ledger DEM interno. Não aciona Pix, bancos ou redes reais e não cria dívida real. Cartão: taxa demonstrativa de 3,7%.", null);
        TextView label = Ui.text(this, "Disponibilidade consultada agora · o servidor valida novamente ao confirmar", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = Ui.d(this, 10); lp.bottomMargin = Ui.d(this, 8); root.addView(label, lp);
        options = new LinearLayout(this); options.setOrientation(LinearLayout.VERTICAL); root.addView(options, new LinearLayout.LayoutParams(-1, -2));
        status = Ui.text(this, "Consultando saldo e limites demonstrativos…", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = Ui.d(this, 8); root.addView(status, sp);
        TextView back = Ui.text(this, "‹  Voltar", 15, Palette.NAVY, true); back.setGravity(Gravity.CENTER_VERTICAL); back.setPadding(0, Ui.d(this, 20), 0, Ui.d(this, 12)); back.setClickable(true); back.setOnClickListener(v -> finish()); root.addView(back);
        scroll.addView(root); setContentView(scroll);
        loadAvailability();
    }

    private void loadAvailability() {
        final String account = SessionStore.accountNumber(), token = SessionStore.accessToken();
        new Thread(() -> {
            String failure = "";
            try {
                if (token.isEmpty() || !account.matches("[0-9]{6}")) throw new Exception("session");
                JSONArray rows = InterbankRest.get("customer_profiles?select=user_id,card_credit_limit,card_credit_used,demo_card_active,overdraft_user_limit,overdraft_active,overdraft_used&account_number=eq." + account + "&limit=1", token);
                if (rows.length() == 0 || rows.optJSONObject(0) == null) throw new Exception("profile");
                JSONObject profile = rows.getJSONObject(0);
                String userId = profile.optString("user_id", "");
                if (userId.isEmpty() || profile.isNull("card_credit_limit") || profile.isNull("card_credit_used") || profile.isNull("overdraft_user_limit") || profile.isNull("overdraft_used") || !profile.has("demo_card_active") || !profile.has("overdraft_active")) throw new Exception("profile_fields");
                BigDecimal cLimit = new BigDecimal(profile.getString("card_credit_limit"));
                BigDecimal cUsed = new BigDecimal(profile.getString("card_credit_used"));
                BigDecimal oLimit = new BigDecimal(profile.getString("overdraft_user_limit"));
                BigDecimal oUsed = new BigDecimal(profile.getString("overdraft_used"));
                boolean cActive = profile.getBoolean("demo_card_active"), oActive = profile.getBoolean("overdraft_active");
                JSONArray wallets = InterbankRest.get("wallets?select=available_balance&user_id=eq." + URLEncoder.encode(userId, "UTF-8") + "&limit=1", token);
                if (wallets.length() == 0 || wallets.optJSONObject(0) == null || wallets.getJSONObject(0).isNull("available_balance")) throw new Exception("wallet");
                BigDecimal b = new BigDecimal(wallets.getJSONObject(0).getString("available_balance"));
                BigDecimal c = cLimit.subtract(cUsed).max(BigDecimal.ZERO);
                BigDecimal o = oLimit.subtract(oUsed).max(BigDecimal.ZERO);
                runOnUiThread(() -> {
                    balanceAvailable = b; cardAvailable = c; cardLimitValue = cLimit; overdraftAvailable = o;
                    balanceLoaded = cardLoaded = overdraftLoaded = true; cardActive = cActive; overdraftActive = oActive;
                    renderOptions(); status.setText("Valores indicativos; limites/saldo podem mudar. A RPC DEM verifica novamente antes de registrar.");
                });
            } catch (Exception e) {
                failure = e.getMessage();
                runOnUiThread(() -> { balanceLoaded = cardLoaded = overdraftLoaded = false; renderOptions(); status.setText("Não foi possível confirmar saldo e limites agora. As origens ficam indisponíveis; tente novamente mais tarde."); });
            }
        }, "dem-funding-availability").start();
    }

    private void renderOptions() {
        options.removeAllViews();
        BigDecimal base = amount;
        addOption("balance", "Saldo", balanceLoaded ? "Disponível: " + money(balanceAvailable) + " · débito " + money(base) : "Saldo indisponível: falha ao consultar a carteira", balanceLoaded && balanceAvailable.compareTo(base) >= 0, "Saldo demonstrativo insuficiente.");
        BigDecimal cardMinimum = new BigDecimal("152.00");
        String cardDetail = !cardLoaded ? "Cartão indisponível: perfil não confirmado" : !cardActive ? "Cartão demonstrativo inativo; ative-o para usar" : cardAvailable.compareTo(cardCharge) < 0 ? "Limite insuficiente para valor + taxa de 3,7%" : "Disponível: " + money(cardAvailable) + " · débito " + money(cardCharge) + " (inclui taxa de 3,7%)";
        boolean canCard = cardLoaded && cardActive && cardAvailable.compareTo(cardCharge) >= 0 && cardLimitValue.compareTo(cardMinimum) >= 0;
        addOption("card", "Cartão de crédito", cardDetail, canCard, "O cartão precisa estar ativo e ter limite suficiente para o valor e a taxa.");
        String overdraftDetail = !overdraftLoaded ? "Cheque especial indisponível: perfil não confirmado" : !overdraftActive ? "Cheque especial demonstrativo inativo" : overdraftAvailable.compareTo(base) < 0 ? "Limite disponível insuficiente" : "Disponível: " + money(overdraftAvailable) + " · utilização " + money(base);
        addOption("overdraft", "Cheque especial", overdraftDetail, overdraftLoaded && overdraftActive && overdraftAvailable.compareTo(base) >= 0, "Ative o cheque especial ou aguarde a atualização do limite.");
    }

    private void addOption(String key, String title, String detail, boolean enabled, String reason) {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(Ui.d(this, 14), Ui.d(this, 14), Ui.d(this, 14), Ui.d(this, 14));
        row.setBackground(Ui.bg(selected.equals(key) ? Palette.PALE_BLUE : android.graphics.Color.WHITE, Ui.d(this, 17)));
        row.setAlpha(enabled ? 1f : .58f); row.setClickable(enabled); row.setFocusable(enabled);
        LinearLayout copy = new LinearLayout(this); copy.setOrientation(LinearLayout.VERTICAL);
        copy.addView(Ui.text(this, title + (selected.equals(key) ? "  ✓" : ""), 15, Palette.NAVY, true));
        TextView sub = Ui.text(this, detail + (enabled ? "" : " · " + reason), 12, Palette.MUTED, false); sub.setLineSpacing(Ui.d(this, 2), 1f);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, -2); subp.topMargin = Ui.d(this, 5); copy.addView(sub, subp);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2); rp.bottomMargin = Ui.d(this, 9); options.addView(row, rp);
        if (enabled) row.setOnClickListener(v -> confirmSource(key));
    }

    private void confirmSource(String source) {
        selected = source; renderOptions();
        String label = "balance".equals(source) ? "saldo" : "card".equals(source) ? "cartão de crédito" : "cheque especial";
        String debit = "card".equals(source) ? cardCharge : amount;
        new AlertDialog.Builder(this).setTitle("Confirmar origem")
                .setMessage("Destino: conta DEM " + recipient + "\nValor creditado: " + money(amount) + "\nDébito demonstrativo: " + money(debit) + "\nOrigem: " + label + ("card".equals(source) ? " (inclui taxa de 3,7%)" : "") + "\n\nSomente ledger demonstrativo. O servidor verificará saldo e limites atuais antes da operação; nenhuma rede bancária real será acionada.")
                .setNegativeButton("Voltar", (d, w) -> { selected = ""; renderOptions(); })
                .setPositiveButton("Confirmar", (d, w) -> {
                    android.content.Intent result = new android.content.Intent(); result.putExtra("recipient", recipient); result.putExtra("amount", amount.toPlainString()); result.putExtra("source", source); setResult(RESULT_OK, result); finish();
                }).show();
    }
    private String money(BigDecimal v) { return NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(v); }
}
