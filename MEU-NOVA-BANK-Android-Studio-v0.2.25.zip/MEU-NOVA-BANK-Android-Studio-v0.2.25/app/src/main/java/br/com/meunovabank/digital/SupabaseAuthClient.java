package br.com.meunovabank.digital;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Login por conta via Edge Function; chaves privilegiadas nunca ficam no cliente. */
public final class SupabaseAuthClient {
    private static final String FUNCTION_URL = "https://hzgslpskmyzczqquendt.supabase.co/functions/v1/account-login";
    static final String PUBLISHABLE_KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private SupabaseAuthClient() {}

    public interface Callback { void done(boolean success, String userMessage); }

    public static void login(Context context, String account, String password, Callback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("account", account);
                body.put("password", password);
                connection = (HttpURLConnection) new URL(FUNCTION_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("apikey", PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + PUBLISHABLE_KEY);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Cache-Control", "no-store");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                String response = readAll(stream);
                if (code >= 200 && code < 300) {
                    JSONObject session = new JSONObject(response);
                    String access = session.optString("access_token", "");
                    String refresh = session.optString("refresh_token", "");
                    if (access.isEmpty() || refresh.isEmpty()) throw new IllegalStateException("Sessão incompleta");
                    SessionStore.set(access, refresh, account);
                    callback.done(true, "");
                } else if (code == 401 || code == 429) {
                    callback.done(false, "Não foi possível entrar. Confira seus dados ou tente novamente mais tarde.");
                } else {
                    callback.done(false, "O serviço de acesso está indisponível. Tente novamente mais tarde.");
                }
            } catch (Exception error) {
                callback.done(false, "Não foi possível conectar ao serviço de acesso. Confira sua conexão e tente novamente.");
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "meunova-login").start();
    }

    /** Refreshes the current rotating refresh token for authenticated RPC retries. */
    public static synchronized boolean refreshSessionBlocking(Context context) {
        final String refresh = SessionStore.refreshToken(), account = SessionStore.accountNumber();
        if (refresh.isEmpty()) return false;
        HttpURLConnection connection = null;
        try {
            JSONObject body = new JSONObject(); body.put("refresh_token", refresh);
            connection = (HttpURLConnection) new URL("https://hzgslpskmyzczqquendt.supabase.co/auth/v1/token?grant_type=refresh_token").openConnection();
            connection.setRequestMethod("POST"); connection.setConnectTimeout(12000); connection.setReadTimeout(18000); connection.setDoOutput(true);
            connection.setRequestProperty("apikey", PUBLISHABLE_KEY);
            connection.setRequestProperty("Authorization", "Bearer " + PUBLISHABLE_KEY);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Cache-Control", "no-store");
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String response = readAll(stream);
            if (code < 200 || code >= 300) return false;
            JSONObject session = new JSONObject(response);
            String access = session.optString("access_token", ""), nextRefresh = session.optString("refresh_token", "");
            if (access.isEmpty() || nextRefresh.isEmpty()) return false;
            SessionStore.set(access, nextRefresh, account);
            try { SessionStore.persist(context); } catch (Exception ignored) { }
            return true;
        } catch (Exception ignored) { return false; }
        finally { if (connection != null) connection.disconnect(); }
    }

    /** Restaura a sessão salva usando refresh token; nunca relê ou armazena a senha. */
    public static void restoreSavedSession(Context context, Callback callback) {
        if (!SessionStore.restore(context)) {
            callback.done(false, "Não há uma sessão salva neste aparelho.");
            return;
        }
        final String refresh = SessionStore.refreshToken();
        final String account = SessionStore.accountNumber();
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject(); body.put("refresh_token", refresh);
                connection = (HttpURLConnection) new URL("https://hzgslpskmyzczqquendt.supabase.co/auth/v1/token?grant_type=refresh_token").openConnection();
                connection.setRequestMethod("POST"); connection.setConnectTimeout(15000); connection.setReadTimeout(20000); connection.setDoOutput(true);
                connection.setRequestProperty("apikey", PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + PUBLISHABLE_KEY);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Cache-Control", "no-store");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int code = connection.getResponseCode();
                InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                String response = readAll(stream);
                if (code >= 200 && code < 300) {
                    JSONObject session = new JSONObject(response);
                    String access = session.optString("access_token", ""), nextRefresh = session.optString("refresh_token", "");
                    if (access.isEmpty() || nextRefresh.isEmpty()) throw new IllegalStateException("Sessão incompleta");
                    SessionStore.set(access, nextRefresh, account);
                    try { SessionStore.persist(context); } catch (Exception ignored) { SessionStore.clearSaved(context); }
                    callback.done(true, "");
                } else if (code == 400 || code == 401) {
                    SessionStore.clear(context);
                    callback.done(false, "Sua sessão expirou. Entre novamente com sua conta e senha.");
                } else {
                    callback.done(false, "Não foi possível restaurar agora. Você ainda pode entrar manualmente.");
                }
            } catch (Exception error) {
                callback.done(false, "Não foi possível restaurar agora. Confira sua conexão ou entre manualmente.");
            } finally { if (connection != null) connection.disconnect(); }
        }, "meunova-session-refresh").start();
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int n;
            while ((n = in.read(buffer)) != -1) {
                if (out.size() + n > 8192) throw new IllegalStateException("Resposta acima do limite");
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
