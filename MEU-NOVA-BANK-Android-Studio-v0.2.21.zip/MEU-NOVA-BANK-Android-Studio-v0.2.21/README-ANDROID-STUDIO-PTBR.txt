MEU NOVA BANK BR DIGITAL — projeto Android Studio

Pacote: br.com.meunovabank.digital
Versão: 0.2.15-sem-top (versionCode 26)
Compatibilidade: minSdk 21 (Android 5.0), targetSdk 37 (Android 17).

Abra a pasta raiz deste projeto no Android Studio. O projeto usa Android Gradle Plugin 8.9.2 e compileSdk 37; instale a plataforma Android API 37 quando solicitado.

O código-fonte inclui o cliente nativo e os recursos visuais atuais; a Activity e o cliente TOP não fazem parte desta versão.

Por segurança, chaves privadas, senhas e arquivos de assinatura foram excluídos. É possível compilar uma versão de depuração no Android Studio. Para gerar uma release instalável por cima de outra release, configure sua própria chave de assinatura; ela não está neste arquivo.

Recuperação de senha: informe o número da conta de exatamente 6 dígitos. O servidor localiza o e-mail já confirmado para essa conta e solicita um link de recuperação do Supabase Auth. A resposta do app não revela se a conta existe. O link recebido por e-mail deve ser aberto neste aparelho; só a sessão/token de recuperação validado pelo Supabase permite definir uma nova senha numérica de exatamente 8 dígitos. O número da conta, sozinho, nunca autoriza a troca. O fluxo usa a Edge Function `account-password-recovery`; consulte PASSWORD-RECOVERY-BACKEND.md para seu contrato e requisitos de configuração. A entrega do e-mail depende da configuração de recuperação/e-mail do projeto Supabase.

Este projeto Supabase e o alocador atual aceitam somente contas de 6 dígitos; números de 7 dígitos não são suportados. Nunca coloque service_role ou credenciais privadas de e-mail no aplicativo.


Crédito e Transferência DEM (demo):
- App 0.2.17 mostra o limite configurado de empréstimo e de Meu Nova Card, sem oferecer crédito real.
- Taxa de 3,7% é indicada apenas como taxa por operação de transferência no cartão; essa operação não está habilitada.
- Taxa de 4,8% para empréstimo não informa período/base. Não são calculadas parcelas ou custo total.
- Transferência DEM segue apenas como revisão: sem débito/crédito de saldo e sem comprovante financeiro.
