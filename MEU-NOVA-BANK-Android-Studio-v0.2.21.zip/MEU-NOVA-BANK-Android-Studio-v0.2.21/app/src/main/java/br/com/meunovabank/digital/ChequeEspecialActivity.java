package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** User selects/activates a display-only limit within the maximum configured by Admin. */
public final class ChequeEspecialActivity extends Activity {
    private EditText selectedLimit;
    private TextView maximumText,currentText,status;
    private Button activate,deactivate;
    private String adminLimit="0.00", userLimit="0.00";
    private boolean active=false, loaded=false;

    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Cheque especial","Ativação demonstrativa do limite da sua conta");
        Ui.card(this,root,"Importante","Este limite é apenas visual e demonstrativo. Não é crédito real, não altera saldo e não pode ser usado em pagamentos ou transferências.",null);
        maximumText=Ui.text(this,"Máximo definido pelo Admin: carregando…",14,Palette.NAVY,true);LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=Ui.d(this,8);root.addView(maximumText,mp);
        currentText=Ui.text(this,"Status atual: carregando…",13,Palette.MUTED,false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.d(this,5);root.addView(currentText,cp);
        selectedLimit=Ui.input(this,"Seu limite · R$ 50 a R$ 90.000",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,Ui.d(this,54));fp.topMargin=Ui.d(this,14);root.addView(selectedLimit,fp);
        status=Ui.text(this,"Consultando configuração protegida…",13,Palette.MUTED,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.d(this,9);root.addView(status,sp);
        activate=Ui.button(this,"Ativar / atualizar meu limite",Palette.NAVY);LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,Ui.d(this,52));ap.topMargin=Ui.d(this,12);root.addView(activate,ap);
        deactivate=Ui.button(this,"Desativar limite",Palette.RED);LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,Ui.d(this,52));dp.topMargin=Ui.d(this,8);root.addView(deactivate,dp);
        activate.setEnabled(false);deactivate.setEnabled(false);activate.setOnClickListener(v->reviewActivation());deactivate.setOnClickListener(v->confirmDeactivation());setContentView(root);loadSettings();
    }

    private void loadSettings(){String token=SessionStore.accessToken(),account=SessionStore.accountNumber();if(token.isEmpty()||!account.matches("[0-9]{6}")){status.setText("Entre novamente para consultar o limite da sua conta.");return;}new Thread(()->{try{JSONArray rows=InterbankRest.get("customer_profiles?select=overdraft_admin_limit,overdraft_user_limit,overdraft_active&account_number=eq."+account+"&limit=1",token);if(rows.length()==0)throw new Exception();JSONObject p=rows.optJSONObject(0);String cap=p.optString("overdraft_admin_limit","0.00"),chosen=p.optString("overdraft_user_limit","0.00");boolean enabled=p.optBoolean("overdraft_active",false);runOnUiThread(()->{adminLimit=cap;userLimit=chosen;active=enabled;loaded=true;maximumText.setText("Máximo definido pelo Admin: "+money(adminLimit));currentText.setText("Status: "+(active?"ativo · seu limite "+money(userLimit):"desativado"));selectedLimit.setText(active?userLimit:(Double.parseDouble(adminLimit)>=50?adminLimit:""));boolean canUse=Double.parseDouble(adminLimit)>=50;activate.setEnabled(canUse);deactivate.setEnabled(active);status.setText(canUse?"Escolha qualquer valor entre R$ 50 e o máximo configurado.":"O Admin ainda não configurou um máximo para esta conta.");});}catch(Exception e){runOnUiThread(()->status.setText("Não foi possível carregar a configuração agora. Tente novamente."));}},"nova-user-overdraft-load").start();}

    private void reviewActivation(){if(!loaded)return;BigDecimal value;try{value=new BigDecimal(selectedLimit.getText().toString().trim().replace(',','.'));}catch(Exception e){status.setText("Informe um valor entre R$ 50 e R$ 90.000.");return;}BigDecimal cap=new BigDecimal(adminLimit);if(value.compareTo(new BigDecimal("50.00"))<0||value.compareTo(new BigDecimal("90000.00"))>0){status.setText("Seu limite deve ficar entre R$ 50 e R$ 90.000.");return;}if(value.compareTo(cap)>0){status.setText("O valor não pode superar o máximo definido pelo Admin: "+money(adminLimit)+".");return;}String formatted=value.setScale(2,RoundingMode.HALF_UP).toPlainString();new AlertDialog.Builder(this).setTitle(active?"Atualizar seu limite?":"Ativar seu limite demonstrativo?").setMessage("Seu valor escolhido: R$ "+formatted+"\nMáximo definido pelo Admin: "+money(adminLimit)+"\n\nIsto não habilita crédito real nem movimenta dinheiro.").setNegativeButton("Revisar",null).setPositiveButton(active?"Atualizar":"Ativar",(d,w)->save(true,formatted)).show();}

    private void confirmDeactivation(){if(!loaded||!active)return;new AlertDialog.Builder(this).setTitle("Desativar seu limite?").setMessage("O limite demonstrativo ficará inativo. Nenhum saldo ou transação será alterado.").setNegativeButton("Manter ativo",null).setPositiveButton("Desativar",(d,w)->save(false,userLimit)).show();}

    private void save(boolean enabled,String amount){activate.setEnabled(false);deactivate.setEnabled(false);status.setText("Salvando preferência…");new Thread(()->{try{JSONObject req=new JSONObject();req.put("p_user_limit",amount);req.put("p_is_active",enabled);JSONObject result=InterbankRest.rpc("meunova_set_user_overdraft",SessionStore.accessToken(),req);if(!result.optBoolean("ok",false))throw new Exception("Overdraft update rejected");runOnUiThread(()->{status.setText(enabled?"Seu limite demonstrativo está ativo.":"Seu limite demonstrativo foi desativado.");loadSettings();});}catch(Exception e){runOnUiThread(()->{status.setText("Não foi possível atualizar. Verifique se o valor está dentro do máximo do Admin.");activate.setEnabled(Double.parseDouble(adminLimit)>=50);deactivate.setEnabled(active);});}},"nova-user-overdraft-save").start();}

    private String money(String raw){try{DecimalFormatSymbols s=new DecimalFormatSymbols(new Locale("pt","BR"));return new DecimalFormat("R$ #,##0.00",s).format(new BigDecimal(raw));}catch(Exception e){return "R$ 0,00";}}
}
