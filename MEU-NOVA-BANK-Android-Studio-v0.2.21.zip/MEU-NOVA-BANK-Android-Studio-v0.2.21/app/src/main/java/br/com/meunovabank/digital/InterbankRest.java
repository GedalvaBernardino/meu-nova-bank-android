package br.com.meunovabank.digital;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class InterbankRest {
    static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private InterbankRest() {}

    static JSONArray get(String path, String token) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/rest/v1/" + path).openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
            c.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("Cache-Control", "no-store");
            int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = read(stream); if (code < 200 || code >= 300) throw new Exception("request failed");
            return new JSONArray(body);
        } finally { if (c != null) c.disconnect(); }
    }

    static JSONObject rpc(String function, String token, JSONObject payload) throws Exception {
        return rpcOnce(function, token, payload);
    }

    /** Retries one expired access token with the rotating refresh token, then retries the same idempotent request once. */
    static JSONObject rpc(android.content.Context context, String function, String token, JSONObject payload) throws Exception {
        try { return rpcOnce(function, token, payload); }
        catch (RpcException e) {
            if (e.status != 401 || !SupabaseAuthClient.refreshSessionBlocking(context)) throw e;
            String refreshed = SessionStore.accessToken();
            if (refreshed.isEmpty()) throw new Exception("SESSION_EXPIRED");
            return rpcOnce(function, refreshed, payload);
        }
    }

    private static JSONObject rpcOnce(String function, String token, JSONObject payload) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/rest/v1/rpc/" + function).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(20000); c.setDoOutput(true);
            c.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Cache-Control", "no-store");
            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
            int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = read(stream); if (code < 200 || code >= 300) throw rpcFailure(code, body);
            return new JSONObject(body);
        } finally { if (c != null) c.disconnect(); }
    }

    private static final class RpcException extends Exception {
        final int status;
        RpcException(int status, String reason) { super(reason); this.status = status; }
    }

    private static Exception rpcFailure(int status, String body) {
        String code = "";
        String message = "";
        String details = "";
        String hint = "";
        try {
            JSONObject error = new JSONObject(body);
            code = error.optString("code", "");
            message = error.optString("message", "");
            details = error.optString("details", "");
            hint = error.optString("hint", "");
        } catch (Exception ignored) { }
        String combined = (code + " " + message + " " + details + " " + hint).toLowerCase(java.util.Locale.ROOT);
        String reason;
        if (combined.contains("recipient") || combined.contains("same-institution")) reason = "RECIPIENT_INVALID";
        else if (combined.contains("same account") || combined.contains("own account")) reason = "RECIPIENT_IS_SELF";
        else if (combined.contains("insufficient balance") || combined.contains("available demo balance")) reason = "BALANCE_INSUFFICIENT";
        else if (combined.contains("card limit is below current demo usage")) reason = "CARD_LIMIT_BELOW_USAGE";
        else if (combined.contains("card limit insufficient") || combined.contains("card limit")) reason = "CARD_LIMIT_INSUFFICIENT";
        else if (status == 401 || combined.contains("authentication required") || combined.contains("jwt")) reason = "AUTH_REQUIRED";
        else if (status == 403) reason = "NOT_AUTHORIZED";
        else if (status == 404 || code.equals("PGRST202")) reason = "BACKEND_FUNCTION_MISSING";
        else if (status == 429 || status >= 500) reason = "SERVICE_UNAVAILABLE";
        else reason = "REQUEST_INVALID";
        return new RpcException(status, reason);
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "[]";
        try (InputStream src = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[2048]; int n;
            while ((n = src.read(b)) != -1) {
                if (out.size() + n > 65536) throw new Exception("response too large");
                out.write(b, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
