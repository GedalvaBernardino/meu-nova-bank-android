MEU NOVA BANK BR DIGITAL — projeto Android Studio

Pacote: br.com.meunovabank.digital
Versão: 0.2.15-sem-top (versionCode 26)
Compatibilidade: minSdk 21 (Android 5.0), targetSdk 37 (Android 17).

Abra a pasta raiz deste projeto no Android Studio. O projeto usa Android Gradle Plugin 8.9.2 e compileSdk 37; instale a plataforma Android API 37 quando solicitado.

O código-fonte inclui o cliente nativo e os recursos visuais atuais; a Activity e o cliente TOP não fazem parte desta versão. Os arquivos de backend Supabase não estão incluídos neste ZIP.

Por segurança, chaves privadas, senhas e arquivos de assinatura foram excluídos. É possível compilar uma versão de depuração no Android Studio. Para gerar uma release instalável por cima de outra release, configure sua própria chave de assinatura; ela não está neste arquivo.

Recuperação de senha: informe a conta de 6 dígitos; o app solicita um link ao e-mail já confirmado. O link retorna à Activity nativa para definir uma nova senha numérica de 8 dígitos. A Edge Function `account-password-recovery` faz a busca no servidor e não revela o e-mail. O fonte dela está em `supabase/functions/account-password-recovery/index.ts`. Nunca coloque service_role ou outros segredos no APK.

O backend atual gera contas de 6 dígitos; o cliente e a recuperação devem usar esse mesmo formato.

