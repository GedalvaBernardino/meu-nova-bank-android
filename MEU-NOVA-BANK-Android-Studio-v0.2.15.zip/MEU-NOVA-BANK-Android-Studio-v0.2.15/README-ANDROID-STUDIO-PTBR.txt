MEU NOVA BANK BR DIGITAL — projeto Android Studio

Pacote: br.com.meunovabank.digital
Versão: 0.2.15-sem-top (versionCode 26)
Compatibilidade: minSdk 21 (Android 5.0), targetSdk 37 (Android 17).

Abra a pasta raiz deste projeto no Android Studio. O projeto usa Android Gradle Plugin 8.9.2 e compileSdk 37; instale a plataforma Android API 37 quando solicitado.

O código-fonte inclui o cliente nativo e os recursos visuais atuais; a Activity e o cliente TOP não fazem parte desta versão. Os arquivos de backend Supabase não estão incluídos neste ZIP.

Por segurança, chaves privadas, senhas e arquivos de assinatura foram excluídos. É possível compilar uma versão de depuração no Android Studio. Para gerar uma release instalável por cima de outra release, configure sua própria chave de assinatura; ela não está neste arquivo.

Recuperação de senha: a tela nativa pede a conta, um código de verificação e a nova senha. A alteração só deve ser autorizada depois de validar o código enviado ao contato já cadastrado. O cliente espera a Edge Function Supabase `account-password-recovery` (contrato descrito em PASSWORD-RECOVERY-BACKEND.md); essa função/backend não acompanha este ZIP. Sem implantá-la e configurar o envio do código, a recuperação falha de forma segura. Nunca coloque service_role ou credenciais de e-mail no aplicativo.

As senhas atuais têm 8 dígitos numéricos. A recuperação aceita contas de 6 ou 7 dígitos e exige código numérico de 6 dígitos.

