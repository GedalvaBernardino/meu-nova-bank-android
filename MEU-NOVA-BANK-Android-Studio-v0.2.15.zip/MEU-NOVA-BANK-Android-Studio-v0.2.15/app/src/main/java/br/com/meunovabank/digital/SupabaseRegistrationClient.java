package br.com.meunovabank.digital;

import android.content.Context;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Cadastro e ativação exclusivamente no backend; nunca persiste senha/CPF no aparelho. */
public final class SupabaseRegistrationClient {
    private static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co/functions/v1/";
    private static final String KEY = "sb_publishable_U5caPnNVEBwTcUvkDrmLwA_EVWO9Urb";
    private SupabaseRegistrationClient() {}

    public interface RegisterCallback { void done(boolean success, String message); }
    public interface ActivateCallback { void done(boolean success, String accountNumber, String message); }

    public static void register(Context context, String name, String cpf, String email, String phone, String password, RegisterCallback callback) {
        new Thread(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("name", name); body.put("cpf", cpf); body.put("email", email); body.put("phone", phone); body.put("password", password);
                JSONObject response = request("account-register", body, null);
                boolean ok = "confirmation_sent".equals(response.optString("status"));
                callback.done(ok, ok ? "Enviamos um link de confirmação para seu e-mail." : "Não foi possível iniciar o cadastro. Confira os dados, o e-mail e o CPF.");
            } catch (Exception e) {
                callback.done(false, "Não foi possível conectar ao serviço de cadastro. Tente novamente.");
            }
        }, "meunova-register").start();
    }

    public static void activate(Context context, String accessToken, String refreshToken, ActivateCallback callback) {
        new Thread(() -> {
            try {
                JSONObject result = request("account-activate", new JSONObject(), accessToken);
                String account = result.optString("account_number", "");
                if (!account.matches("[0-9]{6}")) throw new IllegalStateException("Conta inválida");
                SessionStore.set(accessToken, refreshToken, account);
                callback.done(true, account, "");
            } catch (Exception e) {
                callback.done(false, "", "Não foi possível confirmar o cadastro. Confira o link ou tente novamente.");
            }
        }, "meunova-activate").start();
    }

    private static JSONObject request(String function, JSONObject body, String accessToken) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(BASE + function).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            connection.setDoOutput(true);
            connection.setRequestProperty("apikey", KEY);
            connection.setRequestProperty("Authorization", "Bearer " + (accessToken == null || accessToken.isEmpty() ? KEY : accessToken));
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Cache-Control", "no-store");
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
            int status = connection.getResponseCode();
            InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
            String text = readAll(stream);
            if (status < 200 || status >= 300) throw new IllegalStateException("Cadastro não confirmado");
            return new JSONObject(text);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048]; int n;
            while ((n = in.read(buffer)) != -1) {
                if (out.size() + n > 8192) throw new IllegalStateException("Resposta acima do limite");
                out.write(buffer, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
