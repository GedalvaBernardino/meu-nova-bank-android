package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;

/** Receives Supabase confirmation and password-recovery links through the registered app deep link. */
public class AuthCallbackActivity extends Activity {
    private boolean started;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        started = false;
        handle(intent);
    }

    private void handle(Intent intent) {
        if (started) return;
        started = true;
        Uri uri = intent == null ? null : intent.getData();
        if (uri == null) {
            fail("Link inválido. Volte ao app e solicite um novo link.");
            return;
        }
        String fragment = uri.getFragment();
        Uri fragmentUri = Uri.parse("https://callback.local/?" + (fragment == null ? "" : fragment));
        String access = first(uri.getQueryParameter("access_token"), fragmentUri.getQueryParameter("access_token"));
        String refresh = first(uri.getQueryParameter("refresh_token"), fragmentUri.getQueryParameter("refresh_token"));
        String type = first(uri.getQueryParameter("type"), fragmentUri.getQueryParameter("type"));
        String error = first(uri.getQueryParameter("error_description"), fragmentUri.getQueryParameter("error_description"));

        if (!error.isEmpty()) {
            fail("O link expirou ou já foi utilizado. Solicite um novo link de recuperação.");
            return;
        }
        if ("recovery".equals(type) && !access.isEmpty()) {
            Intent reset = new Intent(this, RecuperarSenhaActivity.class);
            reset.putExtra("recovery_access_token", access);
            reset.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(reset);
            finish();
            return;
        }
        if (access.isEmpty() || refresh.isEmpty() || (!type.isEmpty() && !type.equals("signup"))) {
            fail("Não foi possível validar o link. Abra a mensagem mais recente e tente novamente.");
            return;
        }
        SupabaseRegistrationClient.activate(this, access, refresh, (ok, account, message) -> runOnUiThread(() -> {
            if (!ok) {
                fail(message);
                return;
            }
            new AlertDialog.Builder(this).setTitle("Conta criada")
                    .setMessage("Seu número de conta é:\n\n" + account + "\n\nGuarde esse número. Para entrar, use-o junto com a senha de 8 dígitos que você criou.")
                    .setPositiveButton("Acessar o app", (dialog, which) -> {
                        Intent home = new Intent(this, HomeActivity.class);
                        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(home);
                        finish();
                    }).setCancelable(false).show();
        }));
    }

    private String first(String a, String b) { return a == null || a.isEmpty() ? (b == null ? "" : b) : a; }

    private void fail(String message) {
        new AlertDialog.Builder(this).setTitle("Link não concluído").setMessage(message)
                .setPositiveButton("Voltar", (dialog, which) -> finish()).setCancelable(false).show();
    }
}
