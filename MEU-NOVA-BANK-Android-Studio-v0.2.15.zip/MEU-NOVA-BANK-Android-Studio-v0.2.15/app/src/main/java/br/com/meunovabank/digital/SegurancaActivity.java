package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;

public final class SegurancaActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.moduleScreen(this, "Segurança", "Dispositivos e acesso");
    }
}
