package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

/** Dedicated account security screen with a path to the existing secure password-reset flow. */
public final class SegurancaActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Segurança","Acesso e proteção da conta");
        Ui.card(this,root,"Sessão atual","Conta "+SessionStore.accountNumber()+" · sessão protegida pelo armazenamento do Android",null);
        Ui.card(this,root,"Redefinir senha","Solicitar link seguro para o e-mail confirmado",()->Ui.open(this,RecuperarSenhaActivity.class));
        Ui.card(this,root,"Privacidade","O app não exibe nem armazena sua senha. Não compartilhe códigos de recuperação.",null);
        Ui.card(this,root,"Dispositivos","O gerenciamento remoto de dispositivos ainda não está conectado.",null);setContentView(root);}
}
