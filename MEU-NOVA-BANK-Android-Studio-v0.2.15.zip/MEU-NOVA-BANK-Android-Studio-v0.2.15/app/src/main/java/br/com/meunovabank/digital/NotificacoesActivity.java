package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dedicated notifications inbox empty state, with no fabricated bank alerts. */
public final class NotificacoesActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Notificações","Avisos vinculados à sua conta");
        LinearLayout empty=new LinearLayout(this);empty.setOrientation(LinearLayout.VERTICAL);empty.setGravity(Gravity.CENTER);empty.setPadding(Ui.d(this,22),Ui.d(this,28),Ui.d(this,22),Ui.d(this,28));empty.setBackground(Ui.bg(android.graphics.Color.WHITE,Ui.d(this,24)));empty.setElevation(Ui.d(this,1));
        TextView icon=Ui.text(this,"•",34,Palette.NAVY,true);icon.setGravity(Gravity.CENTER);icon.setBackground(Ui.bg(Palette.PALE_BLUE,Ui.d(this,24)));empty.addView(icon,new LinearLayout.LayoutParams(Ui.d(this,62),Ui.d(this,62)));
        TextView title=Ui.text(this,"Sua caixa está pronta",18,Palette.NAVY,true);title.setGravity(Gravity.CENTER);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.topMargin=Ui.d(this,14);empty.addView(title,tp);
        TextView note=Ui.text(this,"As notificações ainda não estão conectadas ao servidor. Nenhum aviso foi carregado.",13,Palette.MUTED,false);note.setGravity(Gravity.CENTER);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=Ui.d(this,6);empty.addView(note,np);root.addView(empty,new LinearLayout.LayoutParams(-1,-2));
        Button back=Ui.button(this,"Voltar ao início",Palette.NAVY);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,Ui.d(this,52));bp.topMargin=Ui.d(this,16);root.addView(back,bp);back.setOnClickListener(v->finish());setContentView(root);}
}
