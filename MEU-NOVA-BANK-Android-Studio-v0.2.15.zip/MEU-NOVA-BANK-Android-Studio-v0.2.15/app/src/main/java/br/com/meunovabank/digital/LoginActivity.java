package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    private Button loginButton;
    private EditText accountField;
    private CheckBox keepSignedIn;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Palette.loadSaved(this);
        boolean restored = SessionStore.restore(this);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.column(this);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(Ui.d(this, 24), Ui.d(this, 24), Ui.d(this, 24), Ui.d(this, 26));
        scroll.addView(root);
        setContentView(scroll);

        TextView emblem = Ui.text(this, "N", 29, Color.WHITE, true);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(Ui.bg(Palette.NAVY, Ui.d(this, 26)));
        root.addView(emblem, new LinearLayout.LayoutParams(Ui.d(this, 74), Ui.d(this, 74)));
        TextView brand = Ui.text(this, "MEU NOVA BANK", 24, Palette.NAVY, true);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(-1, -2);
        brandLp.topMargin = Ui.d(this, 11);
        root.addView(brand, brandLp);
        TextView digital = Ui.text(this, "BR DIGITAL", 11, Palette.GREEN, true);
        digital.setLetterSpacing(.16f);
        digital.setGravity(Gravity.CENTER);
        root.addView(digital, new LinearLayout.LayoutParams(-1, Ui.d(this, 20)));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(Ui.d(this, 19), Ui.d(this, 19), Ui.d(this, 19), Ui.d(this, 18));
        GradientDrawable formBackground = new GradientDrawable();
        formBackground.setColor(Color.WHITE);
        formBackground.setCornerRadius(Ui.d(this, 23));
        formBackground.setStroke(Ui.d(this, 1), Palette.BORDER);
        form.setBackground(formBackground);
        form.setElevation(Ui.d(this, 3));
        LinearLayout.LayoutParams formLp = new LinearLayout.LayoutParams(-1, -2);
        formLp.topMargin = Ui.d(this, 25);
        root.addView(form, formLp);

        form.addView(Ui.text(this, "Acesse sua conta", 20, Palette.NAVY, true));
        TextView intro = Ui.text(this, "Entre com seus dados para continuar.", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = Ui.d(this, 4);
        introLp.bottomMargin = Ui.d(this, 15);
        form.addView(intro, introLp);

        form.addView(Ui.text(this, "NÚMERO DA CONTA", 10, Palette.MUTED, true));
        accountField = Ui.input(this, "Conta · 6 dígitos", InputType.TYPE_CLASS_NUMBER);
        accountField.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        accountField.setSaveEnabled(false);
        if (restored) accountField.setText(SessionStore.accountNumber());
        LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        accountLp.topMargin = Ui.d(this, 5);
        form.addView(accountField, accountLp);

        TextView passwordLabel = Ui.text(this, "SENHA", 10, Palette.MUTED, true);
        LinearLayout.LayoutParams passwordLabelLp = new LinearLayout.LayoutParams(-1, -2);
        passwordLabelLp.topMargin = Ui.d(this, 13);
        form.addView(passwordLabel, passwordLabelLp);
        EditText password = Ui.input(this, "Senha numérica · 8 dígitos", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        password.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8)});
        password.setSaveEnabled(false);
        LinearLayout.LayoutParams passwordLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        passwordLp.topMargin = Ui.d(this, 5);
        form.addView(password, passwordLp);

        keepSignedIn = new CheckBox(this);
        keepSignedIn.setText("Manter conectado neste aparelho");
        keepSignedIn.setTextColor(Palette.TEXT);
        keepSignedIn.setTextSize(13);
        keepSignedIn.setChecked(restored);
        LinearLayout.LayoutParams keepLp = new LinearLayout.LayoutParams(-1, -2);
        keepLp.topMargin = Ui.d(this, 9);
        form.addView(keepSignedIn, keepLp);
        TextView privacyNote = Ui.text(this, "A senha não é salva. A sessão é protegida pelo armazenamento seguro do Android.", 10, Palette.MUTED, false);
        privacyNote.setPadding(Ui.d(this, 11), Ui.d(this, 9), Ui.d(this, 11), Ui.d(this, 9));
        privacyNote.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 13)));
        LinearLayout.LayoutParams privacyLp = new LinearLayout.LayoutParams(-1, -2);
        privacyLp.topMargin = Ui.d(this, 4);
        form.addView(privacyNote, privacyLp);

        loginButton = Ui.button(this, "Entrar", Palette.RED);
        LinearLayout.LayoutParams loginLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        loginLp.topMargin = Ui.d(this, 14);
        form.addView(loginButton, loginLp);
        loginButton.setOnClickListener(v -> {
            if (accountField.length() != 6 || password.length() != 8) {
                Toast.makeText(this, "Informe conta e senha nos formatos indicados.", Toast.LENGTH_SHORT).show();
                return;
            }
            String accountValue = accountField.getText().toString();
            String passwordValue = password.getText().toString();
            password.setText("");
            loginButton.setEnabled(false);
            loginButton.setText("Verificando…");
            SupabaseAuthClient.login(this, accountValue, passwordValue, (success, message) -> runOnUiThread(() -> {
                loginButton.setEnabled(true);
                loginButton.setText("Entrar");
                if (success) fetchThemeThenOpenHome();
                else Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }));
        });

        TextView forgot = Ui.text(this, "Esqueci minha senha", 13, Palette.NAVY, true);
        forgot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams forgotLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 43));
        forgotLp.topMargin = Ui.d(this, 3);
        form.addView(forgot, forgotLp);
        forgot.setOnClickListener(v -> Ui.open(this, RecuperarSenhaActivity.class));

        Button openAccount = Ui.button(this, "Abrir nova conta", Palette.GREEN);
        LinearLayout.LayoutParams openLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        openLp.topMargin = Ui.d(this, 13);
        root.addView(openAccount, openLp);
        openAccount.setOnClickListener(v -> Ui.open(this, AbrirContaActivity.class));
        TextView note = Ui.text(this, "PRÉVIA · OPERAÇÕES FINANCEIRAS DEMONSTRATIVAS", 10, Palette.MUTED, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2);
        noteLp.topMargin = Ui.d(this, 17);
        root.addView(note, noteLp);

        if (restored) {
            loginButton.setEnabled(false);
            loginButton.setText("Restaurando sessão…");
            SupabaseAuthClient.restoreSavedSession(this, (success, message) -> runOnUiThread(() -> {
                if (success) fetchThemeThenOpenHome();
                else {
                    loginButton.setEnabled(true);
                    loginButton.setText("Entrar");
                    if (message != null && !message.isEmpty()) Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                }
            }));
        }
    }

    private void fetchThemeThenOpenHome() {
        SupabaseProfileClient.fetchThemeTier(SessionStore.accessToken(), SessionStore.accountNumber(), tier -> {
            if (tier != null && !tier.isEmpty()) Palette.applyTheme(getApplicationContext(), tier);
            runOnUiThread(this::persistPreferenceAndOpenHome);
        });
    }

    private void persistPreferenceAndOpenHome() {
        if (keepSignedIn != null && keepSignedIn.isChecked()) {
            try { SessionStore.persist(this); }
            catch (Exception ignored) {
                SessionStore.clearSaved(this);
                Toast.makeText(this, "A sessão foi iniciada, mas não pôde ser salva neste aparelho.", Toast.LENGTH_LONG).show();
            }
        } else SessionStore.clearSaved(this);
        openHome();
    }

    private void openHome() {
        Intent home = new Intent(this, HomeActivity.class);
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(home);
        Ui.transition(this);
        finish();
    }
}
