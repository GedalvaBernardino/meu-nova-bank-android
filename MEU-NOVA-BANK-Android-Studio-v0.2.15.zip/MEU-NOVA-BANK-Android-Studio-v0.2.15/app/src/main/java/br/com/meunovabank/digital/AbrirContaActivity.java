package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.LinkedHashMap;
import java.util.Map;

/** Cadastro em 8 etapas; senha é enviada diretamente ao Auth por HTTPS e não é persistida pelo app. */
public class AbrirContaActivity extends Activity {
    private int step = 1;
    private final LinkedHashMap<String,String> data = new LinkedHashMap<>();
    private final LinkedHashMap<String,EditText> inputs = new LinkedHashMap<>();
    private CheckBox consent;
    private LinearLayout page;
    private Button nextButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        page = Ui.column(this);
        scroll.addView(page);
        setContentView(scroll);
        inputs.clear(); consent = null;

        TextView brand = Ui.text(this, "MEU NOVA BANK  ·  ABERTURA DE CONTA", 11, Palette.GREEN, true);
        page.addView(brand);
        TextView progress = Ui.text(this, "ETAPA " + step + " DE 8", 12, Palette.RED, true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, -2);
        pp.topMargin = Ui.d(this, 18);
        page.addView(progress, pp);
        TextView heading = Ui.text(this, step == 7 ? "Revise e autorize" : step == 8 ? "Confirme seu e-mail" : stepTitle(step), 24, Palette.NAVY, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = Ui.d(this, 10); hp.bottomMargin = Ui.d(this, 8);
        page.addView(heading, hp);
        TextView explainer = Ui.text(this, step == 8
                ? "Enviamos um link de confirmação para " + value("email") + ". Abra o e-mail e toque no link para gerar seu número de conta."
                : step == 7
                ? "Confira os dados. O número de conta será criado só depois da confirmação do e-mail."
                : "Preencha os dados para continuar. A senha deve ter exatamente 8 números.", 13, Palette.MUTED, false);
        page.addView(explainer);

        switch (step) {
            case 1: addField("name", "Nome completo", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS, 120); break;
            case 2: addField("cpf", "CPF (somente números)", InputType.TYPE_CLASS_NUMBER, 11); break;
            case 3: addField("email", "E-mail", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS, 160); break;
            case 4: addField("phone", "Celular com DDD (somente números)", InputType.TYPE_CLASS_PHONE, 11); break;
            case 5: addField("password", "Crie sua senha numérica de 8 dígitos", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8); break;
            case 6: addField("password_confirm", "Digite novamente a senha", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8); break;
            case 7: showReview(); break;
            case 8: showPending(); break;
        }

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams row = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        row.topMargin = Ui.d(this, 22);
        if (step > 1 && step < 8) {
            Button back = Ui.button(this, "Voltar", Palette.NAVY);
            buttons.addView(back, new LinearLayout.LayoutParams(0, -1, 1));
            back.setOnClickListener(v -> { capture(); step--; render(); });
        }
        String label = step == 7 ? "Enviar link seguro" : step == 8 ? "Voltar ao login" : "Continuar";
        nextButton = Ui.button(this, label, step == 7 ? Palette.RED : Palette.GREEN);
        LinearLayout.LayoutParams nextLp = new LinearLayout.LayoutParams(0, -1, 1);
        if (step > 1 && step < 8) nextLp.leftMargin = Ui.d(this, 10);
        buttons.addView(nextButton, nextLp);
        page.addView(buttons, row);
        if (step == 7) nextButton.setOnClickListener(v -> submitRegistration());
        else if (step == 8) nextButton.setOnClickListener(v -> finish());
        else nextButton.setOnClickListener(v -> { if (validateCurrent()) { capture(); step++; render(); } });

        TextView safety = Ui.text(this, "Conta de acesso ao protótipo. Não movimenta dinheiro real.", 11, Palette.MUTED, false);
        safety.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2);
        slp.topMargin = Ui.d(this, 16); page.addView(safety, slp);
    }

    private String stepTitle(int s) {
        switch (s) {
            case 1: return "Seus dados";
            case 2: return "Documento";
            case 3: return "E-mail";
            case 4: return "Celular";
            case 5: return "Crie sua senha";
            case 6: return "Confirme a senha";
            default: return "Cadastro";
        }
    }

    private void addField(String key, String hint, int inputType, int max) {
        EditText edit = new EditText(this);
        edit.setHint(hint); edit.setInputType(inputType); edit.setSingleLine(true); edit.setSaveEnabled(false);
        edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(max)});
        String saved=data.get(key); if(saved!=null)edit.setText(saved);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,Ui.d(this,54)); lp.topMargin=Ui.d(this,8);
        page.addView(edit,lp); inputs.put(key,edit);
    }

    private boolean validateCurrent() {
        capture(); String message="";
        switch(step) {
            case 1: if(words("name")<2)message="Informe seu nome e sobrenome."; break;
            case 2: if(!validCpf(value("cpf")))message="Confira o CPF informado."; break;
            case 3: if(!android.util.Patterns.EMAIL_ADDRESS.matcher(value("email").trim()).matches())message="Informe um e-mail válido."; break;
            case 4: if(!(digitsCount("phone")==10||digitsCount("phone")==11))message="Informe celular com DDD, com 10 ou 11 números."; break;
            case 5: if(!value("password").matches("[0-9]{8}"))message="A senha precisa ter exatamente 8 números."; break;
            case 6: if(!value("password").equals(value("password_confirm")))message="As senhas não conferem."; break;
        }
        if(!message.isEmpty())Toast.makeText(this,message,Toast.LENGTH_LONG).show();
        return message.isEmpty();
    }

    private void capture(){for(Map.Entry<String,EditText> e:inputs.entrySet())data.put(e.getKey(),e.getValue().getText().toString().trim());}
    private String value(String key){String v=data.get(key);return v==null?"":v;}
    private int words(String key){String v=value(key).trim();return v.isEmpty()?0:v.split("\\s+").length;}
    private int digitsCount(String key){return value(key).replaceAll("[^0-9]","").length();}

    private boolean validCpf(String raw){
        String cpf=raw.replaceAll("[^0-9]",""); if(!cpf.matches("[0-9]{11}")||cpf.matches("([0-9])\\1{10}"))return false;
        int sum=0;for(int i=0;i<9;i++)sum+=(cpf.charAt(i)-'0')*(10-i);int d=(sum*10)%11;if(d==10)d=0;if(d!=cpf.charAt(9)-'0')return false;
        sum=0;for(int i=0;i<10;i++)sum+=(cpf.charAt(i)-'0')*(11-i);d=(sum*10)%11;if(d==10)d=0;return d==cpf.charAt(10)-'0';
    }

    private void showReview(){
        String[][] rows={{"Nome",value("name")},{"CPF",maskCpf(value("cpf"))},{"E-mail",value("email")},{"Celular",value("phone")},{"Senha","•••••••• (não será exibida)"}};
        for(String[] row:rows){TextView line=Ui.text(this,row[0]+":  "+row[1],13,Palette.TEXT,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=Ui.d(this,8);page.addView(line,lp);}
        consent=new CheckBox(this);consent.setText("Autorizo usar meu nome, CPF, e-mail e celular para criar e proteger meu acesso. O CPF será guardado apenas como código criptográfico para impedir duplicidade; a senha é processada pelo Supabase Auth e não fica salva no app. Entendo que esta conta é do protótipo e não movimenta dinheiro real.");consent.setTextColor(Palette.NAVY);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=Ui.d(this,14);page.addView(consent,cp);
    }

    private String maskCpf(String raw){String d=raw.replaceAll("[^0-9]","");return d.length()==11?"***.***.***-"+d.substring(9):"***";}

    private void showPending(){
        TextView notice=Ui.text(this,"Depois de abrir o link, o app confirmará seu e-mail e criará automaticamente um número aleatório de 6 dígitos, sem repetir contas ou CPFs cadastrados. Guarde esse número: ele será seu usuário para entrar junto com a senha que você definiu.",14,Palette.TEXT,false);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=Ui.d(this,20);page.addView(notice,np);
        TextView spam=Ui.text(this,"Se não encontrar a mensagem, confira Spam/Lixo eletrônico. O link pode ser usado uma única vez e expira conforme a configuração de segurança do Supabase.",12,Palette.MUTED,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.d(this,12);page.addView(spam,sp);
    }

    private void submitRegistration(){
        if(consent==null||!consent.isChecked()){Toast.makeText(this,"Marque a autorização para continuar.",Toast.LENGTH_SHORT).show();return;}
        capture(); if(!validCpf(value("cpf"))||!value("password").matches("[0-9]{8}")||!value("password").equals(value("password_confirm"))){Toast.makeText(this,"Revise os dados e confirme a senha de 8 dígitos.",Toast.LENGTH_LONG).show();return;}
        nextButton.setEnabled(false);nextButton.setText("Enviando…");
        SupabaseRegistrationClient.register(this,value("name"),value("cpf"),value("email"),value("phone"),value("password"),(ok,message)->runOnUiThread(()->{
            if(!ok){nextButton.setEnabled(true);nextButton.setText("Enviar link seguro");Toast.makeText(this,message,Toast.LENGTH_LONG).show();return;}
            String email=value("email");data.clear();data.put("email",email);step=8;render();
        }));
    }

    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);}
    @Override protected void onDestroy(){if(isFinishing()){data.clear();inputs.clear();}super.onDestroy();}
}
