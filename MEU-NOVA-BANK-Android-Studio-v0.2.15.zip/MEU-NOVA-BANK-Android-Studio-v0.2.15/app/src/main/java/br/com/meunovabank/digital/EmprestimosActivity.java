package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dedicated loan inquiry screen that does not submit applications or promise credit. */
public final class EmprestimosActivity extends Activity {
    private EditText amount,months;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Empréstimos","Organize os dados de uma simulação demonstrativa");
        amount=Ui.input(this,"Valor que deseja simular (R$)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(amount,new LinearLayout.LayoutParams(-1,Ui.d(this,54)));
        months=Ui.input(this,"Prazo desejado em meses",InputType.TYPE_CLASS_NUMBER);months.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(2)});LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,Ui.d(this,54));mp.topMargin=Ui.d(this,10);root.addView(months,mp);
        status=Ui.text(this,"Nenhuma solicitação foi enviada.",13,Palette.MUTED,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.d(this,10);root.addView(status,sp);
        Button simulate=Ui.button(this,"Revisar simulação",Palette.NAVY);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,Ui.d(this,52));bp.topMargin=Ui.d(this,10);root.addView(simulate,bp);
        Ui.card(this,root,"Sem análise de crédito","Não existe taxa, oferta ou aprovação conectada nesta prévia.",null);
        simulate.setOnClickListener(v->{String a=amount.getText().toString().trim(),m=months.getText().toString().trim();int duration=0;try{duration=Integer.parseInt(m);}catch(Exception ignored){}if(a.isEmpty()||duration<=0){status.setText("Informe valor e prazo para revisar os dados.");return;}new AlertDialog.Builder(this).setTitle("Prévia não enviada").setMessage("Os dados foram preenchidos apenas nesta tela. Nenhum pedido foi enviado e nenhuma condição de crédito foi calculada.").setPositiveButton("Entendi",(d,w)->status.setText("Prévia encerrada. Nada foi enviado.")).show();});setContentView(root);}
}
