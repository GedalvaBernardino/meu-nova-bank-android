package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

/** Dedicated payments hub linking to the separate boleto and QR review Activities. */
public final class PagamentosActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Pagamentos","Escolha a forma de pagamento para abrir sua tela");
        Ui.card(this,root,"Boleto","Informar o código e conferir o formato localmente",()->Ui.open(this,BoletoActivity.class));
        Ui.card(this,root,"Pagar por QR","Colar e revisar o código QR demonstrativo",()->Ui.open(this,PagarQrActivity.class));
        Ui.card(this,root,"Serviços","Água, energia e outros pagamentos ainda não estão conectados a emissores.",null);
        Ui.card(this,root,"Aviso","Nenhuma opção desta tela debita saldo ou confirma um pagamento real.",null);setContentView(root);}
}
