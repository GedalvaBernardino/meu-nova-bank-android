package br.com.meunovabank.digital;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Password recovery is completed only by a server-side function after the registered-contact code is verified. */
public final class SupabaseRecoveryClient {
    private static final String FUNCTION_URL =
            "https://hzgslpskmyzczqquendt.supabase.co/functions/v1/account-password-recovery";

    private SupabaseRecoveryClient() {}

    public interface Callback { void done(boolean success, String message); }

    public static void requestCode(String accountNumber, Callback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("action", "request_code");
            body.put("account_number", accountNumber);
        } catch (Exception ignored) {
            callback.done(false, genericFailure());
            return;
        }
        request(body, callback, "Se a conta existir, enviaremos um código ao contato cadastrado.");
    }

    public static void confirmCode(String accountNumber, String code, String newPassword, Callback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("action", "confirm_code");
            body.put("account_number", accountNumber);
            body.put("code", code);
            body.put("new_password", newPassword);
        } catch (Exception ignored) {
            callback.done(false, genericFailure());
            return;
        }
        request(body, callback, "Senha atualizada. Você já pode entrar com a nova senha.");
    }

    private static void request(JSONObject body, Callback callback, String successMessage) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(FUNCTION_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Cache-Control", "no-store");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                String responseText = readAll(stream);
                if (status >= 200 && status < 300) {
                    JSONObject response = new JSONObject(responseText);
                    String result = response.optString("status", "");
                    if ("code_requested".equals(result) || "password_updated".equals(result)) {
                        callback.done(true, successMessage);
                    } else {
                        callback.done(false, genericFailure());
                    }
                } else {
                    callback.done(false, genericFailure());
                }
            } catch (Exception ignored) {
                callback.done(false, genericFailure());
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "meunova-password-recovery").start();
    }

    private static String genericFailure() {
        return "Não foi possível concluir a recuperação agora. Confira sua conexão ou tente mais tarde.";
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int count;
            while ((count = in.read(buffer)) != -1) {
                if (out.size() + count > 8192) throw new IllegalStateException("Response too large");
                out.write(buffer, 0, count);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
