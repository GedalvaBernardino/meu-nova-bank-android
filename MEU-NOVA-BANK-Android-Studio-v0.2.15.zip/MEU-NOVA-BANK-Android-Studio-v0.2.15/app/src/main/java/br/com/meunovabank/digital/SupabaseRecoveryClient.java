package br.com.meunovabank.digital;

import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Account recovery starts on the server and changes a password only with a Supabase recovery session. */
public final class SupabaseRecoveryClient {
    private static final String FUNCTION_URL =
            "https://hzgslpskmyzczqquendt.supabase.co/functions/v1/account-password-recovery";
    private static final String AUTH_USER_URL =
            "https://hzgslpskmyzczqquendt.supabase.co/auth/v1/user";

    private SupabaseRecoveryClient() {}

    public interface Callback { void done(boolean success, String message); }

    public static void requestRecovery(String accountNumber, Callback callback) {
        JSONObject body = new JSONObject();
        try {
            body.put("account_number", accountNumber);
        } catch (Exception ignored) {
            callback.done(false, "Não foi possível iniciar a recuperação agora.");
            return;
        }
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(FUNCTION_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Cache-Control", "no-store");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                String response = readAll(stream);
                if (status >= 200 && status < 300
                        && "recovery_requested".equals(new JSONObject(response).optString("status"))) {
                    callback.done(true, "Se a conta estiver ativa, enviaremos um link seguro ao e-mail cadastrado. Abra o link neste aparelho para escolher a nova senha.");
                } else {
                    callback.done(false, "Não foi possível iniciar a recuperação agora. Confira a conexão e tente novamente mais tarde.");
                }
            } catch (Exception ignored) {
                callback.done(false, "Não foi possível iniciar a recuperação agora. Confira a conexão e tente novamente mais tarde.");
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "meunova-password-recovery-request").start();
    }

    public static void updatePassword(String recoveryAccessToken, String newPassword, Callback callback) {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                JSONObject body = new JSONObject();
                body.put("password", newPassword);
                connection = (HttpURLConnection) new URL(AUTH_USER_URL).openConnection();
                connection.setRequestMethod("PUT");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setDoOutput(true);
                connection.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
                connection.setRequestProperty("Authorization", "Bearer " + recoveryAccessToken);
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                connection.setRequestProperty("Cache-Control", "no-store");
                byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                connection.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300
                        ? connection.getInputStream() : connection.getErrorStream();
                readAll(stream);
                if (status >= 200 && status < 300) {
                    callback.done(true, "Senha atualizada. Entre com sua conta e a nova senha.");
                } else {
                    callback.done(false, "O link expirou ou já foi usado. Solicite outro link de recuperação.");
                }
            } catch (Exception ignored) {
                callback.done(false, "Não foi possível atualizar a senha. Confira a conexão e tente novamente.");
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "meunova-password-update").start();
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[2048];
            int count;
            while ((count = in.read(buffer)) != -1) {
                if (out.size() + count > 8192) throw new IllegalStateException("Response too large");
                out.write(buffer, 0, count);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
