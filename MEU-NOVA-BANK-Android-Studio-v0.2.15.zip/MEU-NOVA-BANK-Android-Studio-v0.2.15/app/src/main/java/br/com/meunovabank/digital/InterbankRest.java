package br.com.meunovabank.digital;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class InterbankRest {
    static final String BASE = "https://hzgslpskmyzczqquendt.supabase.co";
    private InterbankRest() {}

    static JSONArray get(String path, String token) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/rest/v1/" + path).openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
            c.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("Cache-Control", "no-store");
            int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = read(stream); if (code < 200 || code >= 300) throw new Exception("request failed");
            return new JSONArray(body);
        } finally { if (c != null) c.disconnect(); }
    }

    static JSONObject rpc(String function, String token, JSONObject payload) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + "/rest/v1/rpc/" + function).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(12000); c.setReadTimeout(15000); c.setDoOutput(true);
            c.setRequestProperty("apikey", SupabaseAuthClient.PUBLISHABLE_KEY);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Cache-Control", "no-store");
            byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
            int code = c.getResponseCode(); InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = read(stream); if (code < 200 || code >= 300) throw new Exception("RPC request failed");
            return new JSONObject(body);
        } finally { if (c != null) c.disconnect(); }
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "[]";
        try (InputStream src = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[2048]; int n;
            while ((n = src.read(b)) != -1) {
                if (out.size() + n > 65536) throw new Exception("response too large");
                out.write(b, 0, n);
            }
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        }
    }
}
