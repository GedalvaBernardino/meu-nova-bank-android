package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dedicated transfer review form; this prototype deliberately does not execute a transfer. */
public final class TransferenciaActivity extends Activity {
    private EditText destination,amount;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Transferência DEM","Revise os dados antes de qualquer operação");
        Ui.card(this,root,"Conta de origem","Conta demonstrativa "+SessionStore.accountNumber(),null);
        destination=Ui.input(this,"Conta de destino · 6 dígitos",InputType.TYPE_CLASS_NUMBER);destination.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});root.addView(destination,new LinearLayout.LayoutParams(-1,Ui.d(this,54)));
        amount=Ui.input(this,"Valor demonstrativo (R$)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);root.addView(amount,new LinearLayout.LayoutParams(-1,Ui.d(this,54)));
        status=Ui.text(this,"Nenhuma transferência foi iniciada.",13,Palette.MUTED,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.d(this,10);root.addView(status,sp);
        Button review=Ui.button(this,"Revisar dados",Palette.NAVY);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,Ui.d(this,52));bp.topMargin=Ui.d(this,12);root.addView(review,bp);
        Ui.card(this,root,"Modo de demonstração","A tela não debita nem credita saldo e não gera comprovante financeiro.",null);
        review.setOnClickListener(v->{String acc=destination.getText().toString().trim(),raw=amount.getText().toString().trim().replace(',','.');double value;try{value=Double.parseDouble(raw);}catch(Exception e){value=0;}if(!acc.matches("\\d{6}")||value<=0){status.setText("Informe uma conta com 6 dígitos e um valor maior que zero.");return;}new AlertDialog.Builder(this).setTitle("Revisão demonstrativa").setMessage("Destino: conta "+acc+"\nValor: R$ "+raw+"\n\nNenhuma transferência será executada neste protótipo.").setPositiveButton("Entendi",(d,w)->status.setText("Revisão concluída. Nenhum saldo foi alterado.")).setNegativeButton("Voltar",null).show();});setContentView(root);}
}
