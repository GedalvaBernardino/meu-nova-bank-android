package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;

public final class TransferenciaActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.moduleScreen(this, "Transferência DEM", "Transferências entre contas");
    }
}
