package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dedicated profile screen showing only authenticated profile fields available to this app. */
public final class PerfilActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Meu perfil","Dados da sessão autenticada");
        String account=SessionStore.accountNumber();TextView name=Ui.text(this,"Carregando nome…",18,Palette.NAVY,true);root.addView(name,new LinearLayout.LayoutParams(-1,-2));
        Ui.card(this,root,"Número da conta",account.isEmpty()?"Não disponível":"Conta "+account,null);
        Ui.card(this,root,"Privacidade","Esta tela consulta apenas o perfil vinculado à sessão autenticada.",null);
        Ui.card(this,root,"Alterar senha","Use o fluxo seguro de recuperação de acesso",()->Ui.open(this,RecuperarSenhaActivity.class));
        SupabaseProfileClient.fetchDisplayName(SessionStore.accessToken(),account,value->runOnUiThread(()->name.setText(value==null||value.trim().isEmpty()?"Nome indisponível":value.trim())));
        setContentView(root);}
}
