package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    private Ui() { }

    static int d(Activity a, float n) { return (int) (n * a.getResources().getDisplayMetrics().density + .5f); }

    static TextView text(Activity a, String s, int size, int color, boolean bold) {
        TextView v = new TextView(a);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setIncludeFontPadding(false);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    static GradientDrawable bg(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    static LinearLayout column(Activity a) {
        AnimatedColumn l = new AnimatedColumn(a);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(d(a, 20), d(a, 18), d(a, 20), d(a, 26));
        l.setBackgroundColor(Palette.BG);
        return l;
    }

    static Button button(Activity a, String s, int color) {
        Button b = new Button(a);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(d(a, 50));
        b.setPadding(d(a, 16), d(a, 5), d(a, 16), d(a, 5));
        b.setBackground(ripple(color, d(a, 18), Color.argb(34, 255, 255, 255), Color.TRANSPARENT));
        b.setElevation(d(a, 2));
        pressScale(a, b);
        return b;
    }

    static EditText input(Activity a, String hint, int inputType) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(129, 145, 164));
        e.setTextColor(Palette.TEXT);
        e.setTextSize(15);
        e.setSingleLine(true);
        e.setInputType(inputType);
        e.setPadding(d(a, 15), 0, d(a, 15), 0);
        e.setMinHeight(d(a, 52));
        e.setBackground(ripple(Color.WHITE, d(a, 16), Color.argb(18, 16, 43, 80), Palette.BORDER));
        return e;
    }

    static LinearLayout card(Activity a, LinearLayout root, String title, String sub, Runnable on) {
        LinearLayout c = new LinearLayout(a);
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(d(a, 14), d(a, 13), d(a, 13), d(a, 13));
        GradientDrawable shape = shape(Color.WHITE, d(a, 20), Palette.BORDER);
        c.setBackground(on == null ? shape : new RippleDrawable(ColorStateList.valueOf(Color.rgb(232, 239, 248)), shape, null));
        c.setElevation(d(a, on == null ? 1 : 2));
        c.setContentDescription(title + (sub == null || sub.isEmpty() ? "" : ". " + sub));
        TextView monogram = text(a, first(title), 15, Palette.NAVY, true);
        monogram.setGravity(Gravity.CENTER);
        monogram.setBackground(bg(Palette.PALE_BLUE, d(a, 16)));
        c.addView(monogram, new LinearLayout.LayoutParams(d(a, 42), d(a, 42)));

        LinearLayout copy = new LinearLayout(a);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(d(a, 12), 0, d(a, 7), 0);
        TextView t = text(a, title, 15, Palette.NAVY, true);
        copy.addView(t, new LinearLayout.LayoutParams(-1, -2));
        TextView sText = text(a, sub, 12, Palette.MUTED, false);
        sText.setLineSpacing(d(a, 2), 1f);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = d(a, 4);
        copy.addView(sText, sp);
        c.addView(copy, new LinearLayout.LayoutParams(0, -2, 1));
        if (on != null) {
            TextView arrow = text(a, "›", 26, Palette.GREEN, true);
            arrow.setGravity(Gravity.CENTER);
            c.addView(arrow, new LinearLayout.LayoutParams(d(a, 24), -2));
            c.setClickable(true);
            c.setFocusable(true);
            c.setOnClickListener(v -> on.run());
            pressScale(a, c);
        }
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = d(a, 9);
        root.addView(c, cp);
        return c;
    }

    static void section(Activity a, LinearLayout root, String title, String subtitle) {
        LinearLayout block = new LinearLayout(a);
        block.setOrientation(LinearLayout.VERTICAL);
        TextView t = text(a, title, 17, Palette.NAVY, true);
        block.addView(t, new LinearLayout.LayoutParams(-1, -2));
        if (subtitle != null && !subtitle.isEmpty()) {
            TextView sub = text(a, subtitle, 11, Palette.MUTED, false);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
            sp.topMargin = d(a, 3);
            block.addView(sub, sp);
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = d(a, 14);
        p.bottomMargin = d(a, 8);
        root.addView(block, p);
    }

    static EditText input(Activity a, String hint) {
        return input(a, hint, InputType.TYPE_CLASS_TEXT);
    }

    static void moduleScreen(Activity a, String title, String subtitle) {
        LinearLayout root = column(a);
        LinearLayout brandRow = new LinearLayout(a);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView emblem = text(a, "N", 19, Color.WHITE, true);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(bg(Palette.NAVY, d(a, 18)));
        brandRow.addView(emblem, new LinearLayout.LayoutParams(d(a, 42), d(a, 42)));
        LinearLayout brand = new LinearLayout(a);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(d(a, 11), 0, 0, 0);
        brand.addView(text(a, "MEU NOVA BANK", 14, Palette.NAVY, true));
        brand.addView(text(a, "BR DIGITAL · ÁREA DO CLIENTE", 9, Palette.GREEN, true));
        brandRow.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(brandRow, new LinearLayout.LayoutParams(-1, d(a, 48)));
        TextView heading = text(a, title, 25, Palette.NAVY, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = d(a, 23);
        root.addView(heading, hp);
        TextView desc = text(a, subtitle, 13, Palette.MUTED, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = d(a, 5);
        dp.bottomMargin = d(a, 15);
        root.addView(desc, dp);
        card(a, root, "Módulo nativo", "Esta função possui uma tela própria no aplicativo.", null);
        card(a, root, "Integração pendente", "Conecte o projeto Supabase independente para habilitar dados e operações. Nenhuma ação financeira é executada nesta prévia.", null);
        Button back = button(a, "Voltar ao início", Palette.NAVY);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, d(a, 52));
        bp.topMargin = d(a, 9);
        root.addView(back, bp);
        back.setOnClickListener(v -> a.finish());
        a.setContentView(root);
    }

    static void open(Activity a, Class<?> c) {
        a.startActivity(new Intent(a, c));
        transition(a);
    }

    static void transition(Activity a) {
        if (Build.VERSION.SDK_INT < 21) return;
        int enter = a.getResources().getIdentifier("activity_enter", "anim", a.getPackageName());
        int exit = a.getResources().getIdentifier("activity_exit", "anim", a.getPackageName());
        if (enter != 0 && exit != 0) a.overridePendingTransition(enter, exit);
    }

    static Drawable ripple(int color, int radius, int rippleColor, int strokeColor) {
        GradientDrawable content = shape(color, radius, strokeColor);
        if (Build.VERSION.SDK_INT >= 21) return new RippleDrawable(ColorStateList.valueOf(rippleColor), content, null);
        return content;
    }

    private static GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (stroke != Color.TRANSPARENT) d.setStroke(1, stroke);
        return d;
    }

    private static String first(String value) {
        if (value == null || value.trim().isEmpty()) return "•";
        return value.trim().substring(0, 1).toUpperCase(java.util.Locale.ROOT);
    }

    private static void pressScale(Activity a, View v) {
        v.setOnTouchListener((view, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) view.animate().scaleX(.985f).scaleY(.985f).setDuration(90).start();
            else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) view.animate().scaleX(1f).scaleY(1f).setDuration(150).setInterpolator(new DecelerateInterpolator()).start();
            return false;
        });
    }

    private static final class AnimatedColumn extends LinearLayout {
        AnimatedColumn(Activity context) { super(context); }
        @Override public void addView(View child, int index, ViewGroup.LayoutParams params) {
            super.addView(child, index, params);
            int position = Math.max(0, getChildCount() - 1);
            child.setAlpha(0f);
            child.setTranslationY(d((Activity) getContext(), 9));
            child.animate().alpha(1f).translationY(0f)
                    .setStartDelay(Math.min(position * 18L, 190L))
                    .setDuration(230L)
                    .setInterpolator(new DecelerateInterpolator())
                    .start();
        }
    }
}
