package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

/** Dedicated support and help screen; avoids inventing contact details or claiming a ticket was sent. */
public final class SuporteActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Suporte","Ajuda para usar o aplicativo");
        Ui.card(this,root,"Problemas de acesso","Abra o fluxo seguro de recuperação de senha",()->Ui.open(this,RecuperarSenhaActivity.class));
        Ui.card(this,root,"Transferências","Confira os dados antes de continuar; esta prévia não executa pagamentos",()->Ui.open(this,TransferenciaActivity.class));
        Ui.card(this,root,"Sobre esta versão","O app é um protótipo demonstrativo. Ele não é uma instituição financeira nem movimenta dinheiro real.",null);
        Ui.card(this,root,"Atendimento","Nenhum canal de atendimento foi configurado nesta versão.",null);setContentView(root);}
}
