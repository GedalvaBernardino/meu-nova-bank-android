package br.com.meunovabank.digital;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Lista recebimentos e separa solicitações pendentes de créditos efetivamente lançados. */
public final class IncomingTransfersActivity extends Activity {
    private LinearLayout entries;
    private TextView status;
    private Button refresh;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, String> observedStates = new HashMap<>();
    private boolean activityVisible;
    private boolean requestInProgress;
    private boolean initialStateLoaded;
    private static final long POLL_MILLIS = 12_000L;
    private final Runnable pollTask = new Runnable() {
        @Override public void run() {
            if (!activityVisible) return;
            load();
            handler.postDelayed(this, POLL_MILLIS);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.column(this);
        page.addView(Ui.text(this, "Transferências recebidas", 23, Palette.NAVY, true));
        page.addView(Ui.text(this, "A resposta do administrador é consultada automaticamente a cada 12 segundos enquanto esta tela fica aberta. O crédito só aparece no saldo e no extrato depois da confirmação do débito na origem.", 12, Palette.MUTED, false));
        Button statement = Ui.button(this, "Abrir extrato", Palette.GREEN);
        LinearLayout.LayoutParams statementParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 48));
        statementParams.topMargin = Ui.d(this, 10);
        page.addView(statement, statementParams);
        statement.setOnClickListener(v -> Ui.open(this, ExtratoActivity.class));
        status = Ui.text(this, "Consultando recebimentos…", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = Ui.d(this, 9);
        page.addView(status, statusParams);
        entries = Ui.column(this);
        page.addView(entries);
        refresh = Ui.button(this, "Atualizar recebimentos", Palette.NAVY);
        page.addView(refresh, new LinearLayout.LayoutParams(-1, Ui.d(this, 48)));
        refresh.setOnClickListener(v -> load());
        Button back = Ui.button(this, "Voltar ao início", Palette.GREEN);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 48));
        backParams.topMargin = Ui.d(this, 8);
        page.addView(back, backParams);
        back.setOnClickListener(v -> finish());
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        activityVisible = true;
        if (refresh != null) {
            handler.removeCallbacks(pollTask);
            load();
            handler.postDelayed(pollTask, POLL_MILLIS);
        }
    }

    @Override protected void onPause() {
        activityVisible = false;
        handler.removeCallbacks(pollTask);
        super.onPause();
    }

    private void load() {
        if (!activityVisible || requestInProgress) return;
        requestInProgress = true;
        status.setText("Consultando a resposta do administrador…");
        refresh.setEnabled(false);
        new Thread(() -> {
            JSONArray rows = null;
            try {
                String token = SessionStore.accessToken();
                if (token.isEmpty()) throw new Exception("session");
                rows = InterbankRest.get("interbank_incoming_transfers?select=transfer_id,sender_account,sender_name,amount,status,source_commit_status,created_at,reviewed_at,credited_at&order=created_at.desc&limit=100", token);
            } catch (Exception ignored) { }
            final JSONArray result = rows;
            runOnUiThread(() -> {
                requestInProgress = false;
                refresh.setEnabled(true);
                render(result);
            });
        }, "meunova-incoming-transfers").start();
    }

    private void render(JSONArray rows) {
        entries.removeAllViews();
        if (rows == null) {
            status.setText("Não foi possível consultar os recebimentos. Tente atualizar.");
            return;
        }
        status.setText(rows.length() == 0 ? "Nenhum recebimento encontrado." : "Resposta consultada · " + rows.length() + " operação(ões)");
        Map<String, String> currentStates = new HashMap<>();
        String approvalNotice = null;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String state = row.optString("status", "pending_admin");
            String transferId = row.optString("transfer_id", "");
            if (!transferId.isEmpty()) {
                String previous = observedStates.get(transferId);
                if (initialStateLoaded && previous != null && !previous.equals(state)) approvalNotice = statusChangeMessage(state);
                currentStates.put(transferId, state);
            }
            boolean credited = "credited".equals(state);
            LinearLayout card = Ui.column(this);
            card.setPadding(Ui.d(this, 14), Ui.d(this, 12), Ui.d(this, 14), Ui.d(this, 12));
            card.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 16)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.topMargin = Ui.d(this, 7);
            params.bottomMargin = Ui.d(this, 5);
            entries.addView(card, params);
            card.addView(Ui.text(this, row.optString("sender_name", "SANBANK") + " · conta " + row.optString("sender_account", "—"), 15, Palette.NAVY, true));
            String amountCaption = credited ? "Valor creditado" : "approved_waiting_source".equals(state) ? "Aprovado pelo administrador · aguardando débito na origem" : "Valor solicitado · ainda não creditado";
            card.addView(Ui.text(this, amountCaption + ": " + formatAmount(row.optString("amount", "0")), 17, credited ? Palette.GREEN : Palette.MUTED, true));
            int stateColor = credited ? Palette.GREEN : "rejected".equals(state) ? Palette.RED : Color.rgb(177, 112, 16);
            card.addView(Ui.text(this, stateLabel(state), 12, stateColor, true));
            String reviewedAt = row.optString("reviewed_at", "");
            String date = credited ? row.optString("credited_at", "") : !reviewedAt.isEmpty() ? reviewedAt : row.optString("created_at", "");
            if (!date.isEmpty()) card.addView(Ui.text(this, (credited ? "Crédito confirmado · " : "Última atualização · ") + formatDate(date), 11, Palette.MUTED, false));
            card.addView(Ui.text(this, "ID: " + transferId, 10, Palette.MUTED, false));
        }
        observedStates.putAll(currentStates);
        initialStateLoaded = true;
        if (approvalNotice != null) {
            Toast.makeText(this, approvalNotice, Toast.LENGTH_LONG).show();
            status.setText("Resposta nova do administrador recebida.");
        }
    }

    private String statusChangeMessage(String state) {
        switch (state) {
            case "approved_waiting_source": return "Recebimento aprovado pelo administrador do MEU NOVA; aguardando confirmação da origem.";
            case "credited": return "Crédito confirmado: saldo atualizado e lançamento gravado no extrato.";
            case "rejected": return "Recebimento recusado pelo administrador; nenhum saldo foi alterado.";
            case "source_failed": return "Ainda não houve confirmação do débito na origem; saldo não foi creditado.";
            default: return "O status do recebimento foi atualizado: " + state + ".";
        }
    }

    private String stateLabel(String state) {
        switch (state) {
            case "pending_admin": return "Aguardando aprovação do administrador do MEU NOVA";
            case "approved_waiting_source": return "Aprovado · aguardando confirmação do débito na origem";
            case "credited": return "Creditado no saldo e lançado no extrato";
            case "rejected": return "Recusado · sem movimentação de saldo";
            case "source_failed": return "Débito na origem não confirmado · aguardando revisão";
            default: return "Em processamento · sem confirmação de crédito";
        }
    }

    private String formatAmount(String raw) {
        try {
            BigDecimal value = new BigDecimal(raw).abs();
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("pt", "BR"));
            return new DecimalFormat("R$ #,##0.00", symbols).format(value);
        } catch (Exception ignored) { return "R$ 0,00"; }
    }

    private String formatDate(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        return raw.replace('T', ' ').replace("Z", "");
    }
}
