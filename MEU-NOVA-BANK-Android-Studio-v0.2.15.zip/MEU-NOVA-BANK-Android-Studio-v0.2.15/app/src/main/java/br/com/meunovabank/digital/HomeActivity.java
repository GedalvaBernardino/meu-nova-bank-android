package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class HomeActivity extends Activity {
    private boolean amountsHidden = false;
    private TextView privacyButton;
    private TextView balanceValue;
    private TextView specialAvailable;
    private TextView specialTotal;
    private TextView specialUsed;
    private TextView customerName;
    private TextView accountIdentity;
    private String latestWalletBalance;
    private final Map<String, List<View>> featureViews = new LinkedHashMap<>();

    @Override public void onResume() {
        super.onResume();
        refreshThemeTier();
        loadWalletBalance();
        loadProfileIdentity();
        loadFeatureVisibility();
    }

    private void refreshThemeTier() {
        final String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) return;
        SupabaseProfileClient.fetchThemeTier(token, account, tier -> {
            if (tier == null || tier.isEmpty()) return;
            boolean changed = Palette.applyTheme(getApplicationContext(), tier);
            if (changed) runOnUiThread(() -> {
                if (!isFinishing() && !isDestroyed()) recreate();
            });
        });
    }

    private void loadWalletBalance() {
        final String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) return;
        new Thread(() -> {
            String amount = null;
            try {
                org.json.JSONArray profiles = InterbankRest.get("customer_profiles?select=user_id&account_number=eq." + account + "&limit=1", token);
                String userId = profiles.length() == 0 ? "" : profiles.optJSONObject(0).optString("user_id", "");
                if (!userId.isEmpty()) {
                    org.json.JSONArray wallets = InterbankRest.get("wallets?select=available_balance&user_id=eq." + java.net.URLEncoder.encode(userId, "UTF-8") + "&limit=1", token);
                    if (wallets.length() > 0) amount = wallets.optJSONObject(0).optString("available_balance", null);
                }
            } catch (Exception ignored) { }
            final String value = amount;
            runOnUiThread(() -> {
                if (value != null) latestWalletBalance = value;
                if (balanceValue != null && !amountsHidden) balanceValue.setText(formatWalletBalance(latestWalletBalance));
            });
        }, "meunova-wallet-balance").start();
    }

    private void loadProfileIdentity() {
        final String token = SessionStore.accessToken();
        final String account = SessionStore.accountNumber();
        if (customerName == null || accountIdentity == null || !account.matches("[0-9]{6}")) return;
        accountIdentity.setText("Conta " + account);
        customerName.setText("Carregando nome…");
        SupabaseProfileClient.fetchDisplayName(token, account, name -> runOnUiThread(() -> {
            if (customerName == null || !account.equals(SessionStore.accountNumber())) return;
            String value = name == null ? "" : name.trim();
            customerName.setText(value.isEmpty() ? "Nome indisponível" : value);
        }));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Palette.loadSaved(this);
        amountsHidden = getSharedPreferences("meunova_user_settings", MODE_PRIVATE).getBoolean("hide_balance", false);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.column(this);
        root.setPadding(Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 28));
        scroll.addView(root);
        setContentView(scroll);

        addHeader(root);
        addBalanceCard(root);
        addSpecialCard(root);
        addQuickActions(root);

        Ui.section(this, root, "Todas as funções", "Acesse cada área do aplicativo");
        Ui.section(this, root, "Movimentações", "Transferências e recebimentos");
        addFeatureCard(root, "pix", "Pix", "Enviar e receber Pix", PixActivity.class);
        addFeatureCard(root, "dem_transfer", "Transferência DEM", "Transferências entre contas", TransferenciaActivity.class);
        addFeatureCard(root, "interbank_receipts", "Recebimentos SANBANK", "Consultar transferências antigas recebidas", IncomingTransfersActivity.class);

        Ui.section(this, root, "Pagamentos e cartão", "Acompanhe sua conta e pagamentos");
        addFeatureCard(root, "neo_card", "Meu Nova Card", "Cartão de crédito virtual demonstrativo", CartaoActivity.class);
        addFeatureCard(root, "statement", "Extrato", "Movimentações e filtros", ExtratoActivity.class);
        addFeatureCard(root, "payments", "Pagamentos", "Pagar contas e serviços", PagamentosActivity.class);
        addFeatureCard(root, "bill", "Boleto", "Leitura e pagamento de boleto", BoletoActivity.class);

        Ui.section(this, root, "QR Code", "Pagar, receber ou gerar uma cobrança");
        addFeatureCard(root, "pay_qr", "Pagar QR", "Leitura de QR Code", PagarQrActivity.class);
        addCombinedQrFeatureCard(root);

        Ui.section(this, root, "Serviços financeiros", "Outros recursos disponíveis");
        addFeatureCard(root, "yield_cdi", "Rendimento CDI", "Saldo e simulação", RendimentoActivity.class);
        addFeatureCard(root, "loans", "Empréstimos", "Opções e solicitações", EmprestimosActivity.class);

        Ui.section(this, root, "Conta e suporte", "Dados, segurança e atendimento");
        addFeatureCard(root, "support", "Suporte", "Atendimento ao cliente", SuporteActivity.class);
        addFeatureCard(root, "notifications", "Notificações", "Avisos e alertas", NotificacoesActivity.class);
        addFeatureCard(root, "profile", "Perfil", "Dados cadastrais", PerfilActivity.class);
        addFeatureCard(root, "security", "Segurança", "Dispositivos e acesso", SegurancaActivity.class);
        addFeatureCard(root, "settings", "Configurações", "Preferências do aplicativo", ConfiguracoesActivity.class);
        addFeatureCard(root, "open_account", "Abrir conta", "Solicitar cadastro", AbrirContaActivity.class);
        addFeatureCard(root, "recover_password", "Recuperar senha", "Redefinição de acesso", RecuperarSenhaActivity.class);
        applyAmountsVisibility();
    }

    private void addFeatureCard(LinearLayout root, String key, String title, String subtitle, Class<? extends Activity> target) {
        View card = Ui.card(this, root, title, subtitle, () -> Ui.open(this, target));
        registerFeatureView(key, card);
    }

    private void addCombinedQrFeatureCard(LinearLayout root) {
        View card = Ui.card(this, root, "Cobrar / receber por QR", "Gerar um QR com sua conta e o valor da cobrança", () -> Ui.open(this, DepositoQrActivity.class));
        registerFeatureView("qr_collect", card);
    }

    private void registerFeatureView(String key, View view) {
        List<View> views = featureViews.get(key);
        if (views == null) { views = new ArrayList<>(); featureViews.put(key, views); }
        views.add(view);
    }

    private void loadFeatureVisibility() {
        final String token = SessionStore.accessToken();
        if (token.isEmpty() || featureViews.isEmpty()) return;
        new Thread(() -> {
            try {
                JSONObject visibility = InterbankRest.rpc("meunova_get_user_feature_visibility", token, new JSONObject());
                runOnUiThread(() -> {
                    for (Map.Entry<String, List<View>> entry : featureViews.entrySet()) {
                        boolean visible;
                        if ("qr_collect".equals(entry.getKey())) {
                            visible = visibility.optBoolean("deposit_qr", true) || visibility.optBoolean("charge_qr", true);
                        } else {
                            visible = visibility.optBoolean(entry.getKey(), true);
                        }
                        for (View view : entry.getValue()) view.setVisibility(visible ? View.VISIBLE : View.GONE);
                    }
                });
            } catch (Exception ignored) {
                // Falha de rede ou migração ausente: manter o menu visível, sem bloquear o usuário.
            }
        }, "meunova-feature-visibility").start();
    }

    private void addHeader(LinearLayout root) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.d(this, 13), Ui.d(this, 11), Ui.d(this, 11), Ui.d(this, 11));
        row.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 22)));
        row.setElevation(Ui.d(this, 2));
        TextView emblem = Ui.text(this, "N", 18, Color.WHITE, true);
        emblem.setGravity(Gravity.CENTER);
        emblem.setBackground(Ui.bg(Palette.NAVY, Ui.d(this, 16)));
        row.addView(emblem, new LinearLayout.LayoutParams(Ui.d(this, 46), Ui.d(this, 46)));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(Ui.d(this, 11), 0, Ui.d(this, 5), 0);
        row.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(Ui.text(this, "MEU NOVA BANK", 16, Palette.NAVY, true));
        customerName = Ui.text(this, "Carregando nome…", 10, Palette.TEXT, true);
        customerName.setSingleLine(true);
        customerName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 15));
        nameLp.topMargin = Ui.d(this, 2);
        brand.addView(customerName, nameLp);
        accountIdentity = Ui.text(this, "Conta " + SessionStore.accountNumber(), 9, Palette.MUTED, false);
        accountIdentity.setSingleLine(true);
        LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 13));
        accountLp.topMargin = Ui.d(this, 1);
        brand.addView(accountIdentity, accountLp);

        privacyButton = new TextView(this);
        privacyButton.setText("Ocultar");
        privacyButton.setTextSize(12);
        privacyButton.setTextColor(Palette.NAVY);
        privacyButton.setGravity(Gravity.CENTER);
        privacyButton.setPadding(Ui.d(this, 12), Ui.d(this, 8), Ui.d(this, 12), Ui.d(this, 8));
        privacyButton.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 16)));
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        actions.addView(privacyButton, new LinearLayout.LayoutParams(-2, Ui.d(this, 38)));
        Button logout = Ui.button(this, "Sair", Palette.RED);
        logout.setTextSize(12);
        LinearLayout.LayoutParams logoutParams = new LinearLayout.LayoutParams(Ui.d(this, 66), Ui.d(this, 38));
        logoutParams.leftMargin = Ui.d(this, 6);
        actions.addView(logout, logoutParams);
        row.addView(actions, new LinearLayout.LayoutParams(-2, -2));
        privacyButton.setOnClickListener(v -> toggleAmounts());
        logout.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Sair da conta?")
                .setMessage("A sessão será removida deste aparelho. Para voltar, será necessário entrar novamente.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Sair", (dialog, which) -> {
                    SessionStore.clear(this);
                    Intent login = new Intent(this, LoginActivity.class);
                    login.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(login);
                    finish();
                }).show());
        root.addView(row);
    }

    private void addBalanceCard(LinearLayout root) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.d(this, 20), Ui.d(this, 18), Ui.d(this, 20), Ui.d(this, 17));
        GradientDrawable gradient = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Palette.NAVY_DARK, Palette.NAVY, blend(Palette.NAVY, Color.WHITE, 0.22f)});
        gradient.setCornerRadius(Ui.d(this, 24));
        card.setBackground(gradient);
        card.setElevation(Ui.d(this, 4));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = Ui.d(this, 19);
        root.addView(card, cp);

        TextView eyebrow = Ui.text(this, "SALDO DISPONÍVEL", 11, Color.rgb(205, 222, 242), true);
        eyebrow.setLetterSpacing(0.12f);
        card.addView(eyebrow);
        balanceValue = Ui.text(this, "R$ —", 31, Color.WHITE, true);
        LinearLayout.LayoutParams amount = new LinearLayout.LayoutParams(-1, -2);
        amount.topMargin = Ui.d(this, 5);
        card.addView(balanceValue, amount);
        TextView caption = Ui.text(this, "Seu dinheiro disponível para movimentações", 12, Color.rgb(220, 232, 246), false);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, -2);
        cp2.topMargin = Ui.d(this, 4);
        card.addView(caption, cp2);

        TextView statement = Ui.text(this, "Ver extrato   ›", 13, Color.WHITE, true);
        statement.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        statement.setPadding(0, Ui.d(this, 13), 0, 0);
        card.addView(statement, new LinearLayout.LayoutParams(-1, -2));
        statement.setOnClickListener(v -> Ui.open(this, ExtratoActivity.class));
        registerFeatureView("statement", statement);
    }

    private void addQuickActions(LinearLayout root) {
        Ui.section(this, root, "Acesso rápido", "As tarefas mais usadas, a um toque");
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        addQuickAction(row, "pix", "↗", "Pix", PixActivity.class);
        addQuickAction(row, "dem_transfer", "⇄", "Transferir", TransferenciaActivity.class);
        addQuickAction(row, "statement", "▤", "Extrato", ExtratoActivity.class);
        addQuickAction(row, "qr_collect", "▦", "Cobrar", DepositoQrActivity.class);
        root.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void addQuickAction(LinearLayout row, String featureKey, String glyph, String label, Class<? extends Activity> target) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        item.setPadding(Ui.d(this, 5), Ui.d(this, 11), Ui.d(this, 5), Ui.d(this, 10));
        item.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 19)));
        item.setElevation(Ui.d(this, 1));
        TextView icon = Ui.text(this, glyph, 19, Palette.NAVY, true);
        icon.setGravity(Gravity.CENTER);
        icon.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 15)));
        item.addView(icon, new LinearLayout.LayoutParams(Ui.d(this, 38), Ui.d(this, 38)));
        TextView caption = Ui.text(this, label, 10, Palette.TEXT, true);
        caption.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = Ui.d(this, 7);
        item.addView(caption, cp);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, -2, 1);
        ip.setMargins(Ui.d(this, 3), 0, Ui.d(this, 3), 0);
        row.addView(item, ip);
        item.setContentDescription(label);
        item.setOnClickListener(v -> Ui.open(this, target));
        registerFeatureView(featureKey, item);
        item.setClickable(true);
        item.setFocusable(true);
        item.setOnTouchListener((v, event) -> {
            if (event.getAction() == android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(.96f).scaleY(.96f).setDuration(110).start();
            else if (event.getAction() == android.view.MotionEvent.ACTION_UP || event.getAction() == android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(180).start();
            return false;
        });
    }

    private int blend(int color, int with, float ratio) {
        int red = Math.round(Color.red(color) * (1f - ratio) + Color.red(with) * ratio);
        int green = Math.round(Color.green(color) * (1f - ratio) + Color.green(with) * ratio);
        int blue = Math.round(Color.blue(color) * (1f - ratio) + Color.blue(with) * ratio);
        return Color.rgb(red, green, blue);
    }

    private void addSpecialCard(LinearLayout root) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.d(this, 18), Ui.d(this, 17), Ui.d(this, 18), Ui.d(this, 17));
        GradientDrawable surface = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.WHITE, Color.rgb(239, 250, 246)});
        surface.setCornerRadius(Ui.d(this, 24));
        surface.setStroke(Ui.d(this, 1), Color.rgb(226, 232, 240));
        card.setBackground(surface);
        card.setElevation(Ui.d(this, 2));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = Ui.d(this, 13);
        root.addView(card, cp);

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "Cheque especial", 18, Palette.NAVY, true);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = Ui.text(this, "LIMITE", 10, Palette.GREEN, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(Ui.d(this, 10), Ui.d(this, 6), Ui.d(this, 10), Ui.d(this, 6));
        badge.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 14)));
        titleRow.addView(badge, new LinearLayout.LayoutParams(-2, -2));
        card.addView(titleRow);

        TextView subtitle = Ui.text(this, "Uma margem extra para imprevistos", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams subp = new LinearLayout.LayoutParams(-1, -2);
        subp.topMargin = Ui.d(this, 3);
        card.addView(subtitle, subp);

        TextView availLabel = Ui.text(this, "DISPONÍVEL PARA USO", 10, Palette.MUTED, true);
        availLabel.setLetterSpacing(0.09f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.d(this, 16);
        card.addView(availLabel, lp);
        specialAvailable = Ui.text(this, "R$ —", 26, Palette.GREEN, true);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = Ui.d(this, 2);
        card.addView(specialAvailable, ap);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.topMargin = Ui.d(this, 14);
        card.addView(stats, stp);
        stats.addView(statBox("Limite total", specialTotal = Ui.text(this, "R$ —", 15, Palette.NAVY, true)), new LinearLayout.LayoutParams(0, -2, 1));
        View gap = new View(this);
        stats.addView(gap, new LinearLayout.LayoutParams(Ui.d(this, 10), 1));
        stats.addView(statBox("Em uso", specialUsed = Ui.text(this, "R$ —", 15, Palette.TEXT, true)), new LinearLayout.LayoutParams(0, -2, 1));
    }

    private LinearLayout statBox(String label, TextView value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.d(this, 12), Ui.d(this, 10), Ui.d(this, 12), Ui.d(this, 10));
        box.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 15)));
        box.addView(Ui.text(this, label, 11, Palette.MUTED, false));
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.topMargin = Ui.d(this, 3);
        box.addView(value, vp);
        return box;
    }

    private String formatWalletBalance(String raw) {
        if (raw == null || raw.isEmpty()) return "R$ —";
        try {
            java.math.BigDecimal value = new java.math.BigDecimal(raw);
            java.text.DecimalFormatSymbols symbols = new java.text.DecimalFormatSymbols(new java.util.Locale("pt", "BR"));
            return new java.text.DecimalFormat("R$ #,##0.00", symbols).format(value);
        } catch (Exception ignored) { return "R$ —"; }
    }

    private void toggleAmounts() {
        amountsHidden = !amountsHidden;
        getSharedPreferences("meunova_user_settings", MODE_PRIVATE).edit().putBoolean("hide_balance", amountsHidden).apply();
        applyAmountsVisibility();
    }

    private void applyAmountsVisibility() {
        if (balanceValue == null || specialAvailable == null || specialTotal == null || specialUsed == null) return;
        String privateAmount = amountsHidden ? "••••••" : "R$ —";
        balanceValue.setText(amountsHidden ? privateAmount : formatWalletBalance(latestWalletBalance));
        specialAvailable.setText(privateAmount);
        specialTotal.setText(privateAmount);
        specialUsed.setText(privateAmount);
        if (privacyButton != null) privacyButton.setText(amountsHidden ? "Mostrar" : "Ocultar");
    }
}
