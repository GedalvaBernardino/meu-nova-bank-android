package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Dedicated boleto screen; validates only local barcode length and never pays or queries a bank. */
public final class BoletoActivity extends Activity {
    private EditText barcode;private TextView status;
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Boleto","Conferência local do código de barras");
        barcode=Ui.input(this,"Digite ou cole o código do boleto",InputType.TYPE_CLASS_NUMBER);barcode.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(47)});root.addView(barcode,new LinearLayout.LayoutParams(-1,Ui.d(this,54)));
        status=Ui.text(this,"Nenhum código conferido.",13,Palette.MUTED,false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=Ui.d(this,10);root.addView(status,sp);
        Button check=Ui.button(this,"Conferir formato",Palette.NAVY);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,Ui.d(this,52));bp.topMargin=Ui.d(this,12);root.addView(check,bp);
        Ui.card(this,root,"Pagamento indisponível","A validação é apenas local. O app não consulta o emissor nem paga este boleto.",null);
        check.setOnClickListener(v->{String code=barcode.getText().toString().replaceAll("\\s","");if(!code.matches("\\d{44}|\\d{47}")){status.setText("O código deve ter 44 ou 47 dígitos. Confira e tente novamente.");return;}new AlertDialog.Builder(this).setTitle("Formato reconhecido").setMessage("O código tem o comprimento esperado. O emissor não foi consultado e nenhum pagamento foi feito.").setPositiveButton("Entendi",(d,w)->status.setText("Conferência local concluída; não pago.")).show();});setContentView(root);}
}
