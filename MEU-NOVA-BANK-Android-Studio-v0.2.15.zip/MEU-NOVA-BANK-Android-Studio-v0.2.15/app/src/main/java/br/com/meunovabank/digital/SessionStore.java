package br.com.meunovabank.digital;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.KeyPairGeneratorSpec;
import android.util.Base64;

import org.json.JSONObject;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.util.Calendar;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.security.auth.x500.X500Principal;

/** Sessão em memória; quando o usuário opta por permanecer conectado, tokens cifrados com Android Keystore. */
public final class SessionStore {
    private static final String PREFS = "meunova_secure_session";
    private static final String BLOB = "session_ciphertext";
    private static final String IV = "session_iv";
    private static final String WRAPPED_KEY = "session_wrapped_key";
    private static final String ALIAS = "meunovabank.session.rsa.v1";
    private static volatile String accessToken = "";
    private static volatile String refreshToken = "";
    private static volatile String accountNumber = "";

    private SessionStore() {}

    public static void set(String access, String refresh) { set(access, refresh, ""); }

    public static void set(String access, String refresh, String account) {
        accessToken = access == null ? "" : access;
        refreshToken = refresh == null ? "" : refresh;
        accountNumber = account == null ? "" : account;
    }

    public static String accessToken() { return accessToken; }
    public static String refreshToken() { return refreshToken; }
    public static String accountNumber() { return accountNumber; }
    public static boolean hasSavedSession(Context context) {
        SharedPreferences p = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return !p.getString(BLOB, "").isEmpty() && !p.getString(IV, "").isEmpty() && !p.getString(WRAPPED_KEY, "").isEmpty();
    }

    /** Descriptografa a sessão salva, sem salvar nem reter a senha do usuário. */
    public static boolean restore(Context context) {
        try {
            Context app = context.getApplicationContext();
            SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String blob = p.getString(BLOB, ""), ivText = p.getString(IV, ""), wrappedText = p.getString(WRAPPED_KEY, "");
            if (blob.isEmpty() || ivText.isEmpty() || wrappedText.isEmpty()) return false;
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsa.init(Cipher.DECRYPT_MODE, keyStore.getKey(ALIAS, null));
            byte[] aesBytes = rsa.doFinal(Base64.decode(wrappedText, Base64.NO_WRAP));
            javax.crypto.SecretKey aesKey = new javax.crypto.spec.SecretKeySpec(aesBytes, "AES");
            Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
            aes.init(Cipher.DECRYPT_MODE, aesKey, new IvParameterSpec(Base64.decode(ivText, Base64.NO_WRAP)));
            String json = new String(aes.doFinal(Base64.decode(blob, Base64.NO_WRAP)), StandardCharsets.UTF_8);
            JSONObject session = new JSONObject(json);
            String access = session.optString("access_token", ""), refresh = session.optString("refresh_token", ""), account = session.optString("account_number", "");
            if (access.isEmpty() || refresh.isEmpty() || !account.matches("[0-9]{6,7}")) return false;
            set(access, refresh, account);
            return true;
        } catch (Exception ignored) { return false; }
    }

    /** Armazena apenas tokens cifrados; a senha nunca é persistida. */
    public static void persist(Context context) throws Exception {
        if (accessToken.isEmpty() || refreshToken.isEmpty() || !accountNumber.matches("[0-9]{6,7}")) throw new IllegalStateException("Sessão incompleta");
        Context app = context.getApplicationContext();
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (!keyStore.containsAlias(ALIAS)) createKeyPair(app);
        keyStore.load(null);
        Certificate cert = keyStore.getCertificate(ALIAS);
        if (cert == null) throw new IllegalStateException("Chave segura indisponível");

        JSONObject json = new JSONObject();
        json.put("access_token", accessToken);
        json.put("refresh_token", refreshToken);
        json.put("account_number", accountNumber);
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        generator.init(256);
        SecretKey aesKey = generator.generateKey();
        Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
        aes.init(Cipher.ENCRYPT_MODE, aesKey);
        byte[] encrypted = aes.doFinal(json.toString().getBytes(StandardCharsets.UTF_8));
        Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        rsa.init(Cipher.ENCRYPT_MODE, cert.getPublicKey());
        byte[] wrapped = rsa.doFinal(aesKey.getEncoded());
        SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        p.edit().putString(BLOB, Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .putString(IV, Base64.encodeToString(aes.getIV(), Base64.NO_WRAP))
                .putString(WRAPPED_KEY, Base64.encodeToString(wrapped, Base64.NO_WRAP)).commit();
    }

    private static void createKeyPair(Context context) throws Exception {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA", "AndroidKeyStore");
        Calendar start = Calendar.getInstance(), end = Calendar.getInstance();
        end.add(Calendar.YEAR, 30);
        KeyPairGeneratorSpec spec = new KeyPairGeneratorSpec.Builder(context)
                .setAlias(ALIAS)
                .setSubject(new X500Principal("CN=MEU NOVA BANK Session"))
                .setSerialNumber(BigInteger.ONE)
                .setStartDate(new Date(start.getTimeInMillis()))
                .setEndDate(new Date(end.getTimeInMillis()))
                .build();
        generator.initialize(spec);
        generator.generateKeyPair();
    }

    /** Remove somente a sessão persistida; usado quando a opção de manter conectado é desligada. */
    public static void clearSaved(Context context) {
        try { context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit(); } catch (Exception ignored) { }
        try {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (keyStore.containsAlias(ALIAS)) keyStore.deleteEntry(ALIAS);
        } catch (Exception ignored) { }
    }

    public static void clear(Context context) {
        clear();
        clearSaved(context);
    }

    /** Limpa apenas a sessão em memória. */
    public static void clear() {
        accessToken = "";
        refreshToken = "";
        accountNumber = "";
    }
}
