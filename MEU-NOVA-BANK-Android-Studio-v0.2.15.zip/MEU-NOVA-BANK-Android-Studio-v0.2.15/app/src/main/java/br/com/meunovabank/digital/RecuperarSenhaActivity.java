package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** In-app recovery. The account only selects the user; Supabase's verified email link proves ownership. */
public final class RecuperarSenhaActivity extends Activity {
    private int step = 1; // 1=request, 2=set new password after verified recovery link, 3=check email
    private String accountNumber = "";
    private String recoveryAccessToken = "";
    private Button actionButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        acceptRecoveryIntent(getIntent());
        render();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        acceptRecoveryIntent(intent);
        render();
    }

    private void acceptRecoveryIntent(Intent intent) {
        String token = intent == null ? null : intent.getStringExtra("recovery_access_token");
        if (token != null && !token.isEmpty()) {
            recoveryAccessToken = token;
            step = 2;
        }
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.column(this);
        root.setGravity(Gravity.TOP);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = Ui.text(this, "MEU NOVA BANK · SEGURANÇA", 11, Palette.GREEN, true);
        root.addView(brand);
        String titleText = step == 1 ? "Recuperar senha" : step == 2 ? "Criar nova senha" : "Confira seu e-mail";
        TextView title = Ui.text(this, titleText, 25, Palette.NAVY, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = Ui.d(this, 20);
        root.addView(title, titleLp);

        if (step == 1) renderRequestStep(root);
        else if (step == 2) renderNewPasswordStep(root);
        else renderSentStep(root);
    }

    private void renderRequestStep(LinearLayout root) {
        TextView explanation = Ui.text(this,
                "Informe sua conta de 6 dígitos. Se estiver ativa, enviaremos um link de recuperação ao e-mail confirmado. O link retorna a esta tela no app.",
                13, Palette.MUTED, false);
        LinearLayout.LayoutParams explanationLp = new LinearLayout.LayoutParams(-1, -2);
        explanationLp.topMargin = Ui.d(this, 7);
        root.addView(explanation, explanationLp);

        TextView label = Ui.text(this, "NÚMERO DA CONTA", 10, Palette.MUTED, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = Ui.d(this, 24);
        root.addView(label, labelLp);
        EditText account = Ui.input(this, "Conta · 6 dígitos", InputType.TYPE_CLASS_NUMBER);
        account.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        account.setSaveEnabled(false);
        LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        accountLp.topMargin = Ui.d(this, 6);
        root.addView(account, accountLp);

        TextView privacy = Ui.text(this,
                "A senha não será alterada só com o número da conta. Você precisará abrir o link enviado ao e-mail cadastrado.",
                12, Palette.MUTED, false);
        privacy.setPadding(Ui.d(this, 13), Ui.d(this, 12), Ui.d(this, 13), Ui.d(this, 12));
        privacy.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 15)));
        LinearLayout.LayoutParams privacyLp = new LinearLayout.LayoutParams(-1, -2);
        privacyLp.topMargin = Ui.d(this, 13);
        root.addView(privacy, privacyLp);

        actionButton = Ui.button(this, "Enviar link seguro", Palette.RED);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        actionLp.topMargin = Ui.d(this, 21);
        root.addView(actionButton, actionLp);
        actionButton.setOnClickListener(v -> {
            String value = account.getText().toString().trim();
            if (!value.matches("[0-9]{6}")) {
                Toast.makeText(this, "Informe a conta com exatamente 6 dígitos.", Toast.LENGTH_SHORT).show();
                return;
            }
            accountNumber = value;
            setBusy("Enviando…");
            SupabaseRecoveryClient.requestRecovery(accountNumber, (success, message) -> runOnUiThread(() -> {
                if (isFinishing()) return;
                setBusy(null);
                if (!success) {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    return;
                }
                step = 3;
                render();
            }));
        });
        addBackButton(root, "Voltar ao login", this::finish);
    }

    private void renderSentStep(LinearLayout root) {
        TextView message = Ui.text(this,
                "Se a conta estiver ativa, enviamos um link ao e-mail confirmado. Abra a mensagem mais recente neste aparelho e toque no link para voltar ao app e definir a nova senha.",
                15, Palette.TEXT, false);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2);
        messageLp.topMargin = Ui.d(this, 18);
        root.addView(message, messageLp);

        TextView spam = Ui.text(this,
                "Confira Spam/Lixo eletrônico. O link expira e só pode ser usado uma vez.",
                12, Palette.MUTED, false);
        LinearLayout.LayoutParams spamLp = new LinearLayout.LayoutParams(-1, -2);
        spamLp.topMargin = Ui.d(this, 12);
        root.addView(spam, spamLp);

        actionButton = Ui.button(this, "Informar outra conta", Palette.GREEN);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        actionLp.topMargin = Ui.d(this, 22);
        root.addView(actionButton, actionLp);
        actionButton.setOnClickListener(v -> { accountNumber = ""; step = 1; render(); });
        addBackButton(root, "Voltar ao login", this::finish);
    }

    private void renderNewPasswordStep(LinearLayout root) {
        TextView explanation = Ui.text(this,
                "Seu link seguro foi validado. Crie uma senha numérica nova com exatamente 8 dígitos.",
                13, Palette.MUTED, false);
        LinearLayout.LayoutParams explanationLp = new LinearLayout.LayoutParams(-1, -2);
        explanationLp.topMargin = Ui.d(this, 7);
        root.addView(explanation, explanationLp);

        EditText password = addInput(root, "Nova senha · 8 dígitos", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8, 22);
        EditText confirm = addInput(root, "Confirme a nova senha", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8, 12);

        actionButton = Ui.button(this, "Atualizar senha", Palette.RED);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        actionLp.topMargin = Ui.d(this, 20);
        root.addView(actionButton, actionLp);
        actionButton.setOnClickListener(v -> {
            String passwordValue = password.getText().toString();
            String confirmValue = confirm.getText().toString();
            if (!passwordValue.matches("[0-9]{8}")) {
                Toast.makeText(this, "A nova senha precisa ter exatamente 8 números.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!passwordValue.equals(confirmValue)) {
                password.setText("");
                confirm.setText("");
                Toast.makeText(this, "As senhas não conferem. Digite-as novamente.", Toast.LENGTH_SHORT).show();
                return;
            }
            password.setText("");
            confirm.setText("");
            setBusy("Atualizando…");
            SupabaseRecoveryClient.updatePassword(recoveryAccessToken, passwordValue, (success, message) -> runOnUiThread(() -> {
                if (isFinishing()) return;
                setBusy(null);
                if (success) {
                    SessionStore.clear(this);
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    recoveryAccessToken = "";
                    Intent login = new Intent(this, LoginActivity.class);
                    login.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(login);
                    finish();
                } else {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                }
            }));
        });
        addBackButton(root, "Cancelar", this::finish);
    }

    private EditText addInput(LinearLayout root, String hint, int type, int maxLength, int marginTop) {
        EditText input = Ui.input(this, hint, type);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        input.setSaveEnabled(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        lp.topMargin = Ui.d(this, marginTop);
        root.addView(input, lp);
        return input;
    }

    private void addBackButton(LinearLayout root, String label, Runnable action) {
        Button back = Ui.button(this, label, Palette.NAVY);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        lp.topMargin = Ui.d(this, 10);
        root.addView(back, lp);
        back.setOnClickListener(v -> action.run());
    }

    private void setBusy(String label) {
        if (actionButton == null) return;
        if (label == null) {
            actionButton.setEnabled(true);
            actionButton.setText(step == 1 ? "Enviar link seguro" : "Atualizar senha");
        } else {
            actionButton.setEnabled(false);
            actionButton.setText(label);
        }
    }

    @Override protected void onDestroy() {
        accountNumber = "";
        recoveryAccessToken = "";
        super.onDestroy();
    }
}
