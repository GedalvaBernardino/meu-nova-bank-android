package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Native two-step recovery UI; the server must verify a code sent to the account's registered contact. */
public final class RecuperarSenhaActivity extends Activity {
    private int step = 1;
    private String accountNumber = "";
    private Button actionButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        render();
    }

    private void render() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.column(this);
        root.setGravity(Gravity.TOP);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = Ui.text(this, "MEU NOVA BANK · SEGURANÇA", 11, Palette.GREEN, true);
        root.addView(brand);
        TextView title = Ui.text(this, step == 1 ? "Recuperar senha" : "Validar código", 25, Palette.NAVY, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = Ui.d(this, 20);
        root.addView(title, titleLp);
        TextView explanation = Ui.text(this,
                step == 1
                        ? "Informe sua conta. Enviaremos um código ao contato cadastrado para confirmar que você é o titular."
                        : "Digite o código recebido e escolha uma nova senha numérica de 8 dígitos.",
                13, Palette.MUTED, false);
        LinearLayout.LayoutParams explanationLp = new LinearLayout.LayoutParams(-1, -2);
        explanationLp.topMargin = Ui.d(this, 7);
        root.addView(explanation, explanationLp);

        if (step == 1) renderRequestStep(root);
        else renderConfirmStep(root);
    }

    private void renderRequestStep(LinearLayout root) {
        TextView label = Ui.text(this, "NÚMERO DA CONTA", 10, Palette.MUTED, true);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = Ui.d(this, 24);
        root.addView(label, labelLp);
        EditText account = Ui.input(this, "Conta · 6 ou 7 dígitos", InputType.TYPE_CLASS_NUMBER);
        account.setFilters(new InputFilter[]{new InputFilter.LengthFilter(7)});
        account.setSaveEnabled(false);
        LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        accountLp.topMargin = Ui.d(this, 6);
        root.addView(account, accountLp);

        TextView privacy = Ui.text(this,
                "Por segurança, o app não revela se a conta existe. O código deve ser enviado somente ao e-mail ou celular já cadastrado.",
                12, Palette.MUTED, false);
        privacy.setPadding(Ui.d(this, 13), Ui.d(this, 12), Ui.d(this, 13), Ui.d(this, 12));
        privacy.setBackground(Ui.bg(Palette.PALE_BLUE, Ui.d(this, 15)));
        LinearLayout.LayoutParams privacyLp = new LinearLayout.LayoutParams(-1, -2);
        privacyLp.topMargin = Ui.d(this, 13);
        root.addView(privacy, privacyLp);

        actionButton = Ui.button(this, "Enviar código", Palette.RED);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        actionLp.topMargin = Ui.d(this, 21);
        root.addView(actionButton, actionLp);
        actionButton.setOnClickListener(v -> {
            String value = account.getText().toString().trim();
            if (!value.matches("[0-9]{6,7}")) {
                Toast.makeText(this, "Informe uma conta com 6 ou 7 dígitos.", Toast.LENGTH_SHORT).show();
                return;
            }
            accountNumber = value;
            setBusy("Enviando…");
            SupabaseRecoveryClient.requestCode(accountNumber, (success, message) -> runOnUiThread(() -> {
                if (isFinishing()) return;
                setBusy(null);
                if (!success) {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    return;
                }
                step = 2;
                render();
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }));
        });
        addBackButton(root, "Voltar ao login", () -> finish());
    }

    private void renderConfirmStep(LinearLayout root) {
        TextView accountLabel = Ui.text(this, "Conta informada: ••••••", 12, Palette.MUTED, true);
        LinearLayout.LayoutParams accountLp = new LinearLayout.LayoutParams(-1, -2);
        accountLp.topMargin = Ui.d(this, 18);
        root.addView(accountLabel, accountLp);

        EditText code = addInput(root, "Código de verificação · 6 dígitos", InputType.TYPE_CLASS_NUMBER, 6, 19);
        EditText password = addInput(root, "Nova senha · 8 dígitos", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8, 12);
        EditText confirm = addInput(root, "Confirme a nova senha", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD, 8, 12);
        password.setSaveEnabled(false);
        confirm.setSaveEnabled(false);

        actionButton = Ui.button(this, "Atualizar senha", Palette.RED);
        LinearLayout.LayoutParams actionLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        actionLp.topMargin = Ui.d(this, 20);
        root.addView(actionButton, actionLp);
        actionButton.setOnClickListener(v -> {
            String codeValue = code.getText().toString().trim();
            String passwordValue = password.getText().toString();
            String confirmValue = confirm.getText().toString();
            if (!codeValue.matches("[0-9]{6}")) {
                Toast.makeText(this, "Informe o código de 6 dígitos.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!passwordValue.matches("[0-9]{8}")) {
                Toast.makeText(this, "A nova senha precisa ter exatamente 8 números.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!passwordValue.equals(confirmValue)) {
                password.setText("");
                confirm.setText("");
                Toast.makeText(this, "As senhas não conferem. Digite-as novamente.", Toast.LENGTH_SHORT).show();
                return;
            }
            code.setText("");
            password.setText("");
            confirm.setText("");
            setBusy("Validando…");
            SupabaseRecoveryClient.confirmCode(accountNumber, codeValue, passwordValue, (success, message) -> runOnUiThread(() -> {
                if (isFinishing()) return;
                setBusy(null);
                if (success) {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                }
            }));
        });
        addBackButton(root, "Voltar", () -> { step = 1; render(); });
    }

    private EditText addInput(LinearLayout root, String hint, int type, int maxLength, int marginTop) {
        EditText input = Ui.input(this, hint, type);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        input.setSaveEnabled(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        lp.topMargin = Ui.d(this, marginTop);
        root.addView(input, lp);
        return input;
    }

    private void addBackButton(LinearLayout root, String label, Runnable action) {
        Button back = Ui.button(this, label, Palette.NAVY);
        LinearLayout.LayoutParams backLp = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        backLp.topMargin = Ui.d(this, 10);
        root.addView(back, backLp);
        back.setOnClickListener(v -> action.run());
    }

    private void setBusy(String label) {
        if (actionButton == null) return;
        if (label == null) {
            actionButton.setEnabled(true);
            actionButton.setText(step == 1 ? "Enviar código" : "Atualizar senha");
        } else {
            actionButton.setEnabled(false);
            actionButton.setText(label);
        }
    }

    @Override protected void onDestroy() {
        accountNumber = "";
        super.onDestroy();
    }
}
