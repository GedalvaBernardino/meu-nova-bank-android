package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

/** Dedicated information screen for the demo CDI feature; avoids inventing rates or returns. */
public final class RendimentoActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Rendimento CDI","Informações sobre o recurso demonstrativo");
        Ui.card(this,root,"Saldo elegível","A consulta de saldo e o cálculo de rendimento ainda não estão conectados.",null);
        Ui.card(this,root,"Taxa CDI","Não há uma taxa atual configurada nesta prévia; por isso nenhum rendimento estimado é exibido.",null);
        Ui.card(this,root,"Próximo passo","Quando a integração estiver disponível, esta Activity poderá exibir saldo, período e simulação com a taxa informada pelo servidor.",null);
        Ui.card(this,root,"Demonstração","Nenhum investimento, aplicação ou movimentação financeira é realizado aqui.",null);setContentView(root);}
}
