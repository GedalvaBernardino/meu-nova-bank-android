package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/** Colagem e conferência de payloads QR no protótipo MEU NOVA BANK. */
public final class QrPastePaymentActivity extends Activity {
    private EditText payloadInput;
    private LinearLayout reviewCard;
    private TextView status;
    private String account = "", recipient = "", institution = "", description = "";
    private BigDecimal amount = BigDecimal.ZERO;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.column(this);
        page.setPadding(Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 28));
        scroll.addView(page);
        setContentView(scroll);

        page.addView(Ui.text(this, "MEU NOVA BANK BR DIGITAL", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Colar código QR", 26, Palette.NAVY, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = Ui.d(this, 16);
        page.addView(title, titleParams);
        page.addView(Ui.text(this, "Cole o texto contido no QR Code para conferir instituição, conta e valor.", 13, Palette.MUTED, false));

        payloadInput = new EditText(this);
        payloadInput.setHint("Cole aqui o conteúdo do QR Code");
        payloadInput.setTextSize(14);
        payloadInput.setTextColor(Palette.TEXT);
        payloadInput.setGravity(Gravity.TOP | Gravity.START);
        payloadInput.setMinLines(4);
        payloadInput.setMaxLines(8);
        payloadInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        payloadInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(8192)});
        payloadInput.setPadding(Ui.d(this, 13), Ui.d(this, 12), Ui.d(this, 13), Ui.d(this, 12));
        payloadInput.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 14)));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 128));
        inputParams.topMargin = Ui.d(this, 14);
        page.addView(payloadInput, inputParams);

        Button paste = Ui.button(this, "Colar da área de transferência", Palette.NAVY);
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 48));
        buttonParams.topMargin = Ui.d(this, 10);
        page.addView(paste, buttonParams);
        paste.setOnClickListener(v -> pasteFromClipboard());

        Button validate = Ui.button(this, "Conferir QR Code", Palette.GREEN);
        LinearLayout.LayoutParams validateParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        validateParams.topMargin = Ui.d(this, 8);
        page.addView(validate, validateParams);
        validate.setOnClickListener(v -> validatePayload());

        status = Ui.text(this, "Nenhum código conferido.", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = Ui.d(this, 9);
        page.addView(status, statusParams);

        reviewCard = Ui.column(this);
        reviewCard.setVisibility(View.GONE);
        reviewCard.setPadding(Ui.d(this, 15), Ui.d(this, 14), Ui.d(this, 15), Ui.d(this, 14));
        reviewCard.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 16)));
        LinearLayout.LayoutParams reviewParams = new LinearLayout.LayoutParams(-1, -2);
        reviewParams.topMargin = Ui.d(this, 12);
        page.addView(reviewCard, reviewParams);

        TextView note = Ui.text(this,
                "Protótipo: esta tela apenas confere os dados do QR. Não envia pagamentos nem movimenta ou credita dinheiro.",
                12, Color.rgb(112, 88, 29), false);
        note.setPadding(Ui.d(this, 12), Ui.d(this, 10), Ui.d(this, 12), Ui.d(this, 10));
        note.setBackground(Ui.bg(Color.rgb(255, 247, 225), Ui.d(this, 13)));
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = Ui.d(this, 14);
        page.addView(note, noteParams);

        Button back = Ui.button(this, "Voltar", Palette.NAVY);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 48));
        backParams.topMargin = Ui.d(this, 14);
        page.addView(back, backParams);
        back.setOnClickListener(v -> finish());
    }

    private void pasteFromClipboard() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null || !clipboard.hasPrimaryClip()) {
            Toast.makeText(this, "A área de transferência está vazia.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipData clip = clipboard.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0 || clip.getItemAt(0).coerceToText(this) == null) {
            Toast.makeText(this, "Não encontrei um código de texto para colar.", Toast.LENGTH_SHORT).show();
            return;
        }
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        String value = text == null ? "" : text.toString();
        if (value.length() > 8192) {
            Toast.makeText(this, "O conteúdo é grande demais para um QR Code.", Toast.LENGTH_LONG).show();
            return;
        }
        payloadInput.setText(value);
        status.setText("Código colado. Toque em Conferir QR Code.");
    }

    private void validatePayload() {
        String raw = payloadInput.getText().toString().trim();
        reviewCard.removeAllViews();
        reviewCard.setVisibility(View.GONE);
        if (raw.isEmpty() || raw.length() > 8192) {
            status.setText("Cole o conteúdo de um QR Code válido.");
            return;
        }
        try {
            JSONObject data = new JSONObject(raw);
            account = first(data, "account", "recipient_account", "conta");
            recipient = first(data, "recipient_name", "name", "nome");
            institution = first(data, "institution", "institution_name", "instituicao");
            description = first(data, "desc", "description", "descricao");
            String rawAmount = first(data, "amount", "valor");
            amount = new BigDecimal(rawAmount.replace(',', '.')).setScale(2, RoundingMode.UNNECESSARY);
        } catch (Exception error) {
            account = ""; recipient = ""; institution = ""; description = ""; amount = BigDecimal.ZERO;
            status.setText("Código não reconhecido. Cole o texto JSON do QR gerado pelo aplicativo.");
            return;
        }
        if (!account.matches("\\d{6}") || amount.signum() <= 0) {
            status.setText("O QR precisa conter uma conta de 6 dígitos e um valor positivo.");
            return;
        }
        if (recipient.isEmpty()) recipient = "Titular informado no QR";
        if (institution.isEmpty()) institution = "Instituição não identificada";
        if (description.isEmpty()) description = "Sem descrição";
        addDetail("Instituição", institution);
        addDetail("Titular", recipient);
        addDetail("Conta", account);
        addDetail("Descrição", description);
        addDetail("Valor", NumberFormatPt.format(amount));
        reviewCard.setVisibility(View.VISIBLE);
        status.setText("Dados identificados. Confira antes de continuar.");
    }

    private String first(JSONObject data, String... keys) {
        for (String key : keys) {
            Object value = data.opt(key);
            if (value != null && value != JSONObject.NULL) {
                String text = String.valueOf(value).trim();
                if (!text.isEmpty()) return text;
            }
        }
        return "";
    }

    private void addDetail(String label, String value) {
        TextView row = Ui.text(this, label + "\n" + value, 14, Palette.NAVY, true);
        row.setPadding(0, Ui.d(this, 5), 0, Ui.d(this, 5));
        reviewCard.addView(row);
    }

    private static final class NumberFormatPt {
        static String format(BigDecimal value) {
            return java.text.NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(value);
        }
    }
}
