package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class CartaoActivity extends Activity {
    private MeuNovaCardView cardView;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = Ui.column(this);
        root.addView(Ui.text(this, "MEU NOVA BANK", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Meu Nova Card", 27, Palette.NAVY, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = Ui.d(this, 17);
        root.addView(title, titleParams);
        TextView subtitle = Ui.text(this, "Cartão de crédito virtual", 14, Palette.MUTED, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = Ui.d(this, 4);
        subtitleParams.bottomMargin = Ui.d(this, 18);
        root.addView(subtitle, subtitleParams);

        cardView = new MeuNovaCardView(this);
        cardView.setCardholderName("TITULAR DO CARTÃO");
        root.addView(cardView, new LinearLayout.LayoutParams(-1, Ui.d(this, 218)));

        TextView label = Ui.text(this, "MEU NOVA CARD · CARTÃO VIRTUAL", 10, Palette.GREEN, true);
        label.setLetterSpacing(.08f);
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(-1, -2);
        labelParams.topMargin = Ui.d(this, 17);
        root.addView(label, labelParams);
        Ui.card(this, root, "Dados protegidos", "O número do cartão fica mascarado nesta prévia.", null);
        Ui.card(this, root, "Layout demonstrativo", "O cartão é uma representação visual; não realiza pagamentos nem movimenta dinheiro.", null);

        Button back = Ui.button(this, "Voltar ao início", Palette.NAVY);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        backParams.topMargin = Ui.d(this, 8);
        root.addView(back, backParams);
        back.setOnClickListener(v -> finish());
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override protected void onResume() { super.onResume(); if (cardView != null) loadCardholderName(); }

    private void loadCardholderName() {
        String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) return;
        SupabaseProfileClient.fetchDisplayName(token, account, name -> runOnUiThread(() -> {
            if (isFinishing() || cardView == null || !account.equals(SessionStore.accountNumber())) return;
            cardView.setCardholderName(name == null || name.trim().isEmpty() ? "TITULAR DO CARTÃO" : name.trim());
        }));
    }
}
