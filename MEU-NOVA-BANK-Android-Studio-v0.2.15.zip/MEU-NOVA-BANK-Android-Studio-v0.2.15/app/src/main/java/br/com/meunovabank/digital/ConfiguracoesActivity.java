package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Local display preferences for the customer's device. */
public final class ConfiguracoesActivity extends Activity {
    private static final String PREFS="meunova_user_settings",HIDE_BALANCE="hide_balance";
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Configurações","Preferências locais deste aparelho");
        SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        CheckBox hide=new CheckBox(this);hide.setText("Ocultar saldos na tela inicial");hide.setTextColor(Palette.TEXT);hide.setTextSize(15);hide.setChecked(prefs.getBoolean(HIDE_BALANCE,false));root.addView(hide,new LinearLayout.LayoutParams(-1,Ui.d(this,54)));
        TextView info=Ui.text(this,"A preferência é salva somente neste aparelho. Você também pode alternar a exibição diretamente na tela inicial.",12,Palette.MUTED,false);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=Ui.d(this,5);root.addView(info,ip);
        Ui.card(this,root,"Aparência da conta","Categoria visual atual: "+tierLabel(Palette.currentTier())+". Ela é definida pelo administrador.",null);
        Ui.card(this,root,"Notificações","As notificações serão configuráveis quando o serviço estiver conectado.",null);
        hide.setOnCheckedChangeListener((button,checked)->prefs.edit().putBoolean(HIDE_BALANCE,checked).apply());setContentView(root);}
    private String tierLabel(String tier){switch(tier){case"gold":return"Ouro";case"select":return"Select";case"platinum":return"Platinum";case"black":return"Black";default:return"Basic";}}
}
