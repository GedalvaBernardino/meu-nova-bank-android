package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;

public final class ConfiguracoesActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.moduleScreen(this, "Configurações", "Preferências do aplicativo");
    }
}
