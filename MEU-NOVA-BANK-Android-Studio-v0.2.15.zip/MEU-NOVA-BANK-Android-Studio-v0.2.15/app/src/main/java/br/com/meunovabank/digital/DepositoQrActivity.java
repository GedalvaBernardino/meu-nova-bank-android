package br.com.meunovabank.digital;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import org.json.JSONException;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

/** QR demonstrativo para identificar conta e valor; não movimenta dinheiro. */
public class DepositoQrActivity extends Activity {
    private static final String INSTITUTION_NAME = "MEU NOVA BANK BR DIGITAL";
    private EditText accountField;
    private EditText amountField;
    private LinearLayout resultPanel;
    private TextView recipientNameView;
    private TextView institutionResult;
    private TextView recipientResult;
    private TextView accountResult;
    private TextView amountResult;
    private ImageView qrImage;
    private Button generateButton;
    private String recipientName = "";
    private String generatedPayload = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = Ui.column(this);
        root.setPadding(Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 20), Ui.d(this, 28));
        scroll.addView(root);
        setContentView(scroll);

        root.addView(Ui.text(this, "MEU NOVA BANK BR DIGITAL", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Cobrar / receber por QR", 25, Palette.NAVY, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = Ui.d(this, 18);
        root.addView(title, tp);
        TextView subtitle = Ui.text(this, "Gere um QR com sua conta e o valor para outra pessoa conferir a cobrança.", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = Ui.d(this, 5);
        root.addView(subtitle, sp);

        TextView accountLabel = Ui.text(this, "Sua conta", 13, Palette.NAVY, true);
        LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2);
        alp.topMargin = Ui.d(this, 20);
        root.addView(accountLabel, alp);
        accountField = field("Conta da sessão · 6 dígitos", InputType.TYPE_CLASS_NUMBER, 6);
        root.addView(accountField, fieldParams());
        String signedInAccount = SessionStore.accountNumber();
        boolean hasAccount = signedInAccount != null && signedInAccount.matches("[0-9]{6}");
        if (hasAccount) accountField.setText(signedInAccount);
        accountField.setEnabled(false);
        accountField.setFocusable(false);
        accountField.setClickable(false);

        LinearLayout recipientCard = new LinearLayout(this);
        recipientCard.setOrientation(LinearLayout.VERTICAL);
        recipientCard.setPadding(Ui.d(this, 14), Ui.d(this, 11), Ui.d(this, 14), Ui.d(this, 11));
        recipientCard.setBackground(Ui.bg(Color.rgb(239, 250, 246), Ui.d(this, 16)));
        LinearLayout.LayoutParams recipientCardParams = new LinearLayout.LayoutParams(-1, -2);
        recipientCardParams.topMargin = Ui.d(this, 12);
        root.addView(recipientCard, recipientCardParams);
        recipientCard.addView(Ui.text(this, "INSTITUIÇÃO RECEBEDORA", 10, Palette.MUTED, true));
        TextView institutionName = Ui.text(this, INSTITUTION_NAME, 14, Palette.NAVY, true);
        LinearLayout.LayoutParams institutionParams = new LinearLayout.LayoutParams(-1, -2);
        institutionParams.topMargin = Ui.d(this, 3);
        recipientCard.addView(institutionName, institutionParams);
        recipientNameView = Ui.text(this, hasAccount ? "Titular: consultando cadastro…" : "Titular: entre novamente para carregar sua conta", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams recipientNameParams = new LinearLayout.LayoutParams(-1, -2);
        recipientNameParams.topMargin = Ui.d(this, 5);
        recipientCard.addView(recipientNameView, recipientNameParams);

        TextView amountLabel = Ui.text(this, "Valor da cobrança", 13, Palette.NAVY, true);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(-1, -2);
        mlp.topMargin = Ui.d(this, 14);
        root.addView(amountLabel, mlp);
        amountField = field("Ex.: 25,90", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL, 12);
        root.addView(amountField, fieldParams());

        generateButton = Ui.button(this, "Gerar QR Code", Palette.GREEN);
        generateButton.setEnabled(false);
        if (!hasAccount) accountField.setHint("Entre novamente para carregar sua conta");
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        gp.topMargin = Ui.d(this, 17);
        root.addView(generateButton, gp);
        generateButton.setOnClickListener(v -> generateQr());

        resultPanel = new LinearLayout(this);
        resultPanel.setOrientation(LinearLayout.VERTICAL);
        resultPanel.setGravity(Gravity.CENTER_HORIZONTAL);
        resultPanel.setPadding(Ui.d(this, 17), Ui.d(this, 17), Ui.d(this, 17), Ui.d(this, 18));
        resultPanel.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 22)));
        resultPanel.setElevation(Ui.d(this, 2));
        resultPanel.setVisibility(View.GONE);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = Ui.d(this, 17);
        root.addView(resultPanel, rp);

        TextView resultTitle = Ui.text(this, "QR para cobrança", 18, Palette.NAVY, true);
        resultPanel.addView(resultTitle);
        institutionResult = Ui.text(this, "", 12, Palette.MUTED, false);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = Ui.d(this, 7);
        institutionResult.setGravity(Gravity.CENTER);
        resultPanel.addView(institutionResult, ip);
        recipientResult = Ui.text(this, "", 14, Palette.NAVY, true);
        LinearLayout.LayoutParams nrp = new LinearLayout.LayoutParams(-1, -2);
        nrp.topMargin = Ui.d(this, 3);
        recipientResult.setGravity(Gravity.CENTER);
        resultPanel.addView(recipientResult, nrp);
        accountResult = Ui.text(this, "", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams ar = new LinearLayout.LayoutParams(-1, -2);
        ar.topMargin = Ui.d(this, 5);
        accountResult.setGravity(Gravity.CENTER);
        resultPanel.addView(accountResult, ar);
        amountResult = Ui.text(this, "", 22, Palette.GREEN, true);
        LinearLayout.LayoutParams mr = new LinearLayout.LayoutParams(-1, -2);
        mr.topMargin = Ui.d(this, 3);
        amountResult.setGravity(Gravity.CENTER);
        resultPanel.addView(amountResult, mr);
        qrImage = new ImageView(this);
        qrImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrImage.setContentDescription("QR Code para cobrança com conta e valor");
        qrImage.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 12)));
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(Ui.d(this, 250), Ui.d(this, 250));
        qp.topMargin = Ui.d(this, 12);
        resultPanel.addView(qrImage, qp);
        TextView scanHint = Ui.text(this, "A outra pessoa pode escanear ou colar este código", 12, Palette.MUTED, false);
        scanHint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams shp = new LinearLayout.LayoutParams(-1, -2);
        shp.topMargin = Ui.d(this, 7);
        resultPanel.addView(scanHint, shp);
        Button copyCode = Ui.button(this, "Copiar código do QR", Palette.NAVY);
        LinearLayout.LayoutParams copyParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 48));
        copyParams.topMargin = Ui.d(this, 10);
        resultPanel.addView(copyCode, copyParams);
        copyCode.setOnClickListener(v -> copyQrPayload());

        TextView notice = Ui.text(this,
                "QR demonstrativo: identifica a conta e o valor. O crédito só pode ocorrer pelo fluxo da instituição de origem, após aprovações e confirmação do débito. Ler ou gerar o QR, por si só, não movimenta saldo.",
                12, Color.rgb(112, 88, 29), false);
        notice.setPadding(Ui.d(this, 13), Ui.d(this, 11), Ui.d(this, 13), Ui.d(this, 11));
        notice.setBackground(Ui.bg(Color.rgb(255, 247, 225), Ui.d(this, 14)));
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = Ui.d(this, 16);
        root.addView(notice, np);

        Button back = Ui.button(this, "Voltar ao início", Palette.NAVY);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        bp.topMargin = Ui.d(this, 15);
        root.addView(back, bp);
        back.setOnClickListener(v -> finish());
        if (hasAccount) loadRecipientName(signedInAccount);
    }

    private void loadRecipientName(String account) {
        recipientNameView.setText("Titular: consultando cadastro…");
        generateButton.setEnabled(false);
        SupabaseProfileClient.fetchDisplayName(SessionStore.accessToken(), account, name -> runOnUiThread(() -> {
            if (isFinishing()) return;
            if (name == null || name.trim().isEmpty()) {
                recipientName = "";
                recipientNameView.setText("Não foi possível carregar o titular. Confira a conexão e tente novamente.");
                generateButton.setEnabled(false);
                return;
            }
            recipientName = name.trim();
            recipientNameView.setText("Titular: " + recipientName);
            generateButton.setEnabled(true);
        }));
    }

    private EditText field(String hint, int inputType, int maxLength) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setTextSize(16);
        edit.setTextColor(Palette.TEXT);
        edit.setHintTextColor(Palette.MUTED);
        edit.setHint(hint);
        edit.setInputType(inputType);
        edit.setPadding(Ui.d(this, 14), Ui.d(this, 4), Ui.d(this, 14), Ui.d(this, 4));
        edit.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 14)));
        edit.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLength)});
        return edit;
    }

    private LinearLayout.LayoutParams fieldParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, Ui.d(this, 54));
        p.topMargin = Ui.d(this, 7);
        return p;
    }

    private void generateQr() {
        String account = accountField.getText().toString().trim();
        String rawAmount = amountField.getText().toString().trim();
        if (!account.matches("[0-9]{6}")) {
            accountField.setError("Conta da sessão inválida. Entre novamente.");
            accountField.requestFocus();
            return;
        }
        if (recipientName.isEmpty()) {
            Toast.makeText(this, "Aguarde o carregamento do nome do titular.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!rawAmount.matches("[0-9]{1,9}([.,][0-9]{1,2})?")) {
            amountField.setError("Digite um valor positivo com até 2 casas decimais");
            amountField.requestFocus();
            return;
        }

        final BigDecimal amount;
        try {
            amount = new BigDecimal(rawAmount.replace(',', '.')).setScale(2, RoundingMode.UNNECESSARY);
        } catch (Exception e) {
            amountField.setError("Valor inválido");
            amountField.requestFocus();
            return;
        }
        if (amount.signum() <= 0) {
            amountField.setError("O valor deve ser maior que zero");
            amountField.requestFocus();
            return;
        }

        try {
            JSONObject data = new JSONObject();
            data.put("type", "meunovabank_deposito_demo");
            data.put("version", 1);
            data.put("institution", INSTITUTION_NAME);
            data.put("recipient_name", recipientName);
            data.put("account", account);
            data.put("amount", amount.toPlainString());
            data.put("currency", "BRL");
            generatedPayload = data.toString();

            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
            hints.put(EncodeHintType.MARGIN, 2);
            com.google.zxing.common.BitMatrix matrix = new QRCodeWriter().encode(
                    generatedPayload, BarcodeFormat.QR_CODE, 640, 640, hints);
            Bitmap bitmap = Bitmap.createBitmap(matrix.getWidth(), matrix.getHeight(), Bitmap.Config.ARGB_8888);
            for (int y = 0; y < matrix.getHeight(); y++) {
                for (int x = 0; x < matrix.getWidth(); x++) {
                    bitmap.setPixel(x, y, matrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            qrImage.setImageBitmap(bitmap);
            institutionResult.setText("Instituição: " + INSTITUTION_NAME);
            recipientResult.setText("Recebedor: " + recipientName);
            accountResult.setText("Conta de destino: " + account);
            NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
            amountResult.setText(currency.format(amount));
            resultPanel.setVisibility(View.VISIBLE);
            resultPanel.requestFocus();
        } catch (WriterException | JSONException e) {
            generatedPayload = "";
            Toast.makeText(this, "Não foi possível gerar o QR Code. Tente novamente.", Toast.LENGTH_LONG).show();
        }
    }

    private void copyQrPayload() {
        if (generatedPayload == null || generatedPayload.isEmpty()) {
            Toast.makeText(this, "Gere o QR Code antes de copiar o conteúdo.", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard == null) {
            Toast.makeText(this, "Não foi possível acessar a área de transferência.", Toast.LENGTH_SHORT).show();
            return;
        }
        clipboard.setPrimaryClip(ClipData.newPlainText("MEU NOVA BANK QR", generatedPayload));
        Toast.makeText(this, "Código do QR copiado.", Toast.LENGTH_SHORT).show();
    }
}
