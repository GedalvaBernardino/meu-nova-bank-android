package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;

/** Compatibilidade: cobrar e receber por QR usa a mesma tela de geração do QR. */
public final class CobrarQrActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.open(this, DepositoQrActivity.class);
        finish();
    }
}
