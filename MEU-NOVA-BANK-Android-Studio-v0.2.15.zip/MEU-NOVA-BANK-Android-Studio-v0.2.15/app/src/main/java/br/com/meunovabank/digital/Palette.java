package br.com.meunovabank.digital;

import android.graphics.Color;

public final class Palette {
    public static final int NAVY = Color.rgb(16, 43, 80);
    public static final int NAVY_DARK = Color.rgb(11, 31, 59);
    public static final int RED = Color.rgb(203, 38, 58);
    public static final int GREEN = Color.rgb(24, 137, 91);
    public static final int MINT = Color.rgb(229, 246, 237);
    public static final int PALE_BLUE = Color.rgb(232, 241, 252);
    public static final int WHITE = Color.WHITE;
    public static final int BG = Color.rgb(244, 247, 251);
    public static final int TEXT = Color.rgb(27, 43, 64);
    public static final int MUTED = Color.rgb(105, 121, 142);
    public static final int BORDER = Color.rgb(224, 232, 241);
    private Palette() { }
}
