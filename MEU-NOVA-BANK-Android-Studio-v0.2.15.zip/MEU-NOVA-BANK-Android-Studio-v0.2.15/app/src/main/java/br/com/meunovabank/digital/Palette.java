package br.com.meunovabank.digital;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;

/** Shared colors for the app; visual tier is assigned server-side and cached only for display. */
public final class Palette {
    private static final String PREFS = "meunova_visual_theme";
    private static final String TIER_KEY = "theme_tier";
    private static volatile String tier = "basic";

    public static volatile int NAVY = Color.rgb(16, 43, 80);
    public static volatile int NAVY_DARK = Color.rgb(11, 31, 59);
    public static final int RED = Color.rgb(203, 38, 58);
    public static volatile int GREEN = Color.rgb(24, 137, 91);
    public static final int MINT = Color.rgb(229, 246, 237);
    public static volatile int PALE_BLUE = Color.rgb(232, 241, 252);
    public static final int WHITE = Color.WHITE;
    public static final int BG = Color.rgb(244, 247, 251);
    public static final int TEXT = Color.rgb(27, 43, 64);
    public static final int MUTED = Color.rgb(105, 121, 142);
    public static final int BORDER = Color.rgb(224, 232, 241);
    private Palette() { }

    public static String normalizeTier(String value) {
        if ("gold".equalsIgnoreCase(value) || "ouro".equalsIgnoreCase(value)) return "gold";
        if ("select".equalsIgnoreCase(value)) return "select";
        if ("platinum".equalsIgnoreCase(value)) return "platinum";
        if ("black".equalsIgnoreCase(value)) return "black";
        return "basic";
    }

    public static String currentTier() { return tier; }

    public static void loadSaved(Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        applyTier(prefs.getString(TIER_KEY, "basic"));
    }

    /** Call only with a value returned by the RLS-authorized profile fetch. */
    public static boolean applyTheme(Context context, String value) {
        String next = normalizeTier(value);
        boolean changed = !next.equals(tier);
        applyTier(next);
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(TIER_KEY, next).apply();
        return changed;
    }

    private static void applyTier(String value) {
        tier = normalizeTier(value);
        switch (tier) {
            case "gold":
                NAVY = Color.rgb(173, 123, 24); NAVY_DARK = Color.rgb(117, 78, 10); GREEN = NAVY; PALE_BLUE = Color.rgb(250, 241, 215); break;
            case "select":
                NAVY = Color.rgb(91, 101, 113); NAVY_DARK = Color.rgb(57, 64, 73); GREEN = NAVY; PALE_BLUE = Color.rgb(235, 238, 242); break;
            case "platinum":
                NAVY = Color.rgb(216, 105, 24); NAVY_DARK = Color.rgb(155, 67, 10); GREEN = NAVY; PALE_BLUE = Color.rgb(255, 238, 222); break;
            case "black":
                NAVY = Color.rgb(28, 28, 30); NAVY_DARK = Color.rgb(8, 8, 9); GREEN = NAVY; PALE_BLUE = Color.rgb(232, 232, 234); break;
            default:
                NAVY = Color.rgb(16, 43, 80); NAVY_DARK = Color.rgb(11, 31, 59); GREEN = Color.rgb(24, 137, 91); PALE_BLUE = Color.rgb(232, 241, 252); break;
        }
    }
}
