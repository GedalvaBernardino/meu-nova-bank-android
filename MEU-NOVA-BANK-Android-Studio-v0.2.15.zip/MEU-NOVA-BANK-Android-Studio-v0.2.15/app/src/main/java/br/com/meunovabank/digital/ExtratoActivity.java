package br.com.meunovabank.digital;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** Extrato autenticado, alimentado pelo ledger server-side do MEU NOVA BANK. */
public final class ExtratoActivity extends Activity {
    private LinearLayout entries;
    private TextView status;
    private Button refresh;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout page = Ui.column(this);
        page.addView(Ui.text(this, "MEU NOVA BANK BR DIGITAL", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Extrato", 26, Palette.NAVY, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = Ui.d(this, 14);
        page.addView(title, titleParams);
        page.addView(Ui.text(this, "Entradas e saídas confirmadas no ledger da sua conta.", 13, Palette.MUTED, false));
        page.addView(Ui.text(this, "Recebimentos interbancários aparecem como entrada somente depois da aprovação do MEU NOVA e da confirmação do débito na origem. Este extrato é demonstrativo e não comprova liquidação externa.", 12, Palette.MUTED, false));
        status = Ui.text(this, "Consultando extrato…", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = Ui.d(this, 8);
        page.addView(status, statusParams);
        entries = Ui.column(this);
        LinearLayout.LayoutParams entriesParams = new LinearLayout.LayoutParams(-1, -2);
        entriesParams.topMargin = Ui.d(this, 8);
        page.addView(entries, entriesParams);
        refresh = Ui.button(this, "Atualizar extrato", Palette.NAVY);
        page.addView(refresh, new LinearLayout.LayoutParams(-1, Ui.d(this, 50)));
        refresh.setOnClickListener(v -> load());
        Button back = Ui.button(this, "Voltar ao início", Palette.GREEN);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 50));
        backParams.topMargin = Ui.d(this, 8);
        page.addView(back, backParams);
        back.setOnClickListener(v -> finish());
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        if (refresh != null) load();
    }

    private void load() {
        status.setText("Consultando lançamentos…");
        entries.removeAllViews();
        refresh.setEnabled(false);
        new Thread(() -> {
            JSONArray rows = null;
            String failure = "Não foi possível consultar o extrato. Tente atualizar.";
            try {
                String token = SessionStore.accessToken();
                String account = SessionStore.accountNumber();
                if (token.isEmpty() || !account.matches("[0-9]{6}")) throw new Exception("session");
                JSONArray profiles = InterbankRest.get("customer_profiles?select=user_id&account_number=eq." + account + "&limit=1", token);
                String userId = profiles.length() == 0 ? "" : profiles.optJSONObject(0).optString("user_id", "");
                if (userId.isEmpty()) throw new Exception("profile");
                String encodedUser = URLEncoder.encode(userId, StandardCharsets.UTF_8.name());
                rows = InterbankRest.get("ledger_entries?select=id,operation_id,entry_type,amount,description,entry_status,created_at&user_id=eq." + encodedUser + "&order=created_at.desc&limit=200", token);
            } catch (Exception ignored) { }
            final JSONArray result = rows;
            runOnUiThread(() -> {
                refresh.setEnabled(true);
                render(result);
            });
        }, "meunova-statement").start();
    }

    private void render(JSONArray rows) {
        entries.removeAllViews();
        if (rows == null) {
            status.setText("Não foi possível carregar o extrato. Confira a conexão e atualize.");
            return;
        }
        status.setText(rows.length() == 0 ? "Nenhum lançamento registrado." : "Extrato recente · " + rows.length() + " lançamento(s)");
        if (rows.length() == 0) return;
        for (int i = 0; i < rows.length(); i++) {
            JSONObject row = rows.optJSONObject(i);
            if (row == null) continue;
            String type = row.optString("entry_type", "").toLowerCase(Locale.ROOT);
            String state = row.optString("entry_status", "posted").toLowerCase(Locale.ROOT);
            String description = row.optString("description", "Movimentação");
            String amount = row.optString("amount", "0");
            String date = formatDate(row.optString("created_at", ""));
            int amountColor = "pending".equals(state) ? Color.rgb(177, 112, 16) : "reversed".equals(state) ? Palette.MUTED : "credit".equals(type) ? Palette.GREEN : "debit".equals(type) ? Palette.RED : Palette.NAVY;
            String signedAmount = ("pending".equals(state) ? "… " : "reversed".equals(state) ? "× " : "credit".equals(type) ? "+ " : "debit".equals(type) ? "− " : "") + formatMoney(amount);

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(Ui.d(this, 15), Ui.d(this, 12), Ui.d(this, 15), Ui.d(this, 12));
            card.setBackground(Ui.bg(Color.WHITE, Ui.d(this, 16)));
            card.setElevation(Ui.d(this, 1));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
            cardParams.bottomMargin = Ui.d(this, 9);
            entries.addView(card, cardParams);

            TextView title = Ui.text(this, description, 15, Palette.NAVY, true);
            title.setTextIsSelectable(true);
            card.addView(title, new LinearLayout.LayoutParams(-1, -2));
            TextView value = Ui.text(this, signedAmount, 19, amountColor, true);
            LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(-1, -2);
            valueParams.topMargin = Ui.d(this, 4);
            card.addView(value, valueParams);
            TextView metadata = Ui.text(this, date + "  ·  " + statusLabel(state) + operationSuffix(row), 11, "posted".equals(state) ? Palette.MUTED : Color.rgb(177, 112, 16), false);
            LinearLayout.LayoutParams metaParams = new LinearLayout.LayoutParams(-1, -2);
            metaParams.topMargin = Ui.d(this, 3);
            card.addView(metadata, metaParams);
        }
    }

    private String operationSuffix(JSONObject row) {
        String id = row.optString("operation_id", "");
        return id.isEmpty() ? "" : "\nID da operação: " + id;
    }

    private String statusLabel(String state) {
        if ("posted".equals(state)) return "Confirmado";
        if ("pending".equals(state)) return "Aguardando confirmação do débito na origem";
        if ("reversed".equals(state)) return "Recusado/cancelado · sem crédito";
        return "Status: " + state;
    }

    private String formatMoney(String raw) {
        try {
            BigDecimal value = new BigDecimal(raw).abs();
            DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("pt", "BR"));
            return new DecimalFormat("R$ #,##0.00", symbols).format(value);
        } catch (Exception ignored) { return "R$ 0,00"; }
    }

    private String formatDate(String raw) {
        if (raw == null || raw.isEmpty()) return "Data indisponível";
        String[] patterns = {"yyyy-MM-dd'T'HH:mm:ss.SSSX", "yyyy-MM-dd'T'HH:mm:ssX", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String pattern : patterns) {
            try {
                SimpleDateFormat parser = new SimpleDateFormat(pattern, Locale.US);
                parser.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date date = parser.parse(raw);
                if (date != null) return new SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", new Locale("pt", "BR")).format(date);
            } catch (Exception ignored) { }
        }
        return raw.replace('T', ' ').replace("Z", "");
    }
}
