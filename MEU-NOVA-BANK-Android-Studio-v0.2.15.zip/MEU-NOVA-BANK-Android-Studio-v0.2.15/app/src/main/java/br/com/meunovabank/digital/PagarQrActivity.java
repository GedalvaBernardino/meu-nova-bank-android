package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class PagarQrActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = Ui.column(this);
        setContentView(root);
        root.addView(Ui.text(this, "MEU NOVA BANK BR DIGITAL", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Pagar QR", 26, Palette.NAVY, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = Ui.d(this, 18);
        root.addView(title, titleParams);
        TextView subtitle = Ui.text(this, "Cole um código QR para conferir os dados da cobrança.", 14, Palette.MUTED, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = Ui.d(this, 5);
        root.addView(subtitle, subtitleParams);
        Ui.card(this, root, "Colar código QR", "Colar da área de transferência e conferir conta, titular e valor.",
                () -> Ui.open(this, QrPastePaymentActivity.class));
        Ui.card(this, root, "Protótipo", "Esta prévia não envia pagamentos nem movimenta ou credita dinheiro.", null);
        Button back = Ui.button(this, "Voltar ao início", Palette.NAVY);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        backParams.topMargin = Ui.d(this, 14);
        root.addView(back, backParams);
        back.setOnClickListener(v -> finish());
    }
}
