package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;

public final class PixActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Ui.moduleScreen(this, "Pix", "Enviar e receber Pix");
    }
}
