package br.com.meunovabank.digital;

import android.app.Activity;
import android.os.Bundle;
import android.widget.LinearLayout;

/** Dedicated Pix hub with separate navigation for send, receive and incoming history. */
public final class PixActivity extends Activity {
    @Override public void onCreate(Bundle state){super.onCreate(state);LinearLayout root=Ui.column(this);Ui.section(this,root,"Pix","Enviar, receber e acompanhar solicitações");
        Ui.card(this,root,"Enviar Pix","Informe os dados do destinatário para revisar uma transferência demonstrativa",()->Ui.open(this,TransferenciaActivity.class));
        Ui.card(this,root,"Receber por QR Code","Gerar uma cobrança demonstrativa com conta e valor",()->Ui.open(this,DepositoQrActivity.class));
        Ui.card(this,root,"Recebimentos","Consultar solicitações recebidas nesta conta",()->Ui.open(this,IncomingTransfersActivity.class));
        Ui.card(this,root,"Importante","Este protótipo não envia Pix nem movimenta dinheiro real.",null);setContentView(root);}
}
