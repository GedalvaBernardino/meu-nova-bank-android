# Contrato necessário para recuperação de senha

O app oferece uma tela nativa em duas etapas. Para efetivar a troca, o backend Supabase precisa publicar a Edge Function `account-password-recovery` em `/functions/v1/account-password-recovery`. O endpoint ainda não está implantado neste projeto; sem ele, a tela falha de forma segura.

## Solicitar código

`POST` com JSON:

```json
{"action":"request_code","account_number":"123456"}
```

A resposta de sucesso esperada pelo app é HTTP 200 com `{"status":"code_requested"}`. Para não revelar se uma conta existe, use a mesma resposta genérica para contas existentes e inexistentes. Envie um código numérico de 6 dígitos apenas ao e-mail ou celular verificado já associado àquela conta.

## Validar código e atualizar senha

`POST` com JSON:

```json
{"action":"confirm_code","account_number":"123456","code":"123456","new_password":"12345678"}
```

Depois de validar o código, a resposta de sucesso esperada é HTTP 200 com `{"status":"password_updated"}`. Atualize a senha da conta usando a API administrativa do Supabase exclusivamente no servidor.

## Requisitos de segurança

- O número da conta identifica a conta, mas **não prova que a pessoa é titular**.
- Gere o código com fonte criptograficamente segura, armazene somente seu hash, faça-o expirar (por exemplo, em 10 minutos) e aceite-o uma única vez.
- Aplique limite de tentativas e de solicitações por conta e por IP; invalide códigos anteriores quando um novo for emitido.
- Nunca retorne o e-mail/celular completo, confirme a existência da conta ou aceite um contato fornecido durante a recuperação.
- Guarde `SUPABASE_SERVICE_ROLE_KEY` e as credenciais do provedor de e-mail/SMS como secrets da Edge Function. Nunca as inclua no APK, no repositório ou em variáveis públicas.
- A função deve mapear a conta ao usuário autenticado usando o esquema real do projeto. O código do backend e o esquema SQL original não foram fornecidos neste ZIP, portanto esse mapeamento precisa ser implementado e revisado no projeto Supabase antes de ativar a recuperação.
