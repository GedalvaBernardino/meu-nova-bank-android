# Recuperação segura de senha do Android

O aplicativo usa a Edge Function Supabase `account-password-recovery`, publicada em `/functions/v1/account-password-recovery`. O fluxo foi projetado para que o número da conta apenas selecione a conta; ele nunca prova a titularidade nem permite alterar a senha por si só.

## Solicitar link

O cliente envia somente o número da conta de exatamente seis dígitos:

```http
POST /functions/v1/account-password-recovery
Content-Type: application/json
apikey: <publishable key>
Authorization: Bearer <publishable key>

{"account_number":"123456"}
```

A função valida o formato, aplica limite de solicitações por conta e por IP usando a RPC `meunova_login_rate_limit`, e resolve a conta no servidor pela RPC existente `meunova_login_email`. Essa RPC deve retornar apenas o e-mail confirmado associado à conta elegível. O cliente não pode fornecer um e-mail alternativo.

Quando houver um e-mail elegível, a função chama a API Auth `/auth/v1/recover` com o redirecionamento `meunovabank://auth/callback`. Tanto para conta existente quanto inexistente, a resposta normal é HTTP 200 com:

```json
{"status":"recovery_requested"}
```

Assim a API não revela a existência da conta nem o endereço de e-mail. A função usa no servidor `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` e `LOGIN_RATE_LIMIT_SECRET`; nenhum segredo privilegiado deve ser colocado no APK ou repositório. `verify_jwt` fica desativado porque a solicitação acontece antes do login; formato, rate limit e o fluxo de propriedade por link do Auth são validados no servidor.

## Abrir link e trocar a senha

O link de recuperação enviado pelo Supabase deve redirecionar a `AuthCallbackActivity`, registrada para `meunovabank://auth/callback`. Após a validação do link pelo Supabase, o app lê o token de acesso de recuperação do callback. A pessoa informa e confirma uma senha numérica de exatamente 8 dígitos. O app atualiza a senha pela API Auth `/auth/v1/user` usando esse token de recuperação validado. Um token ausente, inválido, expirado ou já usado não autoriza a troca; deve-se solicitar outro link.

O app não salva a senha nem grava o token de recuperação como sessão persistente. A senha só muda depois de validar o link recebido no e-mail confirmado. A configuração de URL de redirecionamento do Supabase Auth precisa permitir `meunovabank://auth/callback`, e os templates/provedor SMTP de recuperação precisam estar configurados para entregar o link corretamente. O fluxo de entrega só estará operacional após verificar essas configurações com uma conta ativa de teste.

## Escopo atual

O banco e o alocador desta instalação aceitam exatamente 6 dígitos para números de conta. Contas de 7 dígitos não são suportadas por este projeto.
