# Recuperação de senha

O app usa a Edge Function Supabase `account-password-recovery`, implantada no projeto `MEU NOVA BANK BR DIGITAL`. Ela localiza a conta no servidor, aplica limite de tentativas e solicita à autenticação Supabase um link de recuperação enviado ao e-mail já confirmado. A resposta é genérica e não revela se a conta existe.

## Fluxo

1. O app envia `POST /functions/v1/account-password-recovery` com `{"account_number":"123456"}`.
2. A função procura o e-mail associado usando a RPC existente `meunova_login_email`; o e-mail nunca é devolvido ao app.
3. Se a conta estiver habilitada, Supabase envia o link de recuperação ao e-mail confirmado, com retorno para `meunovabank://auth/callback`.
4. O deep link abre o app. O app envia a nova senha à API Auth do Supabase usando o token temporário do link.

## Segurança

- O número da conta identifica o usuário, mas não é prova de titularidade. A redefinição exige acesso ao e-mail confirmado.
- A função usa somente credenciais do servidor e a RPC de limite `meunova_login_rate_limit`; não coloque service-role ou segredos no app.
- A função retorna a mesma resposta para contas existentes e inexistentes e não entrega e-mail ao cliente.
- O fluxo atual do projeto aceita conta de **6 dígitos**. A tabela e a RPC de login não aceitam conta de 7 dígitos.
- O link é de uso único, gerenciado pelo Supabase Auth; a tela solicita nova senha numérica de 8 dígitos e não persiste senha nem token.
