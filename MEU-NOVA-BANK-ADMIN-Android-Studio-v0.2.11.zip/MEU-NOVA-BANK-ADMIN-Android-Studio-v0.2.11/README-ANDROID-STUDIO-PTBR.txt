MEU NOVA BANK ADMIN — projeto Android Studio

Pacote: br.com.meunovabank.admin
Versão: 0.2.7-balance-account-fix (versionCode 9)
Compatibilidade: minSdk 21 (Android 5.0), targetSdk 37 (Android 17).

Abra a pasta raiz deste projeto no Android Studio. O projeto usa Android Gradle Plugin 8.9.1 e compileSdk 37; instale a plataforma Android API 37 quando solicitado.

O código-fonte inclui as Activities e recursos do aplicativo administrador. Os arquivos SQL e Edge Functions do backend Supabase não estão incluídos neste ZIP.

Por segurança, chaves privadas, senhas e arquivos de assinatura foram excluídos. É possível compilar uma versão de depuração no Android Studio. Para gerar uma release instalável por cima de outra release, configure sua própria chave de assinatura; ela não está neste arquivo.


Limites de crédito demonstrativos: no hub de funções do usuário, configure empréstimo pessoal (R$ 102–R$ 90.000) e Meu Nova Card (R$ 152–R$ 90.000); zero desativa. Mudanças passam pelo RPC administrativo e são auditadas. Nenhum crédito real é concedido.
