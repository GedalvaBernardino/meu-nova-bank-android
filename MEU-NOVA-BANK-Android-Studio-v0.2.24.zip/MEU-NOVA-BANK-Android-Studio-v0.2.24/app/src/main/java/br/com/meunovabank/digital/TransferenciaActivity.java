package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONObject;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.UUID;

/** Same-institution DEM movement inside the demonstrative ledger only. */
public final class TransferenciaActivity extends Activity {
    private EditText destination, amount;
    private TextView status, cardSummary;
    private BigDecimal overdraftLimit = BigDecimal.ZERO, overdraftUsed = BigDecimal.ZERO;
    private boolean overdraftActive = false;
    private Button review;
    private BigDecimal cardLimit = BigDecimal.ZERO, cardUsed = BigDecimal.ZERO;
    private boolean cardCreditLoaded = false;
    private String pendingRequestId = "", pendingFingerprint = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = Ui.column(this);
        Ui.section(this, root, "Transferência DEM", "Entre contas Meu Nova Bank · demonstração");
        Ui.card(this, root, "Conta de origem", "Conta demonstrativa " + SessionStore.accountNumber(), null);
        destination = Ui.input(this, "Conta de destino · 6 dígitos", InputType.TYPE_CLASS_NUMBER);
        destination.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(6)});
        root.addView(destination, new LinearLayout.LayoutParams(-1, Ui.d(this, 54)));
        amount = Ui.input(this, "Valor da transferência (R$)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        root.addView(amount, new LinearLayout.LayoutParams(-1, Ui.d(this, 54)));
        cardSummary = Ui.text(this, "Limite Meu Nova Card demonstrativo: consultando…", 13, Palette.NAVY, true);
        root.addView(cardSummary);
        review = Ui.button(this, "Revisar transferência", Palette.NAVY);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        bp.topMargin = Ui.d(this, 12); root.addView(review, bp);
        status = Ui.text(this, "Informe a conta DEM de destino e o valor.", 13, Palette.MUTED, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = Ui.d(this, 10); root.addView(status, sp);
        Ui.card(this, root, "Liquidação demonstrativa", "A confirmação debita o saldo demonstrativo de origem e credita a conta DEM de destino em operação atômica, com registro no extrato. Não alcança Pix, bancos ou redes reais. Cartão: taxa demonstrativa de 3,7% por operação. Cheque especial: limite utilizado é controlado separadamente, sem saldo negativo ou dívida real.", null);
        review.setOnClickListener(v -> reviewTransfer());
        setContentView(root);
        pendingFingerprint = getPreferences(MODE_PRIVATE).getString("dem_pending_fingerprint", "");
        pendingRequestId = getPreferences(MODE_PRIVATE).getString("dem_pending_request_id", "");
        loadCardCredit();
        loadOverdraft();
    }

    private void loadCardCredit() {
        String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) {
            cardSummary.setText("Limite do Meu Nova Card indisponível; transferência pelo cartão bloqueada."); return;
        }
        SupabaseProfileClient.fetchCreditLimits(token, account, (loan, card, used) -> runOnUiThread(() -> {
            try {
                if (card == null || used == null) throw new IllegalStateException("credit profile unavailable");
                showCardCredit(new BigDecimal(card), new BigDecimal(used));
            } catch (Exception e) {
                cardCreditLoaded = false;
                cardSummary.setText("Limite do Meu Nova Card indisponível; transferência pelo cartão bloqueada.");
            }
        }));
    }

    private void showCardCredit(BigDecimal limit, BigDecimal used) {
        cardLimit = limit; cardUsed = used; cardCreditLoaded = true;
        BigDecimal available = cardLimit.subtract(cardUsed).max(BigDecimal.ZERO);
        cardSummary.setText("Meu Nova Card demonstrativo · limite: " + money(cardLimit) + " · utilizado: " + money(cardUsed) + " · disponível: " + money(available) + ". Taxa por transferência: 3,7%.");
    }

    private void loadOverdraft() {
        String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) return;
        new Thread(() -> {
            try {
                org.json.JSONArray rows = InterbankRest.get("customer_profiles?select=overdraft_user_limit,overdraft_active,overdraft_used&account_number=eq." + account + "&limit=1", token);
                if (rows.length() == 0) return;
                JSONObject row = rows.optJSONObject(0);
                BigDecimal limit = new BigDecimal(row.optString("overdraft_user_limit", "0.00"));
                BigDecimal used = new BigDecimal(row.optString("overdraft_used", "0.00"));
                boolean active = row.optBoolean("overdraft_active", false);
                runOnUiThread(() -> { overdraftLimit = limit; overdraftUsed = used; overdraftActive = active; });
            } catch (Exception ignored) { runOnUiThread(() -> { overdraftLimit = BigDecimal.ZERO; overdraftUsed = BigDecimal.ZERO; overdraftActive = false; }); }
        }, "nova-user-overdraft-summary").start();
    }

    private void reviewTransfer() {
        String recipient = destination.getText().toString().trim();
        String raw = amount.getText().toString().trim().replace(',', '.');
        BigDecimal value;
        try { value = new BigDecimal(raw); } catch (Exception e) { value = BigDecimal.ZERO; }
        if (!recipient.matches("[0-9]{6}") || value.signum() <= 0 || value.scale() > 2) {
            status.setText("Informe uma conta com 6 dígitos e um valor positivo com até 2 casas decimais."); return;
        }
        if (recipient.equals(SessionStore.accountNumber())) { status.setText("A conta de destino precisa ser diferente da sua."); return; }
        BigDecimal base = value.setScale(2, RoundingMode.UNNECESSARY);
        BigDecimal fee = base.multiply(new BigDecimal("0.037")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal charge = base.add(fee);
        String details = "Conta DEM destino: " + recipient + "\nValor para destinatário: " + money(base)
                + "\n\nTaxa demonstrativa do cartão (3,7%): " + money(fee)
                + "\nTotal debitado do limite se usar cartão: " + money(charge)
                + "\nDisponível no cartão: " + money(cardLimit.subtract(cardUsed).max(BigDecimal.ZERO))
                + "\n\nCheque especial demonstrativo: " + (overdraftActive ? "ativo" : "inativo")
                + "\nUtilizado: " + money(overdraftUsed) + " · disponível: " + money(overdraftLimit.subtract(overdraftUsed).max(BigDecimal.ZERO))
                + "\n\nEscolha a origem do débito demonstrativo.";
        String[] sources = {"Saldo demonstrativo · debitar " + money(base),
                "Meu Nova Card demonstrativo · limite usado " + money(charge),
                "Cheque especial demonstrativo · limite usado " + money(base)};
        boolean cardAllowed = cardCreditLoaded && cardLimit.compareTo(BigDecimal.valueOf(152)) >= 0 && cardUsed.add(charge).compareTo(cardLimit) <= 0;
        boolean overdraftAllowed = overdraftActive && overdraftLimit.subtract(overdraftUsed).compareTo(base) >= 0;
        new AlertDialog.Builder(this).setTitle("Revisar transferência DEM").setMessage(details)
                .setItems(sources, (d, which) -> {
                    String source = which == 0 ? "balance" : which == 1 ? "card" : "overdraft";
                    boolean allowed = which == 0 || (which == 1 && cardAllowed) || (which == 2 && overdraftAllowed);
                    if (!allowed) {
                        status.setText(which == 1 ? "Limite do Meu Nova Card demonstrativo insuficiente ou indisponível." : "Cheque especial demonstrativo inativo ou sem limite disponível suficiente.");
                        return;
                    }
                    String sourceName = which == 0 ? "saldo demonstrativo" : which == 1 ? "Meu Nova Card demonstrativo" : "cheque especial demonstrativo";
                    String usage = which == 1 ? "Total demonstrativo usado: " + money(charge) + " (inclui taxa)." : "Utilização demonstrativa: " + money(base) + ".";
                    new AlertDialog.Builder(this).setTitle("Confirmar origem da transferência DEM")
                            .setMessage("Destino: conta " + recipient + "\\nValor creditado: " + money(base) + "\\nOrigem selecionada: " + sourceName + "\\n" + usage
                                    + "\\n\\nSomente ledger demonstrativo; nenhuma rede bancária real será acionada.")
                            .setNegativeButton("Voltar", null)
                            .setPositiveButton("Confirmar", (confirm, w) -> submitTransfer(recipient, base, source)).show();
                }).setNegativeButton("Cancelar", null).show();
    }

    private void submitTransfer(String recipient, BigDecimal value, String source) {
        String fingerprint = recipient + "|" + value.setScale(2, RoundingMode.UNNECESSARY).toPlainString() + "|" + source;
        if (!fingerprint.equals(pendingFingerprint) || pendingRequestId.isEmpty()) {
            pendingFingerprint = fingerprint; pendingRequestId = UUID.randomUUID().toString();
            getPreferences(MODE_PRIVATE).edit().putString("dem_pending_fingerprint", pendingFingerprint).putString("dem_pending_request_id", pendingRequestId).commit();
        }
        final String requestId = pendingRequestId;
        review.setEnabled(false); status.setText("Validando destinatário e limite demonstrativos…");
        new Thread(() -> {
            try {
                JSONObject req = new JSONObject();
                req.put("p_request_id", requestId);
                req.put("p_recipient_account", recipient);
                req.put("p_amount", value.setScale(2, RoundingMode.UNNECESSARY).toPlainString());
                req.put("p_funding_source", source);
                JSONObject result = InterbankRest.rpc(this, "meunova_execute_dem_transfer", SessionStore.accessToken(), req);
                if (!result.optBoolean("ok", false) || !"posted".equals(result.optString("status", ""))) throw new IllegalStateException("TRANSFER_NOT_CONFIRMED");
                String ref = result.optString("operation_id", "");
                if (ref.isEmpty()) throw new IllegalStateException("TRANSFER_NOT_CONFIRMED");
                String charged = result.optString("charged_amount", value.toPlainString());
                String fee = result.optString("fee_amount", "0.00");
                BigDecimal responseCardLimit = result.has("card_credit_limit") ? new BigDecimal(result.getString("card_credit_limit")) : null;
                BigDecimal responseCardUsed = result.has("card_credit_used") ? new BigDecimal(result.getString("card_credit_used")) : null;
                String message = "Transferência DEM concluída.\nDestino: conta " + recipient + "\nValor creditado: " + money(value)
                        + "\nTotal debitado: " + money(new BigDecimal(charged))
                        + (new BigDecimal(fee).signum() > 0 ? " (inclui taxa de " + money(new BigDecimal(fee)) + ")" : "")
                        + "\nOrigem: " + ("overdraft".equals(source) ? "cheque especial demonstrativo" : "card".equals(source) ? "Meu Nova Card demonstrativo" : "saldo demonstrativo")
                        + "\nReferência: " + ref;
                runOnUiThread(() -> {
                    clearPendingRequest(); status.setText(message);
                    if (responseCardLimit != null && responseCardUsed != null) showCardCredit(responseCardLimit, responseCardUsed);
                    else loadCardCredit();
                    new AlertDialog.Builder(this).setTitle("Transferência demonstrativa concluída")
                            .setMessage(message + "\n\nA operação consta no ledger DEM. Nenhuma rede bancária, Pix ou pagamento real foi acionado.")
                            .setPositiveButton("OK", null).show();
                    review.setEnabled(true); loadOverdraft();
                });
            } catch (Exception e) {
                String error = e.getMessage() == null ? "" : e.getMessage();
                String message = safeError(error);
                runOnUiThread(() -> { status.setText(message + " Se tentar novamente com os mesmos dados, a referência idempotente será reutilizada."); review.setEnabled(true); });
            }
        }, "meunova-dem-transfer").start();
    }

    private String safeError(String error) {
        switch (error) {
            case "RECIPIENT_INVALID": return "Não encontrei uma conta DEM ativa válida desta instituição. Confira os 6 dígitos.";
            case "RECIPIENT_IS_SELF": return "A conta de destino precisa ser diferente da sua.";
            case "BALANCE_INSUFFICIENT": return "Saldo demonstrativo insuficiente para esta transferência.";
            case "CARD_LIMIT_INSUFFICIENT": return "O valor mais a taxa de 3,7% supera o limite demonstrativo disponível.";
            case "OVERDRAFT_INACTIVE": return "Ative primeiro o cheque especial demonstrativo para usá-lo nesta transferência.";
            case "OVERDRAFT_LIMIT_INSUFFICIENT": return "O valor supera o limite restante do cheque especial demonstrativo.";
            case "CARD_LIMIT_BELOW_USAGE": return "O limite demonstrativo está abaixo do valor já utilizado; fale com o suporte.";
            case "AUTH_REQUIRED": case "SESSION_EXPIRED": return "Sua sessão expirou. Entre novamente e confira o extrato antes de tentar de novo.";
            case "NOT_AUTHORIZED": return "Esta conta não está autorizada a fazer a operação. Entre novamente ou fale com o suporte.";
            case "BACKEND_FUNCTION_MISSING": return "O serviço de transferência está em atualização. Tente novamente mais tarde.";
            case "SERVICE_UNAVAILABLE": return "O serviço está temporariamente indisponível. A operação pode ter sido processada; confira o extrato antes de repetir.";
            case "TRANSFER_NOT_CONFIRMED": return "O servidor não confirmou o resultado. Confira o extrato antes de repetir.";
            case "REQUEST_INVALID": return "Os dados da transferência foram rejeitados. Confira o valor e a conta de destino.";
            default: return "Não foi possível confirmar a transferência. Confira o extrato antes de repetir; a mesma referência será mantida para uma nova tentativa.";
        }
    }

    private void clearPendingRequest() {
        pendingFingerprint = ""; pendingRequestId = "";
        getPreferences(MODE_PRIVATE).edit().remove("dem_pending_fingerprint").remove("dem_pending_request_id").commit();
    }

    private String money(BigDecimal value) { return NumberFormat.getCurrencyInstance(new Locale("pt", "BR")).format(value); }
}
