package br.com.meunovabank.digital;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.SharedPreferences;
import java.util.UUID;
import org.json.JSONArray;
import org.json.JSONObject;

/** Meu Nova Card lifecycle screen. All displayed card identifiers are non-payment demo labels. */
public final class CartaoActivity extends Activity {
    private MeuNovaCardView cardView;
    private TextView creditLimit, status, details;
    private LinearLayout root, actions;
    private boolean active = false, stateLoaded = false, stateUnavailable = false, requestInFlight = false;
    private int generation = 0;
    private String expiry = "", blockReason = "";
    private double cardLimit = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = Ui.column(this);
        root.addView(Ui.text(this, "MEU NOVA BANK", 11, Palette.GREEN, true));
        TextView title = Ui.text(this, "Meu Nova Card", 27, Palette.NAVY, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = Ui.d(this, 17);
        root.addView(title, titleParams);
        TextView subtitle = Ui.text(this, "Cartão virtual demonstrativo", 14, Palette.MUTED, false);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(-1, -2);
        subtitleParams.topMargin = Ui.d(this, 4);
        subtitleParams.bottomMargin = Ui.d(this, 18);
        root.addView(subtitle, subtitleParams);

        cardView = new MeuNovaCardView(this);
        cardView.setCardholderName("TITULAR DO CARTÃO");
        cardView.setDemoCardState(false, 0, false);
        root.addView(cardView, new LinearLayout.LayoutParams(-1, Ui.d(this, 218)));

        status = Ui.text(this, "Consultando situação…", 15, Palette.NAVY, true);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = Ui.d(this, 14);
        root.addView(status, statusParams);
        creditLimit = Ui.text(this, "Limite demonstrativo: consultando…", 14, Palette.NAVY, true);
        LinearLayout.LayoutParams limitParams = new LinearLayout.LayoutParams(-1, -2);
        limitParams.topMargin = Ui.d(this, 8);
        root.addView(creditLimit, limitParams);
        details = Ui.text(this, "Nenhum cartão demonstrativo ativado.", 14, Palette.NAVY, false);
        LinearLayout.LayoutParams detailsParams = new LinearLayout.LayoutParams(-1, -2);
        detailsParams.topMargin = Ui.d(this, 12);
        root.addView(details, detailsParams);

        actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams actionsParams = new LinearLayout.LayoutParams(-1, -2);
        actionsParams.topMargin = Ui.d(this, 8);
        actionsParams.bottomMargin = Ui.d(this, 8);
        root.addView(actions, actionsParams);
        Ui.card(this, root, "Aviso importante", "O identificador é fictício e inválido para pagamentos. Este app não cria nem exibe PAN ou CVV de pagamento. Nenhuma compra é autorizada.", null);
        Ui.card(this, root, "Transferência DEM", "O limite do cartão só pode ser usado no ledger demonstrativo. A taxa informativa é de 3,7% por operação; nenhuma rede bancária real é acionada.", null);
        Button back = Ui.button(this, "Voltar ao início", Palette.NAVY);
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        backParams.topMargin = Ui.d(this, 8);
        root.addView(back, backParams);
        back.setOnClickListener(v -> finish());
        scroll.addView(root);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        if (cardView != null) {
            loadCardholderName();
            loadCreditLimit();
            loadState();
        }
    }

    private void renderActions() {
        if (actions == null) return;
        actions.removeAllViews();
        if (!stateLoaded || stateUnavailable || requestInFlight) {
            if (stateUnavailable && !requestInFlight) addButton("Tentar consultar novamente", Palette.NAVY, this::loadState);
            return;
        }
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        String pendingId = prefs.getString("card_pending_id", "");
        if (!pendingId.isEmpty()) {
            String pendingAction = prefs.getString("card_pending_action", "");
            String pendingReason = prefs.getString("card_pending_reason", "");
            addButton("Repetir confirmação pendente", Palette.NAVY, () -> callState(pendingAction, pendingReason.isEmpty() ? null : pendingReason));
            return;
        }
        if (active) {
            addButton("Bloquear cartão", Palette.NAVY, this::confirmBlock);
        } else if (generation == 0 && cardLimit >= 152) {
            addButton("Ativar cartão demonstrativo", Palette.GREEN, () -> new AlertDialog.Builder(this)
                .setTitle("Ativar cartão fictício?")
                .setMessage("Será ativado apenas um cartão demonstrativo, sem número de pagamento e sem CVV real. Quer continuar?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Ativar", (d, w) -> callState("issue", null)).show());
        } else if (generation == 0) {
            addButton("Ativação indisponível · limite mínimo R$ 152", Palette.NAVY, () -> {});
        } else if (cardLimit >= 152) {
            addButton("Gerar cartão substituto", Palette.GREEN, () -> new AlertDialog.Builder(this)
                .setTitle("Substituir cartão demonstrativo?")
                .setMessage("O cartão atual já está bloqueado. Um novo identificador fictício será criado, sem capacidade de pagamento.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Substituir", (d, w) -> callState("replace", null)).show());
        } else {
            addButton("Substituição indisponível · confira o limite", Palette.NAVY, () -> {});
        }
    }

    private void addButton(String label, int color, Runnable action) {
        Button button = Ui.button(this, label, color);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, Ui.d(this, 52));
        params.topMargin = Ui.d(this, 10);
        actions.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }

    private void confirmBlock() {
        final String[] reasons = {"Perda", "Furto", "Roubo"};
        new AlertDialog.Builder(this).setTitle("Selecione o motivo do bloqueio")
            .setItems(reasons, (dialog, which) -> new AlertDialog.Builder(this)
                .setTitle("Confirmar bloqueio?")
                .setMessage("O cartão demonstrativo será bloqueado no servidor e deixará de ser aceito na transferência DEM pelo cartão.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Bloquear", (d, w) -> callState("block", reasons[which].toLowerCase(java.util.Locale.ROOT)))
                .show())
            .setNegativeButton("Cancelar", null).show();
    }

    private void callState(String action, String reason) {
        if (!stateLoaded || stateUnavailable || requestInFlight) return;
        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        String requestId = prefs.getString("card_pending_id", "");
        String oldAction = prefs.getString("card_pending_action", "");
        String oldReason = prefs.getString("card_pending_reason", "");
        if (!requestId.isEmpty()) {
            if (!oldAction.equals(action) || !oldReason.equals(reason == null ? "" : reason)) {
                status.setText("Há uma solicitação anterior sem confirmação. Confirme-a antes de iniciar outra.");
                renderActions(); return;
            }
        } else {
            requestId = UUID.randomUUID().toString();
            prefs.edit().putString("card_pending_id", requestId)
                    .putString("card_pending_action", action)
                    .putString("card_pending_reason", reason == null ? "" : reason).commit();
        }
        final String requestIdToSend = requestId;
        requestInFlight = true;
        renderActions();
        status.setText("Atualizando situação no servidor…");
        new Thread(() -> {
            try {
                JSONObject request = new JSONObject();
                request.put("p_action", action);
                request.put("p_block_reason", reason == null ? JSONObject.NULL : reason);
                request.put("p_request_id", requestIdToSend);
                JSONObject response = InterbankRest.rpc(this, "meunova_set_demo_card_state", SessionStore.accessToken(), request);
                boolean expectedActive = !"block".equals(action);
                if (!response.optBoolean("ok", false) || response.optBoolean("demo_card_active", !expectedActive) != expectedActive
                        || response.optInt("demo_card_generation", -1) < 1)
                    throw new IllegalStateException("CARD_STATE_NOT_CONFIRMED");
                getPreferences(MODE_PRIVATE).edit().remove("card_pending_id").remove("card_pending_action").remove("card_pending_reason").commit();
                runOnUiThread(() -> {
                    requestInFlight = false;
                    status.setText("Resposta confirmada. Conferindo novamente o estado atual…");
                    loadState();
                });
            } catch (Exception error) {
                runOnUiThread(() -> {
                    requestInFlight = false;
                    status.setText(safeError(error));
                    loadState();
                });
            }
        }, "demo-card-state").start();
    }

    private String safeError(Exception error) {
        String code = error.getMessage() == null ? "" : error.getMessage();
        if (code.contains("BACKEND_FUNCTION_MISSING")) return "A função de cartão está sendo atualizada. Tente novamente mais tarde.";
        if (code.contains("AUTH_REQUIRED") || code.contains("SESSION_EXPIRED")) return "Sua sessão expirou. Entre novamente e confira a situação do cartão.";
        if (code.contains("REQUEST_INVALID")) return "A solicitação do cartão foi rejeitada. Confira a ação e tente novamente.";
        return "Não foi possível confirmar a mudança do cartão. Atualizei a situação antes de permitir outra ação.";
    }

    private void loadState() {
        String account = SessionStore.accountNumber();
        String token = SessionStore.accessToken();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) {
            stateLoaded = false;
            stateUnavailable = true;
            status.setText("Entre novamente para consultar o cartão da sua conta.");
            renderActions();
            return;
        }
        stateLoaded = false;
        stateUnavailable = false;
        status.setText("Consultando situação…");
        renderActions();
        new Thread(() -> {
            boolean isActive = false;
            int cardGeneration = 0;
            String expiration = "", reason = "";
            double limit = 0;
            boolean loaded = false;
            try {
                JSONArray rows;
                try { rows = readState(SessionStore.accessToken(), account); }
                catch (Exception first) {
                    if (!SupabaseAuthClient.refreshSessionBlocking(this)) throw first;
                    rows = readState(SessionStore.accessToken(), account);
                }
                if (rows.length() == 0) throw new Exception("profile_not_found");
                JSONObject row = rows.optJSONObject(0);
                if (row == null) throw new Exception("profile_not_found");
                isActive = row.optBoolean("demo_card_active", false);
                cardGeneration = row.optInt("demo_card_generation", 0);
                expiration = row.optString("demo_card_expires_on", "");
                reason = row.optString("demo_card_block_reason", "");
                limit = Double.parseDouble(row.optString("card_credit_limit", "0"));
                loaded = true;
            } catch (Exception ignored) { }
            boolean activeValue = isActive;
            int generationValue = cardGeneration;
            String expiryValue = expiration, reasonValue = reason;
            double limitValue = limit;
            boolean loadedValue = loaded;
            runOnUiThread(() -> {
                if (isFinishing() || !account.equals(SessionStore.accountNumber())) return;
                stateLoaded = loadedValue;
                stateUnavailable = !loadedValue;
                if (loadedValue) {
                    active = activeValue;
                    generation = generationValue;
                expiry = expiryValue;
                blockReason = reasonValue;
                    cardLimit = limitValue;
                }
                cardView.setDemoCardState(loadedValue && activeValue, loadedValue ? generationValue : 0, loadedValue);
                if (!loadedValue) {
                    status.setText("Situação indisponível. Ações desativadas até consultar o servidor.");
                    details.setText("Não foi possível confirmar o estado do cartão. Tente atualizar a tela.");
                } else {
                status.setText(active ? "ATIVO · DEMONSTRATIVO · SEM PAGAMENTOS" : generation > 0 ? "BLOQUEADO · DEMONSTRATIVO" : "NÃO ATIVADO · DEMONSTRATIVO");
                if (active) {
                    details.setText("Número demonstrativo inválido: 0000 0000 0000 0000\nValidade ilustrativa: 12/99 (não é validade de pagamento)
                        + "\nCódigo de segurança: DEMO (não é CVV)\nIdentificador de controle: DEMO-" + String.format(java.util.Locale.ROOT, "%04d", generation));
                } else if (generation > 0) {
                    details.setText("Os marcadores fictícios não são mostrados enquanto o cartão está bloqueado." + (blockReason.isEmpty() ? "" : "\nMotivo registrado: " + blockReason));
                } else {
                    details.setText("Nenhum cartão demonstrativo ativado.");
                }
                }
                renderActions();
            });
        }, "demo-card-refresh").start();
    }

    private String displayExpiry(String raw) {
        if (raw == null || !raw.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) return "indisponível";
        return raw.substring(5, 7) + "/" + raw.substring(0, 4);
    }

    private JSONArray readState(String token, String account) throws Exception {
        return InterbankRest.get("customer_profiles?select=demo_card_active,demo_card_generation,demo_card_expires_on,demo_card_block_reason,card_credit_limit&account_number=eq." + account + "&limit=1", token);
    }

    private void loadCreditLimit() {
        String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (creditLimit == null || token.isEmpty() || !account.matches("[0-9]{6}")) return;
        SupabaseProfileClient.fetchCreditLimits(token, account, (loan, card, used) -> runOnUiThread(() -> {
            if (isFinishing() || creditLimit == null) return;
            try {
                java.math.BigDecimal limit = new java.math.BigDecimal(card), consumed = new java.math.BigDecimal(used);
                creditLimit.setText("Limite demonstrativo: " + formatMoney(card) + " · utilizado: " + formatMoney(used) + " · disponível: " + formatMoney(limit.subtract(consumed).max(java.math.BigDecimal.ZERO).toPlainString()));
            } catch (Exception error) { creditLimit.setText("Limite demonstrativo indisponível."); }
        }));
    }

    private String formatMoney(String raw) { return java.text.NumberFormat.getCurrencyInstance(new java.util.Locale("pt", "BR")).format(new java.math.BigDecimal(raw)); }

    private void loadCardholderName() {
        String token = SessionStore.accessToken(), account = SessionStore.accountNumber();
        if (token.isEmpty() || !account.matches("[0-9]{6}")) return;
        SupabaseProfileClient.fetchDisplayName(token, account, name -> runOnUiThread(() -> {
            if (!isFinishing() && cardView != null && account.equals(SessionStore.accountNumber())) cardView.setCardholderName(name == null || name.trim().isEmpty() ? "TITULAR DO CARTÃO" : name.trim());
        }));
    }
}
